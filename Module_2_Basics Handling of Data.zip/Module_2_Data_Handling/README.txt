BASICS HANDLING OF DATA: RAW DATA, GRAPHS, SUMMARY STATISTICS, COMPONENTS OF A TIME SERIES AND TRANSFORMATIONS
Module 2 of the course on Linear Regression Models. Manhar Singh, November 2026. Notes: 37 pages.

FOLDERS
  notes/                 PDF of the notes, LaTeX source, and lrm-notes.sty (keep the .sty next to the .tex to compile).
  overleaf_single_file/  The same notes as one self-contained .tex file (style inlined): paste into Overleaf and compile.
  data/                  The four data sets used in the module (these are reused in later modules):
                           macro.csv        US quarterly macroeconomic data, 1959Q1-2009Q3
                           engel.csv        food expenditure and income of 235 Belgian households (Koenker and Bassett)
                           grunfeld.csv     investment data for 11 US firms, 1935-1954 (Grunfeld)
                           co2_monthly.csv  Mauna Loa atmospheric CO2, monthly
  code/                  module2_examples.py reproduces every number in the notes and writes the four CSV files
                         (needs numpy, pandas, scipy, statsmodels; the data come from the statsmodels package).
                         module2_examples.R reads the CSV files: copy them from data/ into code/ first. It uses base R
                         plus the mFilter package for the Hodrick-Prescott filter.
                         module_2_template.tex, module2_coords.py and build_module2.py regenerate the notes' .tex
                         (the figures' plotted points) if you change the data.

COMPILING: pdflatex, run twice (for the table of contents).
This module has no practice workbook and no instructor material.
NOTE: the R script was not run for this edition; please run it once before class.
