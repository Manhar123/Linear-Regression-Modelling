# Module 2 -- Basics Handling of Data
# R companion to module2_examples.py. Reads the CSV files that the Python script exports,
# so both languages use identical data. Base R plus mFilter (for the HP filter).

macro <- read.csv("macro.csv")        # US quarterly, 1959Q1-2009Q3
engel <- read.csv("engel.csv")        # Belgian household budgets, 1857
grun  <- read.csv("grunfeld.csv")     # 11 US firms, 1935-1954
co2   <- read.csv("co2_monthly.csv")  # Mauna Loa CO2, monthly

jb <- function(x) { x <- na.omit(x); n <- length(x); m <- x - mean(x)
  s <- mean(m^3) / mean(m^2)^1.5; k <- mean(m^4) / mean(m^2)^2
  stat <- n / 6 * (s^2 + (k - 3)^2 / 4); c(skew = s, kurt = k, JB = stat, p = 1 - pchisq(stat, 2)) }
summ <- function(x) { x <- na.omit(x)
  c(n = length(x), mean = mean(x), median = median(x), min = min(x), max = max(x), sd = sd(x), jb(x)) }
ac1 <- function(x) cor(x[-1], x[-length(x)])

# ---------------------------------------------------------------
cat("=== Experiment 1: a first look at the raw data ===\n")
cat("observations:", nrow(macro), "| missing:", sum(is.na(macro)), "\n")
print(sapply(macro[, c("realgdp", "cpi", "m1", "tbilrate", "unemp", "infl")], range))
g <- 100 * diff(log(macro$realgdp))
cat("largest quarterly fall:", macro$date[which.min(g) + 1], round(min(g), 2), "%\n")
cat("highest T-bill rate:", macro$date[which.max(macro$tbilrate)], max(macro$tbilrate), "\n")
cat("first inflation value:", macro$infl[1], "\n")

# ---------------------------------------------------------------
cat("\n=== Experiment 2: summary statistics ===\n")
print(round(rbind(income = summ(engel$income), log_income = summ(log(engel$income)),
                  food_share = summ(engel$foodexp / engel$income), gdp_growth = summ(g),
                  inflation = summ(macro$infl[-1]), unemployment = summ(macro$unemp)), 3))
hist(engel$income, breaks = 20); hist(log(engel$income), breaks = 20)

# ---------------------------------------------------------------
cat("\n=== Experiment 3: Engel's law ===\n")
fit <- lm(foodexp ~ income, data = engel)
share <- engel$foodexp / engel$income; low <- engel$income <= median(engel$income)
print(c(corr = cor(engel$income, engel$foodexp), coef(fit), share_low = mean(share[low]), share_high = mean(share[!low])))
plot(engel$income, engel$foodexp); abline(fit)

# ---------------------------------------------------------------
cat("\n=== Experiment 4: bar and pie (Grunfeld) ===\n")
mean_inv <- sort(tapply(grun$invest, grun$firm, mean), decreasing = TRUE); print(round(mean_inv, 1))
y54 <- with(subset(grun, year == 1954), setNames(invest, firm))
share54 <- sort(100 * y54 / sum(y54), decreasing = TRUE); print(round(share54, 1))
barplot(rev(mean_inv), horiz = TRUE, las = 1); pie(c(share54[1:5], Other = sum(share54[-(1:5)])))

# ---------------------------------------------------------------
cat("\n=== Experiment 5: HP filter on log real GDP ===\n")
library(mFilter)   # install.packages("mFilter") if needed
lgdp <- ts(100 * log(macro$realgdp), start = c(1959, 1), frequency = 4)
hp <- hpfilter(lgdp, freq = 1600, type = "lambda")
cyc <- as.numeric(hp$cycle)
cat(sprintf("cycle sd %.2f; min %.2f at %s; max %.2f at %s\n", sd(cyc), min(cyc), macro$date[which.min(cyc)],
            max(cyc), macro$date[which.max(cyc)]))
plot(lgdp); lines(hp$trend, lty = 2)

# ---------------------------------------------------------------
cat("\n=== Experiment 6: STL decomposition of CO2 ===\n")
y <- ts(co2$co2, start = c(1958, 3), frequency = 12)
dec <- stl(y, s.window = 7, robust = TRUE)
seas <- dec$time.series[, "seasonal"]; print(round(tapply(seas, cycle(seas), mean), 2))
cat("sd irregular:", round(sd(dec$time.series[, "remainder"]), 2), "\n"); plot(dec)

# ---------------------------------------------------------------
cat("\n=== Experiment 7: changing frequency ===\n")
yr <- floor(macro$year)
ann <- data.frame(gdp_mean = tapply(macro$realgdp, yr, mean), gdp_sum = tapply(macro$realgdp, yr, sum),
                  m1_end = tapply(macro$m1, yr, function(v) tail(v, 1)), m1_mean = tapply(macro$m1, yr, mean),
                  unemp = tapply(macro$unemp, yr, mean))
print(round(ann[c("2000", "2008"), ], 1))

# ---------------------------------------------------------------
cat("\n=== Experiment 8: nominal versus real ===\n")
p <- macro$cpi / macro$cpi[1]
nom_inv <- macro$realinv * p; nom_gov <- macro$realgovt * p
print(c(levels_nominal = cor(nom_inv, nom_gov), levels_real = cor(macro$realinv, macro$realgovt),
        growth_nominal = cor(diff(log(nom_inv)), diff(log(nom_gov))),
        growth_real = cor(diff(log(macro$realinv)), diff(log(macro$realgovt)))))
cpi2005 <- mean(macro$cpi[yr == 2005]); print(100 * macro$cpi[c(1, nrow(macro))] / cpi2005)

# ---------------------------------------------------------------
cat("\n=== Experiment 9: logs ===\n")
lev <- macro$realgdp; t <- seq_along(lev)
print(c(r2_levels = summary(lm(lev ~ t))$r.squared, r2_logs = summary(lm(log(lev) ~ t))$r.squared))
d <- diff(lev); dl <- 100 * diff(log(lev)); yr1 <- yr[-1]
print(c(change_1960s = mean(d[yr1 %in% 1960:1969]), change_2000s = mean(d[yr1 %in% 2000:2007]),
        pct_1960s = mean(dl[yr1 %in% 1960:1969]), pct_2000s = mean(dl[yr1 %in% 2000:2007])))

# ---------------------------------------------------------------
cat("\n=== Experiment 10: differencing ===\n")
l <- log(lev); d1 <- diff(l); d2 <- diff(d1)
print(c(ac_level = ac1(l), ac_d1 = ac1(d1), ac_d2 = ac1(d2), sd_d1 = sd(d1), sd_d2 = sd(d2)))

# ---------------------------------------------------------------
cat("\n=== Experiment 11: four ways to measure growth ===\n")
n <- length(lev)
gr <- data.frame(date = macro$date, discrete = c(NA, 100 * diff(lev) / lev[-n]),
                 logqq = c(NA, 100 * diff(log(lev))), annualised = c(NA, 400 * diff(log(lev))),
                 yy = c(rep(NA, 4), 100 * diff(log(lev), lag = 4)))
print(tail(gr, 5), digits = 3); print(round(colMeans(gr[, -1], na.rm = TRUE), 3))
