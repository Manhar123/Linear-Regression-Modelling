"""Module 2 -- Basics Handling of Data.
Every number printed in the Module 2 notes is produced by this script.
Data: four real data sets that ship with statsmodels (no download needed).
Run from top to bottom:  python module2_examples.py
"""
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
from statsmodels.tsa.filters.hp_filter import hpfilter
from statsmodels.tsa.seasonal import STL

pd.set_option("display.width", 120); pd.set_option("display.precision", 3)

# ---------------------------------------------------------------
# The data
macro = sm.datasets.macrodata.load_pandas().data
macro.index = pd.period_range("1959Q1", periods=len(macro), freq="Q")
engel = sm.datasets.engel.load_pandas().data           # Belgian household budgets, 1857
grun = sm.datasets.grunfeld.load_pandas().data          # 11 US firms, 1935-1954
co2w = sm.datasets.co2.load_pandas().data               # weekly CO2, Mauna Loa
co2 = co2w["co2"].resample("MS").mean().interpolate()   # monthly averages

# export the four data sets so that R (or a spreadsheet) uses exactly the same numbers
macro.assign(date=macro.index.astype(str)).to_csv("macro.csv", index=False)
engel.to_csv("engel.csv", index=False)
grun.to_csv("grunfeld.csv", index=False)
co2.rename("co2").rename_axis("date").to_csv("co2_monthly.csv")

# ---------------------------------------------------------------
print("=== Experiment 1: a first look at the raw data ===")
print("observations:", len(macro), "| sample:", macro.index[0], "to", macro.index[-1])
print("missing values:", int(macro.isna().sum().sum()))
print(macro[["realgdp", "cpi", "m1", "tbilrate", "unemp", "infl"]].agg(["min", "max"]).T)
g = 100 * np.log(macro["realgdp"]).diff()
print("largest quarterly fall in real GDP:", g.idxmin(), round(g.min(), 2), "%")
print("highest T-bill rate:", macro["tbilrate"].idxmax(), macro["tbilrate"].max())
print("first CPI-inflation value (no previous quarter):", macro["infl"].iloc[0])
print("engel: n =", len(engel), "| income min/max:", round(engel.income.min(), 1), round(engel.income.max(), 1))
print("co2 monthly: ", co2.index[0].strftime("%Y-%m"), "to", co2.index[-1].strftime("%Y-%m"),
      "| weekly values missing before interpolation:", int(co2w["co2"].isna().sum()))

# ---------------------------------------------------------------
print("\n=== Experiment 2: summary statistics ===")
def describe(x):
    x = pd.Series(x).dropna(); jb, p = stats.jarque_bera(x)
    return pd.Series({"n": len(x), "mean": x.mean(), "median": x.median(), "min": x.min(),
                      "max": x.max(), "sd": x.std(ddof=1), "skew": stats.skew(x),
                      "kurt": stats.kurtosis(x, fisher=False), "JB": jb, "p": p})
tab = pd.DataFrame({
    "income": describe(engel.income),
    "log income": describe(np.log(engel.income)),
    "food share": describe(engel.foodexp / engel.income),
    "GDP growth": describe(g),
    "inflation": describe(macro["infl"].iloc[1:]),
    "unemployment": describe(macro["unemp"]),
}).T
print(tab.round(3))

# ---------------------------------------------------------------
print("\n=== Experiment 3: scatterplot relationship (Engel's law) ===")
r = np.corrcoef(engel.income, engel.foodexp)[0, 1]
fit = sm.OLS(engel.foodexp, sm.add_constant(engel.income)).fit()
lo, hi = engel.income <= engel.income.median(), engel.income > engel.income.median()
print(f"corr(income, food) = {r:.3f}; slope = {fit.params.iloc[1]:.3f}")
print(f"mean food share: lower half {np.mean(engel.foodexp[lo]/engel.income[lo]):.3f}, "
      f"upper half {np.mean(engel.foodexp[hi]/engel.income[hi]):.3f}")

# ---------------------------------------------------------------
print("\n=== Experiment 4: bar and pie (Grunfeld firms) ===")
mean_inv = grun.groupby("firm")["invest"].mean().sort_values(ascending=False)
print(mean_inv.round(1))
y54 = grun[grun.year == 1954].set_index("firm")["invest"]
share = (100 * y54 / y54.sum()).sort_values(ascending=False)
print("1954 shares (%):"); print(share.round(1))

# ---------------------------------------------------------------
print("\n=== Experiment 5: trend and cycle in US real GDP (HP filter, lambda = 1600) ===")
lgdp = 100 * np.log(macro["realgdp"])
cycle, trend = hpfilter(lgdp, lamb=1600)
print(f"cycle sd {cycle.std():.2f}% of trend; min {cycle.min():.2f} at {cycle.idxmin()}; "
      f"max {cycle.max():.2f} at {cycle.idxmax()}")
tg = trend.diff() * 4
print(f"trend growth (annualised): 1960s {tg['1960Q1':'1969Q4'].mean():.2f}%, 2000s {tg['2000Q1':'2009Q3'].mean():.2f}%")

# ---------------------------------------------------------------
print("\n=== Experiment 6: trend, seasonal and irregular in CO2 (STL) ===")
stl = STL(co2, period=12, robust=True).fit()
seas = stl.seasonal
by_month = seas.groupby(seas.index.month).mean()
print(f"seasonal peak month {by_month.idxmax()} ({by_month.max():.2f}), trough month {by_month.idxmin()} ({by_month.min():.2f}) ppm")
print(f"trend rise: {stl.trend.iloc[0]:.1f} -> {stl.trend.iloc[-1]:.1f} ppm; "
      f"sd seasonal {seas.std():.2f}, sd irregular {stl.resid.std():.2f}")
var_shares = pd.Series({"seasonal": seas.var(), "irregular": stl.resid.var()})
print("variance of detrended series explained by seasonal:", round(seas.var() / (co2 - stl.trend).var(), 3))

# ---------------------------------------------------------------
print("\n=== Experiment 7: changing frequency -- flows, stocks and averages ===")
a = macro.copy(); a["year"] = a.index.year
ann = a.groupby("year").agg(realgdp_mean=("realgdp", "mean"), realgdp_sum=("realgdp", "sum"),
                            m1_end=("m1", "last"), m1_mean=("m1", "mean"), unemp=("unemp", "mean"))
print(ann.loc[[2000, 2008]].round(1))

# ---------------------------------------------------------------
print("\n=== Experiment 8: nominal versus real (spurious correlation from prices) ===")
p = macro["cpi"] / macro["cpi"].iloc[0]       # price level, 1959Q1 = 1
nom_inv, nom_gov = macro["realinv"] * p, macro["realgovt"] * p   # reflated with CPI
def c(x, y): return np.corrcoef(x, y)[0, 1]
print(f"corr levels, nominal: {c(nom_inv, nom_gov):.3f}; real: {c(macro.realinv, macro.realgovt):.3f}")
print(f"corr growth rates, nominal: {c(np.log(nom_inv).diff()[1:], np.log(nom_gov).diff()[1:]):.3f}; "
      f"real: {c(np.log(macro.realinv).diff()[1:], np.log(macro.realgovt).diff()[1:]):.3f}")
cpi2005 = macro["cpi"]["2005Q1":"2005Q4"].mean()
print(f"CPI rebased to 2005 = 100: 1959Q1 {100*macro.cpi.iloc[0]/cpi2005:.1f}, 2009Q3 {100*macro.cpi.iloc[-1]/cpi2005:.1f}")

# ---------------------------------------------------------------
print("\n=== Experiment 9: logs ===")
lev = macro["realgdp"]; t = np.arange(len(lev))
r2_lev = sm.OLS(lev, sm.add_constant(t)).fit().rsquared
r2_log = sm.OLS(np.log(lev), sm.add_constant(t)).fit().rsquared
print(f"R^2 of linear trend: levels {r2_lev:.4f}, logs {r2_log:.4f}")
print(f"real GDP rose {lev.iloc[-1]/lev.iloc[0]:.2f}-fold; log rose {np.log(lev.iloc[-1])-np.log(lev.iloc[0]):.3f}")
# one-step change: level change grows, log change does not
print(f"average quarterly change: 1960s {lev.diff()['1960Q1':'1969Q4'].mean():.1f} bn, 2000s {lev.diff()['2000Q1':'2007Q4'].mean():.1f} bn")
print(f"average quarterly log change x100: 1960s {g['1960Q1':'1969Q4'].mean():.2f}, 2000s {g['2000Q1':'2007Q4'].mean():.2f}")

# ---------------------------------------------------------------
print("\n=== Experiment 10: differencing ===")
d1 = np.log(lev).diff().dropna(); d2 = d1.diff().dropna()
for name, s in [("log level", np.log(lev)), ("first difference", d1), ("second difference", d2)]:
    print(f"{name:18s}: first-order autocorrelation {s.autocorr(1):.3f}, sd {s.std():.4f}")

# ---------------------------------------------------------------
print("\n=== Experiment 11: four ways to measure growth ===")
gr = pd.DataFrame({
    "discrete q/q %": 100 * lev.pct_change(),
    "log q/q %": 100 * np.log(lev).diff(),
    "annualised log q/q %": 400 * np.log(lev).diff(),
    "y/y log %": 100 * np.log(lev).diff(4),
})
print(gr.loc[["2008Q3", "2008Q4", "2009Q1", "2009Q2", "2009Q3"]].round(2))
print("mean over sample:"); print(gr.mean().round(3))

# ---------------------------------------------------------------
# coordinate strings for the figures (written to module2_coords.py)
def coords(xs, ys, nd=2):
    return " ".join(f"({x:.{nd}f},{y:.{nd}f})" for x, y in zip(xs, ys))
tq = macro.index.year + (macro.index.quarter - 1) / 4
out = {}
out["gdp"] = coords(tq, macro.realgdp / 1000, 3)
out["cons"] = coords(tq, macro.realcons / 1000, 3)
out["lgdp"] = coords(tq, lgdp / 100, 4)
out["hptrend"] = coords(tq, trend / 100, 4)
out["cycle"] = coords(tq, cycle, 3)
out["engel"] = coords(engel.income, engel.foodexp, 1)
for name, x in [("hist_inc", engel.income), ("hist_linc", np.log(engel.income))]:
    cnt, edges = np.histogram(x, bins=20)
    out[name] = " ".join(f"({e:.3f},{c})" for e, c in zip(edges, list(cnt) + [cnt[-1]]))
out["bar"] = " ".join(f"({v:.1f},{k})" for k, v in mean_inv.items())
out["barsym"] = ",".join(mean_inv.index)
out["pie"] = share.round(1).to_dict()
tm = co2.index.year + (co2.index.month - 1) / 12
out["co2"] = coords(tm, co2, 2); out["co2trend"] = coords(tm, stl.trend, 2)
w = co2.index >= "1990-01-01"
out["co2seas"] = coords(tm[w], seas[w], 2); out["co2irr"] = coords(tm[w], stl.resid[w], 2)
out["gq"] = coords(tq[1:], 400 * np.log(lev).diff()[1:], 2)
out["gy"] = coords(tq[4:], 100 * np.log(lev).diff(4)[4:], 2)
with open("module2_coords.py", "w") as f:
    f.write("COORDS = " + repr(out) + "\n")
print("\n[figure coordinates written to module2_coords.py]")
