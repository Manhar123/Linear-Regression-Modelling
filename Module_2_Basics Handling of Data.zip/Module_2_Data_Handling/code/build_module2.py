"""Fill the figure placeholders in module_2_template.tex and write
module_2_data_handling.tex (uses lrm-notes.sty) and a standalone copy."""
from module2_coords import COORDS

t = open("module_2_template.tex").read()
c = dict(COORDS)
# bar chart: pgfplots draws the first symbolic coordinate at the bottom, so list smallest first
firms = c["barsym"].split(",")
c["barsym_rev"] = ",".join(reversed(firms))
# pie chart: top five firms plus the rest
pie = list(c["pie"].items())
top, rest = pie[:5], round(100 - sum(v for _, v in pie[:5]), 1)
c["pie"] = ", ".join(f"{v}/{k} ({v}\\%)" for k, v in top) + f", {rest}/Other six firms ({rest}\\%)"
for k, v in c.items():
    t = t.replace(f"@@{k}@@", str(v))
assert "@@" not in t, "unfilled placeholder"
open("module_2_data_handling.tex", "w").write(t)

# standalone version with the style inlined
sty = open("lrm-notes.sty").read()
body = "\n".join(l for l in sty.splitlines()
                 if not l.startswith(("\\NeedsTeXFormat", "\\ProvidesPackage", "\\endinput")))
body = body.replace("\\RequirePackage", "\\usepackage")
block = ("% ===== House style (inlined from lrm-notes.sty) =====\n\\makeatletter\n" + body +
         "\n\\makeatother\n% ===== End of house style =====\n")
open("standalone/module_2_data_handling.tex", "w").write(t.replace("\\usepackage{lrm-notes}", block, 1))
print("written")
