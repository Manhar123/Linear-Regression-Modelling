# Module 6 -- Basic Framework of the Multiple Linear Regression Model
# R companion to module6_examples.py. Needs grunfeld.csv, macro.csv (from module2_examples.py),
# statecrime.csv (from module6_examples.py) and Foundations_Practice_Data.xlsx; package readxl.
# Deterministic results match the notes; simulations give the same pattern, different decimals.

grun <- read.csv("grunfeld.csv"); macro <- read.csv("macro.csv")
crime <- read.csv("statecrime.csv", row.names = 1)
library(readxl)
hh <- as.data.frame(read_excel("Foundations_Practice_Data.xlsx", sheet = "Households", range = "A4:I204"))
names(hh) <- c("id", "region", "urban", "size", "school", "income", "cons", "sav", "inc000")

cat("=== Experiment 1: three-variable model (General Motors) ===\n")
gm <- subset(grun, firm == "General Motors")
f3 <- lm(invest ~ value + capital, data = gm); print(summary(f3))
with(gm, { v2 <- var(value); v3 <- var(capital); c23 <- cov(value, capital)
  c2y <- cov(value, invest); c3y <- cov(capital, invest); den <- v2 * v3 - c23^2
  print(c(b2 = (c2y * v3 - c3y * c23) / den, b3 = (c3y * v2 - c2y * c23) / den, corr = cor(value, capital))) })
X <- model.matrix(f3); print(solve(t(X) %*% X, t(X) %*% gm$invest))
cat("simple slope on value", coef(lm(invest ~ value, data = gm))[2], "\n")
r2 <- resid(lm(value ~ capital, data = gm)); cat("Frisch-Waugh", coef(lm(gm$invest ~ r2))[2], "\n")
d <- coef(lm(capital ~ value, data = gm))[2]; cat("OVB identity", coef(f3)[2] + coef(f3)[3] * d, "\n")

cat("\n=== Experiment 2: k-variable case (Households) ===\n")
hh$C <- hh$cons / 1000
fh <- lm(C ~ inc000 + size + school + urban, data = hh); print(summary(fh))
X <- model.matrix(fh)
print(max(abs(solve(t(X) %*% X, t(X) %*% hh$C) - coef(fh))))
print(c(sum_e = sum(resid(fh)), max_Xe = max(abs(t(X) %*% resid(fh)))))

cat("\n=== Experiment 3: unbiasedness, variance, omitted variable ===\n")
set.seed(61); n <- 40; reps <- 20000; sigma <- 2
z1 <- rnorm(n); z2 <- 0.7 * z1 + sqrt(0.51) * rnorm(n)
X <- cbind(1, 10 + 2 * z1, 5 + 2 * z2); beta <- c(1, 0.5, -0.3)
W <- solve(t(X) %*% X) %*% t(X)
Ys <- matrix(X %*% beta, reps, n, byrow = TRUE) + matrix(rnorm(reps * n, 0, sigma), reps)
B <- Ys %*% t(W)
print(rbind(mean = colMeans(B), sd = apply(B, 2, sd), sd_theory = sqrt(diag(sigma^2 * solve(t(X) %*% X)))))
RSS <- rowSums((Ys - B %*% t(X))^2); cat("mean RSS/(n-k)", mean(RSS / (n - 3)), " mean RSS/n", mean(RSS / n), "\n")
x2 <- X[, 2] - mean(X[, 2]); b_short <- Ys %*% (x2 / sum(x2^2))
cat("omit X3: mean slope", mean(b_short), " predicted", 0.5 - 0.3 * sum(x2 * X[, 3]) / sum(x2^2), "\n")
for (r in c(0, 0.5, 0.9, 0.99)) {
  set.seed(62); a1 <- rnorm(n); a2 <- r * a1 + sqrt(1 - r^2) * rnorm(n)
  Xr <- cbind(1, 10 + 2 * scale(a1), 5 + 2 * scale(a2)); rho <- cor(a1, a2)
  cat(sprintf("corr %.3f: sd(b2) %.4f, 1/sqrt(1-r^2) %.2f\n", rho, sqrt(sigma^2 * solve(t(Xr) %*% Xr)[2, 2]), 1 / sqrt(1 - rho^2)))
}

cat("\n=== Experiment 4: consistency ===\n")
set.seed(63)
for (nn in c(25, 100, 400, 1600, 6400)) {
  est <- replicate(2000, { a1 <- rnorm(nn); a2 <- 0.7 * a1 + sqrt(0.51) * rnorm(nn)
    coef(lm(1 + 0.5 * a1 - 0.3 * a2 + 2 * rnorm(nn) ~ a1 + a2))[2] })
  cat(sprintf("n %5d: mean %.4f sd %.4f sd*sqrt(n) %.3f P(|err|>0.1) %.4f\n", nn, mean(est), sd(est), sd(est) * sqrt(nn), mean(abs(est - 0.5) > 0.1)))
}

cat("\n=== Experiment 5: a rival linear unbiased estimator ===\n")
M <- diag(n) - X %*% solve(t(X) %*% X) %*% t(X); set.seed(64)
Z <- matrix(rnorm(3 * n, 0, 0.05), 3) %*% M; cat("max |ZX|", max(abs(Z %*% X)), "\n")
Bs <- Ys %*% t(W + Z)
print(rbind(mean_star = colMeans(Bs), sd_star = apply(Bs, 2, sd), sd_ols = apply(B, 2, sd),
            theory_star = sqrt(diag(sigma^2 * (solve(t(X) %*% X) + Z %*% t(Z))))))

cat("\n=== Experiment 6: R2 and adjusted R2 (US states) ===\n")
fb <- lm(violent ~ poverty + single + urban, data = crime); print(summary(fb))
set.seed(65); d <- crime[, c("violent", "poverty", "single", "urban")]
for (j in 1:20) { d[[paste0("junk", j)]] <- rnorm(nrow(d)); s <- summary(lm(violent ~ ., data = d))
  cat(j, round(s$r.squared, 4), round(s$adj.r.squared, 4), "\n") }
fa <- lm(violent ~ poverty + single + urban + hs_grad + white, data = crime); print(summary(fa)$coefficients)
set.seed(66); s <- summary(lm(rnorm(20) ~ matrix(rnorm(100), 20))); cat("noise: R2", s$r.squared, "adj", s$adj.r.squared, "\n")
fnd <- lm(violent ~ poverty + single + urban, data = crime[rownames(crime) != "District of Columbia", ])
cat("without DC: R2", summary(fnd)$r.squared, "\n")

cat("\n=== Experiment 7: information criteria in Asteriou-Hall form ===\n")
crit <- function(f) { n <- length(resid(f)); k <- length(coef(f)); r <- sum(resid(f)^2) / n
  c(k = k, R2 = summary(f)$r.squared, adjR2 = summary(f)$adj.r.squared, AIC = r * exp(2 * k / n),
    FPE = r * (n + k) / (n - k), SBC = r * n^(k / n), HQC = r * log(n)^(2 * k / n)) }
forms <- c("violent ~ poverty", "violent ~ single", "violent ~ poverty + single", "violent ~ poverty + single + urban",
           "violent ~ poverty + single + urban + hs_grad", "violent ~ poverty + single + urban + hs_grad + white",
           "violent ~ single + urban")
tab <- t(sapply(forms, function(fm) crit(lm(as.formula(fm), data = crime)))); print(round(tab, 3))
# R's AIC() = -2logL + 2(k+1): it also counts sigma^2; rankings are unchanged
print(sapply(forms, function(fm) AIC(lm(as.formula(fm), data = crime))))

cat("\n=== Experiment 8: which criterion finds the true model? ===\n")
set.seed(67); K <- 6; bt <- c(1, 0.6, 0.3, 0, 0, 0, 0)
for (nn in c(30, 100, 500)) {
  picks <- replicate(4000, { Xr <- cbind(1, matrix(rnorm(nn * K), nn)); y <- Xr %*% bt + rnorm(nn)
    res <- sapply(0:K, function(p) { f <- lm.fit(Xr[, 1:(p + 1), drop = FALSE], y); rss <- sum(f$residuals^2)
      k <- p + 1; r <- rss / nn
      c(-(1 - (rss / (nn - k)) / (sum((y - mean(y))^2) / (nn - 1))), log(r) + 2 * k / nn, log(r * (nn + k) / (nn - k)),
        log(r) + 2 * k * log(log(nn)) / nn, log(r) + k * log(nn) / nn) })
    apply(res, 1, which.min) - 1 })
  cat("n =", nn, " share correct (adjR2, AIC, FPE, HQC, SBC):", round(rowMeans(picks == 2), 3), "\n")
}

cat("\n=== Experiment 9: lag length in Okun's law ===\n")
du <- diff(macro$unemp); g <- 100 * diff(log(macro$realgdp)); P <- 4; T <- length(du) - P
y <- du[(P + 1):length(du)]
for (p in 0:P) {
  X <- sapply(0:p, function(j) g[(P + 1 - j):(length(g) - j)]); f <- lm(y ~ X)
  r <- sum(resid(f)^2) / T; k <- p + 2
  cat(p, round(c(adjR2 = summary(f)$adj.r.squared, lnAIC = log(r) + 2 * k / T, lnFPE = log(r * (T + k) / (T - k)),
                 lnHQC = log(r) + 2 * k * log(log(T)) / T, lnSBC = log(r) + k * log(T) / T), 4), round(coef(f)[-1], 3), "\n")
}
