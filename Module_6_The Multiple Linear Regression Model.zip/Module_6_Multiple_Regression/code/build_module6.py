"""Fill figure and table placeholders in module_6_template.tex."""
import numpy as np
from module6_coords import COORDS
t = open("module_6_template.tex").read(); c = COORDS
reps = 20000; w = 0.025; edges = np.linspace(0, 1, 41)
def hist(h): return " ".join(f"({e:.3f},{v/(reps*w):.4f})" for e, v in zip(edges, list(h) + [h[-1]]))
t = t.replace("@@mchist@@", hist(c["mc_hist"])).replace("@@mcshort@@", hist(c["mc_short"]))
t = t.replace("@@r2@@", " ".join(f"({k-3},{a:.4f})" for k, a, b in c["r2path"]))
t = t.replace("@@adjr2@@", " ".join(f"({k-3},{b:.4f})" for k, a, b in c["r2path"]))
base = c["coll"][0][2]
t = t.replace("@@colltable@@", "\n".join(f"{rho:.2f} & {sd:.3f} & {sd/base:.2f} & {1/np.sqrt(1-rho**2):.2f}\\\\" for r, rho, sd in c["coll"]))
cons = [(25, 0.4869, 0.5945, 0.8615), (100, 0.4992, 0.2815, 0.7110), (400, 0.4999, 0.1405, 0.4645),
        (1600, 0.5009, 0.0693, 0.1475), (6400, 0.5003, 0.0341, 0.0030)]   # from module6_examples.py output
t = t.replace("@@constable@@", "\n".join(f"{n:,} & {m:.4f} & {s:.4f} & {s*np.sqrt(n):.2f} & {p:.3f}\\\\".replace(",", "{,}") for n, m, s, p in cons))
crit = ["adjR2", "AIC", "FPE", "HQC", "SBC"]
t = t.replace("@@seltable@@", "\n".join(f"$n={n}$ & " + " & ".join(f"{c['sel'][n][m][2]:.3f}" for m in crit) + "\\\\" for n in [30, 100, 500]))
styles = {"adjR2": "black!60,dotted,mark=o", "AIC": "rust,mark=*", "FPE": "rust!50,dashed,mark=x",
          "HQC": "sepia,mark=square*", "SBC": "slate,line width=1.2pt,mark=triangle*"}
names = {"adjR2": "$\\bar R^2$", "AIC": "AIC", "FPE": "FPE", "HQC": "HQC", "SBC": "SBC"}
pc, po = [], []
for m in crit:
    pc.append(f"\\addplot[{styles[m]},mark size=1.6pt] coordinates {{" + " ".join(f"({n},{c['sel'][n][m][2]:.4f})" for n in [30, 100, 500]) + "};")
    pc.append(f"\\addlegendentry{{{names[m]}}}")
    po.append(f"\\addplot[{styles[m]},mark size=1.6pt] coordinates {{" + " ".join(f"({n},{sum(c['sel'][n][m][3:]):.4f})" for n in [30, 100, 500]) + "};")
t = t.replace("@@selcorrect@@", "\n".join(pc)).replace("@@selover@@", "\n".join(po))
lab = {"poverty": "Pov", "single": "Single", "urban": "Urban", "hs_grad": "HSgrad", "white": "White"}
label = lambda s: ", ".join(lab[v] for v in s.split(" + "))
rows = c["ic_rows"]; mins = [min(r[j] for r in rows) for j in range(5, 9)]
lines = []
for r in rows:
    cells = [f"\\textbf{{{v:,.0f}}}" if v == mins[j] else f"{v:,.0f}" for j, v in enumerate(r[5:9])]
    lines.append(f"{label(r[0])} & {r[1]} & {r[3]:.3f} & {r[4]:.3f} & " + " & ".join(cells).replace(",", "{,}") + "\\\\")
t = t.replace("@@ictable@@", "\n".join(lines))
ok = c["okun_rows"]; best = [min(r[j] for r in ok) for j in (3, 6, 5, 4)]
def fmt(v, b): return f"$\\mathbf{{{v:.4f}}}$" if v == b else f"${v:.4f}$"
coefs = ["$-0.265$", "$-0.214$, $-0.158$", "$-0.199$, $-0.136$, $-0.085$", "$-0.201$, $-0.127$, $-0.074$, $-0.045$",
         "$-0.201$, $-0.127$, $-0.074$, $-0.046$, $0.003$"]
t = t.replace("@@okuntable@@", "\n".join(
    f"{r[0]} & {r[2]:.4f} & {fmt(r[3],best[0])} & {fmt(r[5],best[2])} & {fmt(r[4],best[3])} & {coefs[r[0]]}\\\\" for r in ok))
assert "@@" not in t
open("module_6_multiple_regression.tex", "w").write(t); print("written")
