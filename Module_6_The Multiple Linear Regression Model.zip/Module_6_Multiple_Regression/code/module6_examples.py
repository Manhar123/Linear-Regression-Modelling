"""Module 6 -- Basic Framework of the Multiple Linear Regression Model.
Every number printed in the Module 6 notes is produced by this script.
Needs grunfeld.csv and macro.csv (written by module2_examples.py) and
Foundations_Practice_Data.xlsx (Households sheet). Writes statecrime.csv.
Run from top to bottom:  python module6_examples.py
"""
import numpy as np
import pandas as pd
import statsmodels.api as sm

grun = pd.read_csv("grunfeld.csv"); macro = pd.read_csv("macro.csv")
hh = pd.read_excel("Foundations_Practice_Data.xlsx", sheet_name="Households", header=3, nrows=200, usecols="A:I")
hh.columns = ["id", "region", "urban", "size", "school", "income", "cons", "sav", "inc000"]
crime = sm.datasets.statecrime.load_pandas().data
crime.to_csv("statecrime.csv")

def ols(y, X): return sm.OLS(y, sm.add_constant(X)).fit()

# ---------------------------------------------------------------
print("=== Experiment 1: the three-variable model, three ways (Grunfeld, General Motors) ===")
gm = grun[grun.firm == "General Motors"]
Y = gm.invest.to_numpy(); X2 = gm.value.to_numpy(); X3 = gm.capital.to_numpy(); n = len(Y)
C = np.cov(np.vstack([X2, X3, Y]))           # sample covariances (divisor n-1; it cancels)
v2, v3, c23, c2y, c3y = C[0, 0], C[1, 1], C[0, 1], C[0, 2], C[1, 2]
den = v2 * v3 - c23**2
b2 = (c2y * v3 - c3y * c23) / den; b3 = (c3y * v2 - c2y * c23) / den
b1 = Y.mean() - b2 * X2.mean() - b3 * X3.mean()
print(f"n {n}; formula: b1 {b1:.4f}, b2 {b2:.5f}, b3 {b3:.5f}")
Xm = np.column_stack([np.ones(n), X2, X3])
bm = np.linalg.solve(Xm.T @ Xm, Xm.T @ Y); print("matrix (X'X)^-1 X'Y:", np.round(bm, 5))
f3 = ols(Y, np.column_stack([X2, X3])); print("statsmodels:", np.round(f3.params, 5), "se", np.round(f3.bse, 5),
      f"R2 {f3.rsquared:.4f}, adjR2 {f3.rsquared_adj:.4f}")
print(f"corr(value, capital) {np.corrcoef(X2, X3)[0,1]:.3f}")
fv = ols(Y, X2); fk = ols(Y, X3)
print(f"simple regressions: on value alone slope {fv.params[1]:.5f} (R2 {fv.rsquared:.3f}); on capital alone {fk.params[1]:.5f} (R2 {fk.rsquared:.3f})")
# Frisch-Waugh: residualise
r2 = ols(X2, X3).resid; ry = ols(Y, X3).resid
print(f"Frisch-Waugh: slope of resid(Y|X3) on resid(X2|X3) = {np.sum(r2*ry)/np.sum(r2**2):.5f}")
# omitted variable bias identity: simple slope = b2 + b3 * d, d = slope of X3 on X2
d = ols(X3, X2).params[1]; print(f"OVB identity: b2 + b3*d = {b2:.5f} + {b3:.5f}*{d:.5f} = {b2 + b3*d:.5f}")
# deviation form
x = np.column_stack([X2 - X2.mean(), X3 - X3.mean()]); y = Y - Y.mean()
print("deviation form x'x:\n", np.round(x.T @ x, 1), "\n x'y:", np.round(x.T @ y, 1),
      "\n solution:", np.round(np.linalg.solve(x.T @ x, x.T @ y), 5))
XtX = Xm.T @ Xm; print("X'X:\n", np.round(XtX, 1), "\nX'Y:", np.round(Xm.T @ Y, 1))
s2 = f3.ssr / (n - 3); print(f"s^2 {s2:.2f}, s {np.sqrt(s2):.3f}, se from s^2 (X'X)^-1: {np.round(np.sqrt(np.diag(s2*np.linalg.inv(XtX))), 5)}")

# ---------------------------------------------------------------
print("\n=== Experiment 2: k-variable case (Households) ===")
Yh = hh.cons.to_numpy() / 1000; Xh = np.column_stack([hh.income / 1000, hh["size"], hh.school, hh.urban])
fh = ols(Yh, Xh); Xc = sm.add_constant(Xh)
print("names: const, income000, size, school, urban")
print("coef", np.round(fh.params, 4)); print("se  ", np.round(fh.bse, 4)); print("t   ", np.round(fh.tvalues, 2))
print(f"n {len(Yh)}, k {Xc.shape[1]}, R2 {fh.rsquared:.4f}, adjR2 {fh.rsquared_adj:.4f}, s {np.sqrt(fh.scale):.4f}")
print("matrix check max abs diff", np.max(np.abs(np.linalg.inv(Xc.T @ Xc) @ Xc.T @ Yh - fh.params)))
fs = ols(Yh, Xh[:, 0]); print(f"simple MPC (income only) {fs.params[1]:.4f}, R2 {fs.rsquared:.4f}")
e = fh.resid; print(f"residual checks: sum e {e.sum():.2e}, max |X'e| {np.max(np.abs(Xc.T @ e)):.2e}")

# ---------------------------------------------------------------
print("\n=== Experiment 3: unbiasedness and Var(b) = sigma^2 (X'X)^-1 (Monte Carlo) ===")
rng = np.random.RandomState(61); nn = 40; reps = 20000; sigma = 2.0
z1 = rng.randn(nn); z2 = 0.7 * z1 + np.sqrt(1 - 0.49) * rng.randn(nn)
X2s = 10 + 2 * z1; X3s = 5 + 2 * z2; Xs = np.column_stack([np.ones(nn), X2s, X3s])
beta = np.array([1.0, 0.5, -0.3])
P = np.linalg.inv(Xs.T @ Xs) @ Xs.T
U = rng.randn(reps, nn) * sigma; Ys = Xs @ beta + U
B = Ys @ P.T
print(f"corr(X2,X3) in the fixed design {np.corrcoef(X2s, X3s)[0,1]:.3f}")
print("true beta", beta, " mean of estimates", np.round(B.mean(axis=0), 4))
Vth = sigma**2 * np.linalg.inv(Xs.T @ Xs); Vmc = np.cov(B.T)
print("sd theory", np.round(np.sqrt(np.diag(Vth)), 4), " sd simulated", np.round(np.sqrt(np.diag(Vmc)), 4))
print(f"cov(b2,b3) theory {Vth[1,2]:.5f}, simulated {Vmc[1,2]:.5f}; corr(b2,b3) theory {Vth[1,2]/np.sqrt(Vth[1,1]*Vth[2,2]):.3f}")
RSS = ((Ys - B @ Xs.T)**2).sum(axis=1)
print(f"mean RSS/(n-k) {np.mean(RSS/(nn-3)):.4f}, mean RSS/n {np.mean(RSS/nn):.4f} (sigma^2 = {sigma**2})")
# omitting X3
b_short = Ys @ (X2s - X2s.mean()) / np.sum((X2s - X2s.mean())**2)
dd = np.sum((X2s - X2s.mean()) * X3s) / np.sum((X2s - X2s.mean())**2)
print(f"omit X3: mean slope on X2 {b_short.mean():.4f}; predicted b2 + b3*d = 0.5 + (-0.3)*{dd:.4f} = {0.5 - 0.3*dd:.4f}")
mc_hist = np.histogram(B[:, 1], bins=np.linspace(0.0, 1.0, 41))[0]
mc_short = np.histogram(b_short, bins=np.linspace(0.0, 1.0, 41))[0]
# collinearity and variance
print("collinearity and sd(b2), n = 40, sigma = 2:")
coll = []
for r in [0.0, 0.5, 0.9, 0.99]:
    rr = np.random.RandomState(62); a1 = rr.randn(nn); a2 = r * a1 + np.sqrt(1 - r**2) * rr.randn(nn)
    a1 = (a1 - a1.mean()) / a1.std(); a2 = (a2 - a2.mean()) / a2.std()
    Xr = np.column_stack([np.ones(nn), 10 + 2 * a1, 5 + 2 * a2]); rho = np.corrcoef(a1, a2)[0, 1]
    sd = np.sqrt(sigma**2 * np.linalg.inv(Xr.T @ Xr)[1, 1]); coll.append((r, rho, sd))
    print(f"  target corr {r:.2f} (actual {rho:.3f}): sd(b2) {sd:.4f}; ratio to uncorrelated {sd/coll[0][2]:.2f}; 1/sqrt(1-r^2) {1/np.sqrt(1-rho**2):.2f}")

# ---------------------------------------------------------------
print("\n=== Experiment 4: consistency ===")
rng = np.random.RandomState(63)
cons_rows = []
for nn2 in [25, 100, 400, 1600, 6400]:
    est = []
    for _ in range(2000):
        a1 = rng.randn(nn2); a2 = 0.7 * a1 + np.sqrt(0.51) * rng.randn(nn2)
        Xr = np.column_stack([np.ones(nn2), a1, a2]); yr = Xr @ beta + 2 * rng.randn(nn2)
        est.append(np.linalg.lstsq(Xr, yr, rcond=None)[0][1])
    est = np.array(est); cons_rows.append((nn2, est.mean(), est.std(), np.mean(np.abs(est - 0.5) > 0.1)))
    print(f"n {nn2:5d}: mean b2 {est.mean():.4f}, sd {est.std():.4f}, sd*sqrt(n) {est.std()*np.sqrt(nn2):.3f}, P(|b2-0.5|>0.1) {np.mean(np.abs(est-0.5)>0.1):.4f}")
print(f"theory sd*sqrt(n) = sigma/sqrt(Var(X2)(1-rho^2)) = {2/np.sqrt(1-0.49):.3f}")

# ---------------------------------------------------------------
print("\n=== Experiment 5: BLUE -- a competing linear unbiased estimator ===")
rng = np.random.RandomState(64)
M = np.eye(nn) - Xs @ np.linalg.inv(Xs.T @ Xs) @ Xs.T
D = rng.randn(3, nn) * 0.05; Z = D @ M
print(f"max |ZX| {np.max(np.abs(Z @ Xs)):.2e}")
Pstar = P + Z; Bstar = Ys @ Pstar.T
print("mean beta* ", np.round(Bstar.mean(axis=0), 4))
print("sd OLS     ", np.round(B.std(axis=0), 4)); print("sd beta*   ", np.round(Bstar.std(axis=0), 4))
Vstar_th = Vth + sigma**2 * Z @ Z.T
print("theory sd beta*", np.round(np.sqrt(np.diag(Vstar_th)), 4))
print("eigenvalues of Var(b*) - Var(b) (theory):", np.round(np.linalg.eigvalsh(sigma**2 * Z @ Z.T), 5))
# a natural competitor: OLS on the first half of the sample only (linear, unbiased)
h = nn // 2; Ph = np.zeros((3, nn)); Ph[:, :h] = np.linalg.inv(Xs[:h].T @ Xs[:h]) @ Xs[:h].T
Bh = Ys @ Ph.T; print("half-sample OLS: mean", np.round(Bh.mean(axis=0), 4), " sd", np.round(Bh.std(axis=0), 4))
print(f"half-sample: max |Ph X - I| {np.max(np.abs(Ph @ Xs - np.eye(3))):.2e}")

# ---------------------------------------------------------------
print("\n=== Experiment 6: R^2 and adjusted R^2 (US states, violent crime) ===")
yc = crime.violent.to_numpy(); nc = len(yc)
base_vars = ["poverty", "single", "urban"]
fb = ols(yc, crime[base_vars].to_numpy())
print(f"n {nc}; base model violent ~ poverty + single + urban: coef {np.round(fb.params, 3)}, se {np.round(fb.bse, 3)}")
print(f"  R2 {fb.rsquared:.4f}, adj R2 {fb.rsquared_adj:.4f}")
rng = np.random.RandomState(65); Xj = crime[base_vars].to_numpy(); r2path = [(3, fb.rsquared, fb.rsquared_adj)]
for j in range(1, 21):
    Xj = np.column_stack([Xj, rng.randn(nc)]); fj = ols(yc, Xj); r2path.append((3 + j, fj.rsquared, fj.rsquared_adj))
for kk, a, b in r2path[::4]: print(f"  {kk-3:2d} junk regressors: R2 {a:.4f}, adj R2 {b:.4f}")
print(f"  20 junk: R2 {r2path[-1][1]:.4f}, adj R2 {r2path[-1][2]:.4f}")
# full set of real regressors
fa = ols(yc, crime[["poverty", "single", "urban", "hs_grad", "white"]].to_numpy())
print(f"add hs_grad and white: R2 {fa.rsquared:.4f}, adj R2 {fa.rsquared_adj:.4f}, t {np.round(fa.tvalues[4:], 2)}")
# negative adjusted R2
rng = np.random.RandomState(66); yn = rng.randn(20); Xn = rng.randn(20, 5); fn = ols(yn, Xn)
print(f"pure noise n=20 k=6: R2 {fn.rsquared:.4f}, adj R2 {fn.rsquared_adj:.4f}")
# identity check
k = 4; print(f"identity: 1-(1-R2)(n-1)/(n-k) = {1-(1-fb.rsquared)*(nc-1)/(nc-k):.4f}")

# ---------------------------------------------------------------
print("\n=== Experiment 7: information criteria, A&H forms (states) ===")
def crit(f, n, k):
    r = f.ssr / n
    return dict(AIC=r*np.exp(2*k/n), FPE=r*(n+k)/(n-k), SBC=r*n**(k/n), HQC=r*np.log(n)**(2*k/n),
                lnAIC=np.log(r)+2*k/n, lnSBC=np.log(r)+k*np.log(n)/n, lnHQC=np.log(r)+2*k*np.log(np.log(n))/n)
cands = [["poverty"], ["single"], ["poverty", "single"], ["poverty", "single", "urban"],
         ["poverty", "single", "urban", "hs_grad"], ["poverty", "single", "urban", "hs_grad", "white"],
         ["single", "urban"]]
ic_rows = []
for vs in cands:
    f = ols(yc, crime[vs].to_numpy()); k = len(vs) + 1; c = crit(f, nc, k)
    ic_rows.append((" + ".join(vs), k, f.ssr, f.rsquared, f.rsquared_adj, c["AIC"], c["FPE"], c["SBC"], c["HQC"], f.aic, f.bic))
    print(f"{' + '.join(vs):40s} k {k} RSS {f.ssr:10.0f} R2 {f.rsquared:.3f} adjR2 {f.rsquared_adj:.3f} "
          f"AIC {c['AIC']:9.1f} FPE {c['FPE']:9.1f} SBC {c['SBC']:9.1f} HQC {c['HQC']:9.1f} | sm aic {f.aic:.2f} bic {f.bic:.2f}")
for j, nm in enumerate(["AIC", "FPE", "SBC", "HQC"]):
    vals = [r[5 + j] for r in ic_rows]; print(f"  {nm} picks: {ic_rows[int(np.argmin(vals))][0]}")
print(f"  adj R2 picks: {ic_rows[int(np.argmax([r[4] for r in ic_rows]))][0]}")
f = ols(yc, crime[["poverty", "single", "urban"]].to_numpy()); c = crit(f, nc, 4)
print(f"log-form check: ln AIC_AH = {np.log(c['AIC']):.5f}, lnAIC {c['lnAIC']:.5f}; "
      f"(sm aic)/n - 1 - ln(2pi) = {f.aic/nc - 1 - np.log(2*np.pi):.5f}")
print(f"  ln SBC_AH = {np.log(c['SBC']):.5f}; (sm bic)/n - 1 - ln(2pi) = {f.bic/nc - 1 - np.log(2*np.pi):.5f}")
print(f"penalty factors at n = {nc}, k = 4: AIC {np.exp(8/nc):.4f}, FPE {(nc+4)/(nc-4):.4f}, SBC {nc**(4/nc):.4f}, HQC {np.log(nc)**(8/nc):.4f}")
for nn3 in [20, 50, 200, 1000]:
    print(f"  per extra regressor, ln-penalty at n={nn3}: AIC {2/nn3:.4f}, SBC {np.log(nn3)/nn3:.4f}, HQC {2*np.log(np.log(nn3))/nn3:.4f}, FPE {np.log((nn3+5)/(nn3-5)) - np.log((nn3+4)/(nn3-4)):.4f}")
# states with largest influence: DC
print("DC row:", crime.loc["District of Columbia", ["violent", "poverty", "single", "urban"]].to_dict())
fnd = ols(yc[crime.index != "District of Columbia"], crime.loc[crime.index != "District of Columbia", base_vars].to_numpy())
print(f"without DC: coef {np.round(fnd.params, 3)}, R2 {fnd.rsquared:.4f}, adj R2 {fnd.rsquared_adj:.4f}")

# ---------------------------------------------------------------
print("\n=== Experiment 8: which criterion finds the true model? (Monte Carlo, nested lag-type models) ===")
rng = np.random.RandomState(67); K = 6; true_k = 3   # const + 2 regressors matter
bt = np.array([1, 0.6, 0.3, 0, 0, 0, 0])[:K + 1]
sel = {}
for nn4 in [30, 100, 500]:
    counts = {m: np.zeros(K + 1, int) for m in ["adjR2", "AIC", "FPE", "HQC", "SBC"]}
    for _ in range(4000):
        Xr = np.column_stack([np.ones(nn4), rng.randn(nn4, K)]); yr = Xr @ bt + rng.randn(nn4)
        res = []
        for p in range(0, K + 1):      # model with constant + first p regressors
            Xp = Xr[:, :p + 1]; bb = np.linalg.lstsq(Xp, yr, rcond=None)[0]; rss = np.sum((yr - Xp @ bb)**2)
            kk = p + 1; r = rss / nn4; tss = np.sum((yr - yr.mean())**2)
            res.append((1 - (rss / (nn4 - kk)) / (tss / (nn4 - 1)), np.log(r) + 2*kk/nn4, np.log(r*(nn4+kk)/(nn4-kk)),
                        np.log(r) + 2*kk*np.log(np.log(nn4))/nn4, np.log(r) + kk*np.log(nn4)/nn4))
        res = np.array(res)
        counts["adjR2"][np.argmax(res[:, 0])] += 1
        for j, m in enumerate(["AIC", "FPE", "HQC", "SBC"], 1): counts[m][np.argmin(res[:, j])] += 1
    sel[nn4] = {m: (v / 4000).tolist() for m, v in counts.items()}
    print(f"n = {nn4}: share choosing p = 0..{K} regressors (truth p = 2)")
    for m, v in counts.items(): print(f"   {m:6s}", np.round(v / 4000, 3), f" under {v[:2].sum()/4000:.3f} correct {v[2]/4000:.3f} over {v[3:].sum()/4000:.3f}")

# ---------------------------------------------------------------
print("\n=== Experiment 9: choosing the lag length in Okun's law (US quarterly) ===")
du = np.diff(macro.unemp.to_numpy()); g = 100 * np.diff(np.log(macro.realgdp.to_numpy()))
P = 4; T = len(du) - P; yo = du[P:]
okun_rows = []
for p in range(0, P + 1):
    Xo = np.column_stack([g[P - j: len(g) - j] for j in range(0, p + 1)]); fo = ols(yo, Xo); k = p + 2; c = crit(fo, T, k)
    okun_rows.append((p, k, fo.ssr, fo.rsquared_adj, c["lnAIC"], c["lnSBC"], c["lnHQC"], np.log(c["FPE"]), fo.params[1:]))
    print(f"lags {p}: k {k} RSS {fo.ssr:.4f} adjR2 {fo.rsquared_adj:.4f} lnAIC {c['lnAIC']:.4f} lnFPE {np.log(c['FPE']):.4f} "
          f"lnHQC {c['lnHQC']:.4f} lnSBC {c['lnSBC']:.4f} coefs {np.round(fo.params[1:], 3)}")
for j, nm in enumerate(["lnAIC", "lnSBC", "lnHQC", "lnFPE"]):
    print(f"  {nm} picks lag {int(np.argmin([r[4 + j] for r in okun_rows]))}")
print(f"  adj R2 picks lag {int(np.argmax([r[3] for r in okun_rows]))}; common sample T = {T}")
f1 = ols(yo, np.column_stack([g[P:], g[P-1:-1]])); print(f"lag-1 model: b0 {f1.params[1]:.3f} b1 {f1.params[2]:.3f}, se {np.round(f1.bse[1:], 3)}, long-run {f1.params[1]+f1.params[2]:.3f}")

# ---------------------------------------------------------------
out = {"sel": sel, "mc_hist": mc_hist.tolist(), "mc_short": mc_short.tolist(),
       "r2path": [(int(a), float(b), float(c)) for a, b, c in r2path],
       "coll": [(float(a), float(b), float(c)) for a, b, c in coll],
       "ic_rows": [(a, int(b), float(c), float(d), float(e), float(f), float(g_), float(h_), float(i_)) for a, b, c, d, e, f, g_, h_, i_, *_ in ic_rows],
       "okun_rows": [(int(r[0]), float(r[2]), float(r[3]), float(r[4]), float(r[5]), float(r[6]), float(r[7])) for r in okun_rows]}
with open("module6_coords.py", "w") as fh: fh.write("import numpy as np\nCOORDS = " + repr(out) + "\n")
print("\n[figure coordinates written to module6_coords.py]")
