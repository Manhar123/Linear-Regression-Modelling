THE MULTIPLE LINEAR REGRESSION MODEL: DERIVING THE ESTIMATORS, THE ASSUMPTIONS, BLUE IN MATRIX FORM,
ADJUSTED R-SQUARED AND CRITERIA FOR CHOOSING A MODEL
Module 6 of the course on Linear Regression Models. Manhar Singh, November 2026. Notes: 38 pages.

FOLDERS
  notes/                 PDF of the notes, LaTeX source, and lrm-notes.sty (keep the .sty next to the .tex to compile).
  overleaf_single_file/  The same notes as one self-contained .tex file (style inlined): paste into Overleaf and compile.
  data/                  grunfeld.csv and macro.csv (from Module 2); statecrime.csv (US state crime data, 51 states,
                         written by this module's Python script from the statsmodels package); and
                         Foundations_Practice_Data.xlsx (student workbook of the Preliminary Module; sheet Households is used).
  code/                  module6_examples.py reproduces every number in the notes (needs numpy, pandas, statsmodels, openpyxl).
                         module6_examples.R (needs readxl) and module6_examples.inp (GRETL) follow the same steps.
                         Copy the four files in data/ into code/ before running any script.
                         module_6_template.tex, module6_coords.py and build_module6.py regenerate the notes' .tex
                         (the figures' plotted points) if you change the data.

COMPILING: pdflatex, run twice (for the table of contents).
This module has no practice workbook of its own and no instructor material.
Reading note: Preliminary Module B (matrix algebra) is meant to be read before this module.
NOTE: the R and GRETL scripts were not run for this edition; please run them once before class.
