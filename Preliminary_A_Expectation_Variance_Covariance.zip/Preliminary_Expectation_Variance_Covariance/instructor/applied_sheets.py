"""Applied problems A1-A6 for Foundations_Practice_Data.xlsx.
Data are synthetic (fixed seeds). In the student file the answer cells are blank and yellow;
with --instructor they contain the solution formulas."""
import numpy as np
from openpyxl.styles import Alignment, PatternFill
from openpyxl.utils import get_column_letter as L

GREEN = PatternFill("solid", fgColor="E2F0D9")


def add_applied(wb, g):
    put, label, header = g["put"], g["label"], g["header"]
    BLUE, BLACK, BOLD, TITLE, NOTE = g["BLUE"], g["BLACK"], g["BOLD"], g["TITLE"], g["NOTE"]
    YELLOW, INSTR = g["YELLOW"], g["INSTRUCTOR"]

    def ans(ws, ref, formula, fmt=None):
        """An answer cell: blank and yellow for students, a formula for the instructor."""
        c = put(ws, ref, formula if INSTR else None, BLACK, fmt, GREEN if INSTR else YELLOW)
        return c

    def title(ws, t, sub):
        ws["A1"] = t; ws["A1"].font = TITLE
        ws["A2"] = sub; ws["A2"].font = NOTE

    def task(ws, ref, text, width=None):
        c = label(ws, ref, text); c.alignment = Alignment(wrap_text=True, vertical="center")
        return c

    # =================================================================
    # A1  Milk stock (expected value of a function)
    ws = wb.create_sheet("A1_Milk_Stock")
    title(ws, "A1  How much milk should a kirana shop stock?",
          "Synthetic example. Daily demand D (litres) is uncertain. Unsold milk spoils and is worth nothing. "
          "Fill in the yellow cells.")
    ws.column_dimensions["A"].width = 46
    for c in "BCDEFGH": ws.column_dimensions[c].width = 12
    header(ws, 4, 1, ["Daily demand d (litres)", "Probability p(d)"])
    dem = [30, 40, 50, 60, 70]; pr = [0.10, 0.20, 0.35, 0.25, 0.10]
    for i, (d, p) in enumerate(zip(dem, pr)):
        put(ws, f"A{5+i}", d, BLUE); put(ws, f"B{5+i}", p, BLUE, "0.00")
    label(ws, "A10", "Total probability"); put(ws, "B10", "=SUM(B5:B9)", fmt="0.00")
    label(ws, "D4", "Inputs", BOLD)
    label(ws, "D5", "Purchase cost per litre (Rs)"); put(ws, "G5", 48, BLUE)
    label(ws, "D6", "Selling price per litre (Rs)"); put(ws, "G6", 60, BLUE)
    label(ws, "D7", "Value of an unsold litre (Rs)"); put(ws, "G7", 0, BLUE)
    for r in (5, 6, 7): ws.merge_cells(f"D{r}:F{r}")

    label(ws, "A12", "Task (a): profit for each demand d and stock level Q", BOLD)
    ws["A13"] = "Profit = price x min(Q, d) + salvage x max(Q - d, 0) - cost x Q"; ws["A13"].font = NOTE
    Qs = [30, 40, 50, 50.5, 60, 70]
    put(ws, "A14", "Demand d  \\  Stock Q", BOLD)
    for j, q in enumerate(Qs): put(ws, f"{L(2+j)}14", q, BLUE)
    for i in range(5):
        r = 15 + i; put(ws, f"A{r}", f"=A{5+i}", BOLD)
        for j in range(len(Qs)):
            col = L(2 + j)
            ans(ws, f"{col}{r}", f"=$G$6*MIN({col}$14,$A{r})+$G$7*MAX({col}$14-$A{r},0)-$G$5*{col}$14", "#,##0")
    ws["E13"] = "Q = 50.5 is the expected demand (task b)."; ws["E13"].font = NOTE
    label(ws, "A21", "Task (a) (cont.): expected profit  E[profit]")
    label(ws, "A22", "Task (a) (cont.): standard deviation of profit")
    for j in range(len(Qs)):
        col = L(2 + j)
        ans(ws, f"{col}21", f"=SUMPRODUCT($B$5:$B$9,{col}15:{col}19)", "#,##0.0")
        ans(ws, f"{col}22", f"=SQRT(SUMPRODUCT($B$5:$B$9,{col}15:{col}19,{col}15:{col}19)-{col}21^2)", "#,##0.0")

    label(ws, "A24", "Tasks (b) to (e)", BOLD)
    items = [
        ("(b) Expected demand E(D)", "=SUMPRODUCT(A5:A9,B5:B9)", "0.0"),
        ("(c) Profit if Q = E(D) and demand is exactly E(D):  g(E[D])", "=(G6-G5)*B25", "#,##0.0"),
        ("(c) Expected profit if Q = E(D):  E[g(D)]", "=E21", "#,##0.0"),
        ("(d) Best stock level among Q = 30, 40, 50, 60, 70", "=INDEX(B14:G14,MATCH(MAX(B21:D21,F21:G21),B21:G21,0))", "0"),
        ("(d) Expected profit at the best Q", "=MAX(B21:D21,F21:G21)", "#,##0.0"),
        ("(e) Critical ratio (price - cost) / (price - salvage)", "=(G6-G5)/(G6-G7)", "0.000"),
    ]
    for k, (t, f, fmt) in enumerate(items):
        r = 25 + k; task(ws, f"A{r}", t); ans(ws, f"B{r}", f, fmt)
    label(ws, "A32", "Decision: how many litres should the shop stock, and why not the expected demand?", BOLD)
    ws.merge_cells("A33:G35"); c = ws["A33"]; c.fill = GREEN if INSTR else YELLOW; c.alignment = Alignment(wrap_text=True, vertical="top")
    if INSTR:
        c.value = ("Stock 40 litres. A litre sold earns Rs 12 but a litre unsold loses Rs 48, so the shop should stock less than "
                   "expected demand: the best Q is the smallest Q with P(D <= Q) >= critical ratio (0.2). "
                   "Profit is not linear in D, so E[g(D)] is below g(E[D]).")
        c.font = BLACK

    # =================================================================
    # A2  Delivery time (variance of a sum with correlated parts)
    ws = wb.create_sheet("A2_Delivery")
    rng = np.random.RandomState(52); n = 300
    prep = np.clip(np.round(rng.normal(15, 4, n), 1), 3, None)
    cov = np.array([[9.0, 0.6 * 3 * 5], [0.6 * 3 * 5, 25.0]])
    rides = rng.multivariate_normal([8, 14], cov, n)
    r1 = np.clip(np.round(rides[:, 0], 1), 1, None); r2 = np.clip(np.round(rides[:, 1], 1), 2, None)
    title(ws, "A2  What delivery time should a food-delivery app promise?",
          "Synthetic data for 300 orders (minutes). The two rides share the same traffic, so they are correlated. "
          "Fill in the yellow cells.")
    header(ws, 4, 1, ["Order", "Kitchen prep (P)", "Ride to restaurant (R1)", "Ride to customer (R2)", "Total T = P+R1+R2"], 13)
    ws.row_dimensions[4].height = 30
    for i in range(n):
        r = 5 + i
        put(ws, f"A{r}", i + 1); put(ws, f"B{r}", float(prep[i]), BLUE, "0.0")
        put(ws, f"C{r}", float(r1[i]), BLUE, "0.0"); put(ws, f"D{r}", float(r2[i]), BLUE, "0.0")
        put(ws, f"E{r}", f"=B{r}+C{r}+D{r}", fmt="0.0")
    P, R1, R2, T = "B5:B304", "C5:C304", "D5:D304", "E5:E304"
    ws.column_dimensions["G"].width = 58; ws.column_dimensions["H"].width = 14
    label(ws, "G4", "Inputs", BOLD)
    label(ws, "G5", "Share of orders allowed to arrive late"); put(ws, "H5", 0.05, BLUE, "0%")
    label(ws, "G6", "Normal critical value for that share (one-sided)"); put(ws, "H6", 1.645, BLUE, "0.000")
    label(ws, "G8", "Tasks", BOLD)
    a2 = [
        ("(a) Mean of P", f"=AVERAGE({P})", "0.00"), ("(a) Mean of R1", f"=AVERAGE({R1})", "0.00"),
        ("(a) Mean of R2", f"=AVERAGE({R2})", "0.00"), ("(a) Mean of T", f"=AVERAGE({T})", "0.00"),
        ("(b) Var(P)", f"=_xlfn.VAR.S({P})", "0.00"), ("(b) Var(R1)", f"=_xlfn.VAR.S({R1})", "0.00"),
        ("(b) Var(R2)", f"=_xlfn.VAR.S({R2})", "0.00"),
        ("(c) Cov(P, R1)", f"=_xlfn.COVARIANCE.S({P},{R1})", "0.00"), ("(c) Cov(P, R2)", f"=_xlfn.COVARIANCE.S({P},{R2})", "0.00"),
        ("(c) Cov(R1, R2)", f"=_xlfn.COVARIANCE.S({R1},{R2})", "0.00"), ("(c) Corr(R1, R2)", f"=CORREL({R1},{R2})", "0.000"),
        ("(d) Var(T), computed directly", f"=_xlfn.VAR.S({T})", "0.00"),
        ("(d) Var(T) ignoring covariances: Var(P)+Var(R1)+Var(R2)", "=H13+H14+H15", "0.00"),
        ("(d) Var(T) with covariances (full formula)", "=H13+H14+H15+2*(H16+H17+H18)", "0.00"),
        ("(e) Promised time, ignoring covariances: mean + z x SD", "=H12+H6*SQRT(H21)", "0.0"),
        ("(e) Promised time, with covariances", "=H12+H6*SQRT(H22)", "0.0"),
        ("(f) Share of orders later than the first promise", f"=COUNTIF({T},\">\"&H23)/COUNT({T})", "0.0%"),
        ("(f) Share of orders later than the second promise", f"=COUNTIF({T},\">\"&H24)/COUNT({T})", "0.0%"),
    ]
    for k, (t, f, fmt) in enumerate(a2):
        r = 9 + k; task(ws, f"G{r}", t); ans(ws, f"H{r}", f, fmt)
    label(ws, "G28", "Decision: which promise should the app show, and what goes wrong with the other?", BOLD)
    ws.merge_cells("G29:H32"); c = ws["G29"]; c.fill = GREEN if INSTR else YELLOW; c.alignment = Alignment(wrap_text=True, vertical="top")
    if INSTR:
        c.value = ("Show the promise that includes the covariance. The two rides move together, so their variances do not "
                   "simply add; ignoring the positive covariance understates the spread of T, and the shorter promise is "
                   "broken more often than the 5% allowed.")
        c.font = BLACK

    # =================================================================
    # A3  Survey design (variance of a mean, design effect)
    ws = wb.create_sheet("A3_Survey_Design")
    title(ws, "A3  How many households must a consumption survey visit?",
          "Uses the spread of consumption in the Households sheet. Households in the same village tend to be alike "
          "(intra-cluster correlation). Fill in the yellow cells.")
    ws.column_dimensions["A"].width = 70; ws.column_dimensions["B"].width = 14
    for c in "CDEFG": ws.column_dimensions[c].width = 11
    label(ws, "A4", "Inputs", BOLD)
    inputs = [
        ("SD of monthly consumption, from the Households sheet (Rs)", "=_xlfn.STDEV.S(Households!G5:G204)", "#,##0.0", BLACK),
        ("Desired margin of error, + or - (Rs)", 500, "#,##0", BLUE),
        ("Confidence: normal critical value (95% -> 1.96)", 1.96, "0.00", BLUE),
        ("Households interviewed per village (cluster size m)", 10, "0", BLUE),
        ("Intra-cluster correlation (rho)", 0.2, "0.00", BLUE),
        ("Current sample size", 200, "0", BLUE),
    ]
    for k, (t, v, fmt, f) in enumerate(inputs):
        r = 5 + k; label(ws, f"A{r}", t); put(ws, f"B{r}", v, f, fmt)
    label(ws, "A12", "Tasks", BOLD)
    a3 = [
        ("(a) Standard error of the mean with the current sample (simple random sampling)", "=B5/SQRT(B10)", "#,##0.0"),
        ("(b) Margin of error with the current sample", "=B7*B13", "#,##0.0"),
        ("(c) Sample size needed for the desired margin, simple random sampling: (z SD / E)^2, rounded up", "=ROUNDUP((B7*B5/B6)^2,0)", "#,##0"),
        ("(d) Design effect for cluster sampling: 1 + (m - 1) rho", "=1+(B8-1)*B9", "0.00"),
        ("(e) Sample size needed with cluster sampling", "=ROUNDUP(B15*B16,0)", "#,##0"),
        ("(e) Number of villages to visit", "=ROUNDUP(B17/B8,0)", "#,##0"),
        ("(f) Sample size needed to halve the desired margin (simple random sampling)", "=ROUNDUP((B7*B5/(B6/2))^2,0)", "#,##0"),
    ]
    for k, (t, f, fmt) in enumerate(a3):
        r = 13 + k; task(ws, f"A{r}", t); ans(ws, f"B{r}", f, fmt)
    label(ws, "A21", "Task (g): sample size needed (clustered) for different intra-cluster correlations", BOLD)
    rhos = [0, 0.05, 0.1, 0.2, 0.3]
    put(ws, "A22", "rho", BOLD); put(ws, "A23", "Households needed", BOLD); put(ws, "A24", "Villages needed", BOLD)
    for j, rho in enumerate(rhos):
        col = L(2 + j); put(ws, f"{col}22", rho, BLUE, "0.00")
        ans(ws, f"{col}23", f"=ROUNDUP($B$15*(1+($B$8-1)*{col}22),0)", "#,##0")
        ans(ws, f"{col}24", f"=ROUNDUP({col}23/$B$8,0)", "#,##0")
    label(ws, "A26", "Decision: what sample would you recommend, and why is 'just divide by n' not enough?", BOLD)
    ws.merge_cells("A27:F30"); c = ws["A27"]; c.fill = GREEN if INSTR else YELLOW; c.alignment = Alignment(wrap_text=True, vertical="top")
    if INSTR:
        c.value = ("About 630 households would do under simple random sampling, but households in a village are correlated, so "
                   "each extra household adds less information. With 10 per village and rho = 0.2 the design effect is 2.8: "
                   "visit about 1,770 households in 177 villages. Var(mean) = sigma^2/n assumes zero covariance between households.")
        c.font = BLACK

    # =================================================================
    # A4  Two examiners (averaging correlated measurements)
    ws = wb.create_sheet("A4_Two_Examiners")
    rng = np.random.RandomState(74); n = 120
    true = np.clip(np.round(rng.normal(60, 12, n)), 15, 98)
    shared = rng.normal(0, 4, n)
    mA = np.clip(np.round(true + shared + rng.normal(0, 3, n)), 0, 100)
    mB = np.clip(np.round(true + shared + rng.normal(0, 3, n)), 0, 100)
    title(ws, "A4  Is a second (or third) examiner worth it?",
          "Synthetic marks for 120 answer scripts. The 'moderated mark' is treated as the true mark. Both examiners are "
          "swayed by the same features of a script, so their errors are correlated. Fill in the yellow cells.")
    header(ws, 4, 1, ["Script", "Moderated (true) mark", "Examiner A", "Examiner B", "Error A = A - true",
                      "Error B = B - true", "Average of A and B", "Error of average"], 12)
    ws.row_dimensions[4].height = 30
    for i in range(n):
        r = 5 + i
        put(ws, f"A{r}", i + 1); put(ws, f"B{r}", int(true[i]), BLUE); put(ws, f"C{r}", int(mA[i]), BLUE); put(ws, f"D{r}", int(mB[i]), BLUE)
        put(ws, f"E{r}", f"=C{r}-B{r}"); put(ws, f"F{r}", f"=D{r}-B{r}")
        put(ws, f"G{r}", f"=(C{r}+D{r})/2", fmt="0.0"); put(ws, f"H{r}", f"=G{r}-B{r}", fmt="0.0")
    EA, EB, EV = "E5:E124", "F5:F124", "H5:H124"
    ws.column_dimensions["J"].width = 62; ws.column_dimensions["K"].width = 13
    label(ws, "J4", "Tasks", BOLD)
    a4 = [
        ("(a) Var(error A)", f"=_xlfn.VAR.S({EA})", "0.00"),
        ("(a) Var(error B)", f"=_xlfn.VAR.S({EB})", "0.00"),
        ("(b) Cov(error A, error B)", f"=_xlfn.COVARIANCE.S({EA},{EB})", "0.00"),
        ("(b) Corr(error A, error B)", f"=CORREL({EA},{EB})", "0.000"),
        ("(c) Var(error of average), computed directly", f"=_xlfn.VAR.S({EV})", "0.00"),
        ("(c) Var(error of average) by formula: [Var(A) + Var(B) + 2 Cov] / 4", "=(K5+K6+2*K7)/4", "0.00"),
        ("(d) Var(error of average) if the errors were uncorrelated: [Var(A) + Var(B)] / 4", "=(K5+K6)/4", "0.00"),
        ("(e) Reduction in error variance from one examiner to two (use the average of K5 and K6)", "=1-K10/AVERAGE(K5:K6)", "0.0%"),
    ]
    for k, (t, f, fmt) in enumerate(a4):
        r = 5 + k; task(ws, f"J{r}", t); ans(ws, f"K{r}", f, fmt)
    label(ws, "J14", "Task (f): k examiners with error variance s^2 and correlation rho: Var = s^2 (1 + (k-1) rho) / k", BOLD)
    put(ws, "J15", "s^2 = average of the two error variances"); ans(ws, "K15", "=AVERAGE(K5:K6)", "0.00")
    put(ws, "J16", "rho = correlation of the errors"); ans(ws, "K16", "=K8", "0.000")
    header(ws, 18, 10, ["Number of examiners k", "Error variance of average"])
    for k in range(1, 7):
        r = 18 + k; put(ws, f"J{r}", k if k < 6 else "Limit as k grows: rho x s^2", BLUE if k < 6 else BOLD)
        ans(ws, f"K{r}", f"=$K$15*(1+(J{r}-1)*$K$16)/J{r}" if k < 6 else "=K16*K15", "0.00")
    label(ws, "J26", "(g) Reduction from two examiners to three", BOLD); ans(ws, "K26", "=1-K21/K20", "0.0%")
    label(ws, "J28", "Decision: should the board pay for a third examiner? Why is the gain so limited?", BOLD)
    ws.merge_cells("J29:K32"); c = ws["J29"]; c.fill = GREEN if INSTR else YELLOW; c.alignment = Alignment(wrap_text=True, vertical="top")
    if INSTR:
        c.value = ("Probably not. Errors are positively correlated because both examiners react to the same features of a "
                   "script, so averaging removes only the independent part of the error. The shared part (rho x s^2) "
                   "never averages away, however many examiners are added.")
        c.font = BLACK

    # =================================================================
    # A5  Inflation basket (variance of a weighted sum)
    ws = wb.create_sheet("A5_Inflation_Basket")
    rng = np.random.RandomState(85); n = 72
    sd = np.array([3.0, 4.0, 1.0]); corr = np.array([[1, .3, .2], [.3, 1, .35], [.2, .35, 1]])
    infl = np.round(rng.multivariate_normal([5.0, 6.0, 5.0], corr * np.outer(sd, sd), n), 2)
    title(ws, "A5  Where does the volatility of headline inflation come from?",
          "Synthetic monthly year-on-year inflation rates (per cent) for three groups. Weights are close to India's "
          "CPI (Combined, base 2012) group weights. Fill in the yellow cells.")
    header(ws, 4, 1, ["Month", "Food & beverages", "Fuel & light", "Core (all else)", "Headline"], 13)
    ws.row_dimensions[4].height = 30
    label(ws, "G4", "Weights", BOLD); put(ws, "H4", "Food", BOLD); put(ws, "I4", "Fuel", BOLD); put(ws, "J4", "Core", BOLD)
    put(ws, "H5", 0.4586, BLUE, "0.0000"); put(ws, "I5", 0.0684, BLUE, "0.0000"); put(ws, "J5", "=1-H5-I5", fmt="0.0000")
    ws["G6"] = "Food and beverages 45.86%, fuel and light 6.84% (CPI base 2012); core is the remainder."; ws["G6"].font = NOTE
    for i in range(n):
        r = 5 + i
        put(ws, f"A{r}", f"M{i+1:02d}"); put(ws, f"B{r}", float(infl[i, 0]), BLUE, "0.00")
        put(ws, f"C{r}", float(infl[i, 1]), BLUE, "0.00"); put(ws, f"D{r}", float(infl[i, 2]), BLUE, "0.00")
        put(ws, f"E{r}", f"=$H$5*B{r}+$I$5*C{r}+$J$5*D{r}", fmt="0.00")
    rngs = {"B": "B5:B76", "C": "C5:C76", "D": "D5:D76"}
    for c in "GHIJK": ws.column_dimensions[c].width = 14
    ws.column_dimensions["G"].width = 52
    label(ws, "G8", "Task (a): covariance matrix of the three groups (COVARIANCE.S)", BOLD)
    put(ws, "H9", "Food", BOLD); put(ws, "I9", "Fuel", BOLD); put(ws, "J9", "Core", BOLD)
    names = ["Food", "Fuel", "Core"]; cols = ["B", "C", "D"]
    for i in range(3):
        r = 10 + i; label(ws, f"G{r}", names[i])
        for j in range(3):
            ans(ws, f"{L(8+j)}{r}", f"=_xlfn.COVARIANCE.S({rngs[cols[i]]},{rngs[cols[j]]})", "0.000")
    label(ws, "G14", "Task (b): each term w_i w_j Cov(i, j) of Var(headline)", BOLD)
    put(ws, "H15", "Food", BOLD); put(ws, "I15", "Fuel", BOLD); put(ws, "J15", "Core", BOLD)
    wref = ["$H$5", "$I$5", "$J$5"]
    for i in range(3):
        r = 16 + i; label(ws, f"G{r}", names[i])
        for j in range(3):
            ans(ws, f"{L(8+j)}{r}", f"={wref[i]}*{wref[j]}*{L(8+j)}{10+i}", "0.0000")
    label(ws, "G20", "Tasks", BOLD)
    a5 = [
        ("(c) Var(headline) = sum of all nine terms", "=SUM(H16:J18)", "0.000"),
        ("(c) Var(headline), computed directly from column E", "=_xlfn.VAR.S(E5:E76)", "0.000"),
        ("(d) SD of headline", "=SQRT(H21)", "0.000"),
        ("(d) Weighted average of the three SDs", "=H5*SQRT(H10)+I5*SQRT(I11)+J5*SQRT(J12)", "0.000"),
        ("(e) Share of Var(headline) from the food variance term", "=H16/H21", "0.0%"),
        ("(e) Share from the fuel variance term", "=I17/H21", "0.0%"),
        ("(e) Share from the core variance term", "=J18/H21", "0.0%"),
        ("(e) Share from all covariance terms together", "=(SUM(H16:J18)-H16-I17-J18)/H21", "0.0%"),
        ("(e) For comparison: weight of core in the index", "=J5", "0.0%"),
    ]
    for k, (t, f, fmt) in enumerate(a5):
        r = 21 + k; task(ws, f"G{r}", t); ans(ws, f"H{r}", f, fmt)
    label(ws, "G31", "Decision: which group should a forecaster watch most closely for headline volatility, and why does core contribute so little despite its weight?", BOLD)
    ws["G31"].alignment = Alignment(wrap_text=True); ws.row_dimensions[31].height = 30
    ws.merge_cells("G32:J35"); c = ws["G32"]; c.fill = GREEN if INSTR else YELLOW; c.alignment = Alignment(wrap_text=True, vertical="top")
    if INSTR:
        c.value = ("Food. Its weight is large and it is volatile, and a variance term scales with the weight squared times the "
                   "variance. Core has an even larger weight but is very stable, so its term is small. Fuel has a small weight, "
                   "so even a volatile fuel series adds little except through its covariance with food.")
        c.font = BLACK

    # =================================================================
    # A6  Age and earnings (dependence without correlation)
    ws = wb.create_sheet("A6_Age_Earnings")
    rng = np.random.RandomState(96); n = 250
    age = np.sort(rng.randint(25, 66, n))
    earn = np.round(5000 + 1800 * age - 20 * age**2 + rng.normal(0, 4000, n), -1)
    title(ws, "A6  Does age matter for earnings if the correlation is near zero?",
          "Synthetic monthly earnings (Rs) for 250 workers aged 25-65, sorted by age. Fill in the yellow cells.")
    header(ws, 4, 1, ["Worker", "Age", "Earnings (Rs/month)", "(Age - 45)^2"], 14)
    for i in range(n):
        r = 5 + i
        put(ws, f"A{r}", i + 1); put(ws, f"B{r}", int(age[i]), BLUE); put(ws, f"C{r}", float(earn[i]), BLUE, "#,##0")
        ans(ws, f"D{r}", f"=(B{r}-45)^2", "0")
    split = int(np.searchsorted(age, 46))      # first row index with age > 45
    last_young = 4 + split; first_old = last_young + 1
    A_, E_, D_ = "B5:B254", "C5:C254", "D5:D254"
    ws.column_dimensions["F"].width = 64; ws.column_dimensions["G"].width = 14
    label(ws, "F4", "Tasks", BOLD)
    a6 = [
        ("(a) Corr(age, earnings)", f"=CORREL({A_},{E_})", "0.000"),
        ("(a) Slope of earnings on age (SLOPE), Rs per year", f"=SLOPE({E_},{A_})", "#,##0.0"),
        ("(b) Mean earnings, ages 25-34", f'=AVERAGEIFS({E_},{A_},">=25",{A_},"<=34")', "#,##0"),
        ("(b) Mean earnings, ages 35-44", f'=AVERAGEIFS({E_},{A_},">=35",{A_},"<=44")', "#,##0"),
        ("(b) Mean earnings, ages 45-54", f'=AVERAGEIFS({E_},{A_},">=45",{A_},"<=54")', "#,##0"),
        ("(b) Mean earnings, ages 55-65", f'=AVERAGEIFS({E_},{A_},">=55",{A_},"<=65")', "#,##0"),
        (f"(c) Corr(age, earnings) for workers aged 45 or under (rows 5-{last_young})", f"=CORREL(B5:B{last_young},C5:C{last_young})", "0.000"),
        (f"(c) Corr(age, earnings) for workers over 45 (rows {first_old}-254)", f"=CORREL(B{first_old}:B254,C{first_old}:C254)", "0.000"),
        ("(d) Corr((age - 45)^2, earnings)", f"=CORREL({D_},{E_})", "0.000"),
    ]
    for k, (t, f, fmt) in enumerate(a6):
        r = 5 + k; task(ws, f"F{r}", t); ans(ws, f"G{r}", f, fmt)
    label(ws, "F15", "Decision: a bank says age is irrelevant to earnings because the correlation is near zero. What is wrong with the argument?", BOLD)
    ws["F15"].alignment = Alignment(wrap_text=True); ws.row_dimensions[15].height = 30
    ws.merge_cells("F16:G19"); c = ws["F16"]; c.fill = GREEN if INSTR else YELLOW; c.alignment = Alignment(wrap_text=True, vertical="top")
    if INSTR:
        c.value = ("Correlation measures only straight-line association. Earnings rise with age until about 45 and then fall, "
                   "so the two halves cancel. Mean earnings differ sharply across age groups and the correlation with "
                   "(age - 45)^2 is strongly negative. A straight-line regression would miss this (see Module 17).")
        c.font = BLACK
    return wb
