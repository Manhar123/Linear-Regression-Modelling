# Applied problems A1-A6 of the Preliminary Module: full solutions in R.
# Reads the student workbook with readxl. Results match the instructor answer key
# (the A3 simulation gives the same pattern with different decimals).

library(readxl)
book <- "Foundations_Practice_Data.xlsx"

cat("=== A1: milk stock ===\n")
d <- c(30, 40, 50, 60, 70); p <- c(.10, .20, .35, .25, .10); cost <- 48; price <- 60; salv <- 0
ED <- sum(d * p); profit <- function(Q, dd) price * pmin(Q, dd) + salv * pmax(Q - dd, 0) - cost * Q
cat("E(D) =", ED, " naive g(E[D]) =", (price - cost) * ED, "\n")
for (Q in c(30, 40, 50, ED, 60, 70)) {
  g <- profit(Q, d); m <- sum(g * p); s <- sqrt(sum(g^2 * p) - m^2)
  cat(sprintf("Q = %5.1f: E[profit] %7.1f, SD %6.1f\n", Q, m, s))
}
cat("critical ratio", (price - cost) / (price - salv), " cumulative P:", cumsum(p), "\n")

cat("\n=== A2: delivery time ===\n")
t <- read_excel(book, sheet = "A2_Delivery", range = "A4:D304"); names(t) <- c("order", "P", "R1", "R2")
TT <- t$P + t$R1 + t$R2; V <- cov(t[, c("P", "R1", "R2")])
print(round(colMeans(t[, c("P", "R1", "R2")]), 2)); print(round(V, 2)); cat("Corr(R1,R2)", cor(t$R1, t$R2), "\n")
v_nocov <- sum(diag(V)); v_full <- sum(V)        # sum of all entries = variances + 2 x covariances
cat("Var(T): direct", var(TT), " ignoring cov", v_nocov, " full", v_full, "\n")
for (v in c(v_nocov, v_full)) { prom <- mean(TT) + 1.645 * sqrt(v); cat("promise", round(prom, 1), "late share", mean(TT > prom), "\n") }

cat("\n=== A3: survey design ===\n")
h <- read_excel(book, sheet = "Households", range = "A4:G204"); sdC <- sd(h[[7]])
z <- 1.96; E <- 500; m <- 10; rho <- 0.2; n0 <- 200
n_srs <- ceiling((z * sdC / E)^2); deff <- 1 + (m - 1) * rho; n_cl <- ceiling(n_srs * deff)
print(c(sd = sdC, se = sdC / sqrt(n0), margin = z * sdC / sqrt(n0), n_srs = n_srs, deff = deff,
        n_cluster = n_cl, villages = ceiling(n_cl / m), n_half = ceiling((z * sdC / (E / 2))^2)))
for (r in c(0, .05, .1, .2, .3)) { nn <- ceiling(n_srs * (1 + (m - 1) * r)); cat("rho", r, ":", nn, "households,", ceiling(nn / m), "villages\n") }
set.seed(13); vill <- 63
for (r in c(0, 0.2)) {
  means <- replicate(20000, mean(matrix(rnorm(vill) * sqrt(r), vill, m) + matrix(rnorm(vill * m) * sqrt(1 - r), vill, m)))
  cat("simulation rho", r, ": Var(mean) x n =", var(means) * vill * m, " formula", 1 + (m - 1) * r, "\n")
}

cat("\n=== A4: two examiners ===\n")
x <- read_excel(book, sheet = "A4_Two_Examiners", range = "A4:D124"); names(x) <- c("s", "true", "A", "B")
eA <- x$A - x$true; eB <- x$B - x$true; eAvg <- (x$A + x$B) / 2 - x$true
vA <- var(eA); vB <- var(eB); cAB <- cov(eA, eB)
print(c(vA = vA, vB = vB, cov = cAB, corr = cor(eA, eB), var_avg = var(eAvg), formula = (vA + vB + 2 * cAB) / 4,
        uncorrelated = (vA + vB) / 4, reduction_1_2 = 1 - (vA + vB + 2 * cAB) / 4 / mean(c(vA, vB))))
s2 <- mean(c(vA, vB)); r <- cor(eA, eB); vk <- sapply(1:5, function(k) s2 * (1 + (k - 1) * r) / k)
print(round(vk, 2)); cat("limit", r * s2, " reduction 2->3", 1 - vk[3] / vk[2], "\n")

cat("\n=== A5: inflation basket ===\n")
f <- read_excel(book, sheet = "A5_Inflation_Basket", range = "A4:D76"); names(f) <- c("m", "food", "fuel", "core")
w <- c(0.4586, 0.0684, 1 - 0.4586 - 0.0684); S <- cov(f[, 2:4]); terms <- outer(w, w) * S; vh <- sum(terms)
print(round(S, 3)); print(round(terms, 4))
head_infl <- as.matrix(f[, 2:4]) %*% w
print(c(var_terms = vh, var_direct = var(as.vector(head_infl)), sd = sqrt(vh), weighted_sd = sum(w * sqrt(diag(S))),
        share_food = terms[1, 1] / vh, share_fuel = terms[2, 2] / vh, share_core = terms[3, 3] / vh,
        share_cov = (vh - sum(diag(terms))) / vh))

cat("\n=== A6: age and earnings ===\n")
a <- read_excel(book, sheet = "A6_Age_Earnings", range = "A4:C254"); names(a) <- c("w", "age", "earn")
cat("Corr", cor(a$age, a$earn), " slope", coef(lm(earn ~ age, data = a))[2], "\n")
print(tapply(a$earn, cut(a$age, c(24, 34, 44, 54, 65)), mean))
young <- a$age <= 45
cat("Corr <=45", cor(a$age[young], a$earn[young]), " >45", cor(a$age[!young], a$earn[!young]),
    " Corr((age-45)^2, earnings)", cor((a$age - 45)^2, a$earn), "\n")
