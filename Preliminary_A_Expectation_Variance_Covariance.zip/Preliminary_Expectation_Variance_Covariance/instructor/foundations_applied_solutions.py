"""Applied problems A1-A6 of the Preliminary Module: full solutions.
Reads the student workbook (data only) and solves every task independently of the Excel formulas.
Run:  python foundations_applied_solutions.py
"""
import numpy as np
import pandas as pd

BOOK = "Foundations_Practice_Data.xlsx"
rd = lambda sheet, cols, skip=3, n=None: pd.read_excel(BOOK, sheet_name=sheet, header=skip, usecols=cols, nrows=n)

# ---------------------------------------------------------------
print("=== A1: milk stock ===")
d = np.array([30, 40, 50, 60, 70.]); p = np.array([.10, .20, .35, .25, .10])
cost, price, salv = 48, 60, 0
ED = d @ p
def profit(Q, dd): return price * np.minimum(Q, dd) + salv * np.maximum(Q - dd, 0) - cost * Q
print(f"E(D) = {ED:.1f}; naive g(E[D]) = {(price - cost) * ED:.1f}")
for Q in [30, 40, 50, ED, 60, 70]:
    g = profit(Q, d); m = g @ p; s = np.sqrt((g**2) @ p - m**2)
    print(f"Q = {Q:5.1f}: profits by demand {g.astype(int)}, E[profit] {m:7.1f}, SD {s:6.1f}")
print(f"critical ratio {(price - cost) / (price - salv):.3f}; cumulative P(D<=d) {np.cumsum(p)}")

# ---------------------------------------------------------------
print("\n=== A2: delivery time ===")
t = rd("A2_Delivery", "A:D", n=300); t.columns = ["order", "P", "R1", "R2"]
T = t.P + t.R1 + t.R2
V = t[["P", "R1", "R2"]].cov()
print("means", t[["P", "R1", "R2"]].mean().round(2).tolist(), "mean T", round(T.mean(), 2))
print("covariance matrix\n", V.round(2))
print(f"Corr(R1,R2) {t.R1.corr(t.R2):.3f}")
v_direct, v_nocov = T.var(), V.values.diagonal().sum()
v_full = v_nocov + 2 * (V.loc["P", "R1"] + V.loc["P", "R2"] + V.loc["R1", "R2"])
print(f"Var(T): direct {v_direct:.2f}, ignoring cov {v_nocov:.2f}, full {v_full:.2f}")
for name, v in [("ignoring cov", v_nocov), ("with cov", v_full)]:
    prom = T.mean() + 1.645 * np.sqrt(v)
    print(f"promise {name}: {prom:.1f} min; share late {np.mean(T > prom):.3f}")

# ---------------------------------------------------------------
print("\n=== A3: survey design ===")
h = rd("Households", "A:G"); sd = h.iloc[:, 6].std()
z, E, m, rho, n0 = 1.96, 500, 10, 0.2, 200
se = sd / np.sqrt(n0); n_srs = int(np.ceil((z * sd / E) ** 2)); deff = 1 + (m - 1) * rho
n_cl = int(np.ceil(n_srs * deff))
print(f"SD {sd:.1f}; SE(n=200) {se:.1f}; margin {z*se:.1f}; n SRS {n_srs}; deff {deff:.2f}; n clustered {n_cl}; "
      f"villages {int(np.ceil(n_cl/m))}; n to halve margin {int(np.ceil((z*sd/(E/2))**2))}")
for r in [0, .05, .1, .2, .3]:
    nn = int(np.ceil(n_srs * (1 + (m - 1) * r))); print(f"  rho {r:.2f}: households {nn}, villages {int(np.ceil(nn/m))}")
# simulation: does the design effect formula hold?
rng = np.random.RandomState(13); reps, vill = 20000, 63
for r in [0.0, 0.2]:
    means = []
    for _ in range(reps):
        a = rng.randn(vill, 1) * np.sqrt(r); e = rng.randn(vill, m) * np.sqrt(1 - r)
        means.append((a + e).mean())
    print(f"  simulation, rho {r}: Var(mean of {vill*m}) {np.var(means):.5f}; 1/n {1/(vill*m):.5f}; "
          f"ratio {np.var(means)*vill*m:.2f} (formula {1+(m-1)*r:.2f})")

# ---------------------------------------------------------------
print("\n=== A4: two examiners ===")
x = rd("A4_Two_Examiners", "A:D", n=120); x.columns = ["s", "true", "A", "B"]
eA, eB = x.A - x.true, x.B - x.true; eAvg = (x.A + x.B) / 2 - x.true
vA, vB, c = eA.var(), eB.var(), np.cov(eA, eB)[0, 1]
print(f"Var eA {vA:.2f}, Var eB {vB:.2f}, Cov {c:.2f}, Corr {eA.corr(eB):.3f}")
print(f"Var avg: direct {eAvg.var():.2f}, formula {(vA+vB+2*c)/4:.2f}, if uncorrelated {(vA+vB)/4:.2f}; "
      f"reduction 1->2 {1-(vA+vB+2*c)/4/np.mean([vA,vB]):.3f}")
s2, r = np.mean([vA, vB]), eA.corr(eB)
vk = {k: s2 * (1 + (k - 1) * r) / k for k in range(1, 6)}
print("by k:", {k: round(v, 2) for k, v in vk.items()}, "limit", round(r * s2, 2), "reduction 2->3", round(1 - vk[3]/vk[2], 3))

# ---------------------------------------------------------------
print("\n=== A5: inflation basket ===")
f = rd("A5_Inflation_Basket", "A:D", n=72); f.columns = ["m", "food", "fuel", "core"]
w = np.array([0.4586, 0.0684, 1 - 0.4586 - 0.0684])
S = f[["food", "fuel", "core"]].cov().values
head = f[["food", "fuel", "core"]].values @ w
terms = np.outer(w, w) * S; vh = terms.sum()
print("covariance matrix\n", np.round(S, 3))
print(f"Var(headline): terms {vh:.3f}, direct {np.var(head, ddof=1):.3f}; SD {np.sqrt(vh):.3f}; "
      f"weighted SDs {w @ np.sqrt(np.diag(S)):.3f}")
print(f"shares: food {terms[0,0]/vh:.3f}, fuel {terms[1,1]/vh:.3f}, core {terms[2,2]/vh:.3f}, "
      f"covariances {(vh-np.trace(terms))/vh:.3f}")
print("terms matrix\n", np.round(terms, 4))

# ---------------------------------------------------------------
print("\n=== A6: age and earnings ===")
a = rd("A6_Age_Earnings", "A:C", n=250); a.columns = ["w", "age", "earn"]
print(f"Corr {a.age.corr(a.earn):.3f}; slope {np.cov(a.age, a.earn)[0,1]/a.age.var():.1f}")
for lo, hi in [(25, 34), (35, 44), (45, 54), (55, 65)]:
    print(f"  ages {lo}-{hi}: mean earnings {a.earn[(a.age >= lo) & (a.age <= hi)].mean():.0f}")
y, o = a[a.age <= 45], a[a.age > 45]
print(f"Corr <=45 {y.age.corr(y.earn):.3f} (n {len(y)}); >45 {o.age.corr(o.earn):.3f} (n {len(o)}); "
      f"Corr((age-45)^2, earnings) {((a.age-45)**2).corr(a.earn):.3f}")
