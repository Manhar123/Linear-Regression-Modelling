# Preliminary Module -- Expectation, Variance and Covariance
# R companion to foundations_examples.py. Reads Foundations_Practice_Data.xlsx with readxl.
# Results computed from the workbook match the notes; simulations give the same pattern, different decimals.

library(readxl)   # install.packages("readxl") if needed
book <- "Foundations_Practice_Data.xlsx"

cat("=== Experiment 1: a joint distribution ===\n")
x <- c(8, 12, 16); y <- c(10, 20, 30, 40)
P <- as.matrix(read_excel(book, sheet = "Joint_Distribution", range = "B6:E8", col_names = FALSE))
px <- rowSums(P); py <- colSums(P)
EX <- sum(x * px); EY <- sum(y * py); VX <- sum(x^2 * px) - EX^2; VY <- sum(y^2 * py) - EY^2
EXY <- sum(outer(x, y) * P); covXY <- EXY - EX * EY
print(c(EX = EX, EY = EY, VX = VX, VY = VY, EXY = EXY, cov = covXY, corr = covXY / sqrt(VX * VY)))
cond <- P / px; EYgX <- as.vector(cond %*% y); VYgX <- as.vector(cond %*% y^2) - EYgX^2
print(rbind(EYgX, VYgX))
cat("iterated expectations:", sum(EYgX * px), " total variance:", sum(VYgX * px) + sum(EYgX^2 * px) - EY^2, "\n")
cat("max |p(x,y) - p(x)p(y)|:", max(abs(P - outer(px, py))), "\n")

cat("\n=== Experiment 2: two dice ===\n")
d <- read_excel(book, sheet = "Two_Dice", skip = 3)[, 1:3]; names(d) <- c("roll", "d1", "d2")
d1 <- d$d1; d2 <- d$d2
print(c(mean1 = mean(d1), mean2 = mean(d2), mean_sum = mean(d1 + d2), var1 = var(d1), var2 = var(d2),
        cov = cov(d1, d2), var_sum = var(d1 + d2), formula = var(d1) + var(d2) + 2 * cov(d1, d2),
        mean_prod = mean(d1 * d2), prod_means = mean(d1) * mean(d2)))

cat("\n=== Experiment 3: households ===\n")
h <- read_excel(book, sheet = "Households", skip = 3)[, 1:7]
names(h) <- c("id", "region", "urban", "size", "educ", "income", "cons")
I <- h$income; C <- h$cons; S <- I - C; n <- length(I)
print(c(mean_I = mean(I), median_I = median(I), mean_C = mean(C), var_I_n1 = var(I), var_I_n = var(I) * (n - 1) / n,
        sd_I = sd(I), var_C = var(C), cov_IC = cov(I, C), corr_IC = cor(I, C)))
print(c(mean_k = mean(I / 1000), var_k = var(I / 1000)))
print(c(var_S = var(S), formula = var(I) + var(C) - 2 * cov(I, C), ignoring_cov = var(I) + var(C)))
pu <- mean(h$urban); cu <- mean(C[h$urban == 1]); cr <- mean(C[h$urban == 0])
print(c(p_urban = pu, E_C_urban = cu, E_C_rural = cr, iterated = pu * cu + (1 - pu) * cr, E_C = mean(C)))
b <- cov(I, C) / var(I); print(c(slope = b, intercept = mean(C) - b * mean(I))); print(coef(lm(C ~ I)))
print(c(formula = 4 * var(I) + 9 * var(C) + 12 * cov(I, C), direct = var(2 * I + 3 * C)))

cat("\n=== Experiment 4: dependence without correlation ===\n")
z <- read_excel(book, sheet = "Zero_Correlation", skip = 3)$X
print(c(corr_X_X2 = cor(z, z^2), corr_absX_X2 = cor(abs(z), z^2)))

cat("\n=== Experiment 5: portfolio ===\n")
p <- read_excel(book, sheet = "Portfolio", skip = 3)[, 1:3]; A <- p[[2]]; B <- p[[3]]
vA <- var(A); vB <- var(B); cAB <- cov(A, B)
for (w in c(0.5, (vB - cAB) / (vA + vB - 2 * cAB), 1, 0)) {
  vp <- w^2 * vA + (1 - w)^2 * vB + 2 * w * (1 - w) * cAB
  cat(sprintf("w = %.4f: formula %.3f, direct %.3f, SD %.3f, weighted SD %.3f\n",
              w, vp, var(w * A + (1 - w) * B), sqrt(vp), w * sqrt(vA) + (1 - w) * sqrt(vB)))
}

cat("\n=== Experiment 6: why divide by n - 1 ===\n")
set.seed(5)
for (m in c(2, 5, 30)) {
  s2 <- replicate(1e5, var(sample(1:6, m, TRUE)))
  cat(sprintf("m = %2d: n-1 version %.4f, n version %.4f, truth %.4f\n", m, mean(s2), mean(s2 * (m - 1) / m), 35 / 12))
}

cat("\n=== Experiment 7: Var(mean) = sigma^2 / n ===\n")
set.seed(6)
for (m in c(1, 4, 16, 64)) {
  v <- var(rowMeans(matrix(sample(1:6, 5e4 * m, TRUE), ncol = m)))
  cat(sprintf("n = %2d: Var(mean) %.4f, sigma^2/n %.4f\n", m, v, 35 / 12 / m))
}

cat("\n=== Experiment 8: correlated observations ===\n")
set.seed(8); m <- 16
for (r in c(0, 0.6)) {
  u <- matrix(0, 5e4, m); e <- matrix(rnorm(5e4 * m), 5e4, m); u[, 1] <- e[, 1]
  for (t in 2:m) u[, t] <- r * u[, t - 1] + sqrt(1 - r^2) * e[, t]
  cat(sprintf("rho = %.1f: Var(mean of 16) %.4f vs naive %.4f\n", r, var(rowMeans(u)), 1 / m))
}
