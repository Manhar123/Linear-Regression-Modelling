"""Preliminary Module -- Expectation, Variance and Covariance.
Every number printed in the notes is produced by this script, from Foundations_Practice_Data.xlsx.
Run from top to bottom:  python foundations_examples.py
"""
import numpy as np
import pandas as pd

BOOK = "Foundations_Practice_Data.xlsx"

# ---------------------------------------------------------------
print("=== Experiment 1: a joint distribution ===")
x = np.array([8, 12, 16]); y = np.array([10, 20, 30, 40])
P = pd.read_excel(BOOK, sheet_name="Joint_Distribution", header=None, usecols="B:E", skiprows=5, nrows=3).to_numpy()
px, py = P.sum(axis=1), P.sum(axis=0)
EX, EY = x @ px, y @ py
VX, VY = (x**2) @ px - EX**2, (y**2) @ py - EY**2
EXY = x @ P @ y; cov = EXY - EX * EY
print(f"p(x) = {px}, p(y) = {py}, total {P.sum():.2f}")
print(f"E(X) {EX:.2f}, E(Y) {EY:.2f}, Var(X) {VX:.2f}, Var(Y) {VY:.2f}, E(XY) {EXY:.2f}, Cov {cov:.2f}, Corr {cov/np.sqrt(VX*VY):.4f}")
cond = P / px[:, None]; EYgX = cond @ y; VYgX = cond @ y**2 - EYgX**2
print("E(Y|X):", np.round(EYgX, 3), " Var(Y|X):", np.round(VYgX, 3))
print(f"law of iterated expectations: sum E(Y|x)p(x) = {EYgX @ px:.4f} vs E(Y) = {EY:.4f}")
print(f"law of total variance: E[Var(Y|X)] + Var[E(Y|X)] = {VYgX @ px + (EYgX**2) @ px - EY**2:.4f} vs Var(Y) = {VY:.4f}")
print(f"max |p(x,y) - p(x)p(y)| = {np.abs(P - np.outer(px, py)).max():.3f}")

# ---------------------------------------------------------------
print("\n=== Experiment 2: two dice ===")
d = pd.read_excel(BOOK, sheet_name="Two_Dice", header=3, usecols="A:C")
d1, d2 = d["Die 1"], d["Die 2"]; s = d1 + d2
print(f"means {d1.mean():.3f}, {d2.mean():.3f}, sum {s.mean():.3f} (theory 3.5, 3.5, 7)")
print(f"var {d1.var():.4f}, {d2.var():.4f} (theory {35/12:.4f}); cov {np.cov(d1, d2)[0,1]:.4f}")
print(f"Var(sum) {s.var():.4f} = {d1.var() + d2.var() + 2*np.cov(d1, d2)[0,1]:.4f}; theory {35/6:.4f}")
print(f"mean of product {(d1*d2).mean():.3f}; product of means {d1.mean()*d2.mean():.3f}; theory 12.25")

# ---------------------------------------------------------------
print("\n=== Experiment 3: households -- linear transformations, sums and conditional means ===")
h = pd.read_excel(BOOK, sheet_name="Households", header=3, usecols="A:G")
h.columns = ["id", "region", "urban", "size", "educ", "income", "cons"]
I, C = h["income"], h["cons"]; S = I - C; n = len(h)
print(f"n {n}; E(I) {I.mean():.2f}; median {I.median():.1f}; E(C) {C.mean():.2f}")
print(f"Var(I): n-1 {I.var(ddof=1):.0f}, n {I.var(ddof=0):.0f}, ratio {I.var(ddof=1)/I.var(ddof=0):.4f}")
print(f"SD(I) {I.std():.2f}; Var(C) {C.var():.0f}; Cov(I,C) {np.cov(I, C)[0,1]:.0f}; Corr {np.corrcoef(I, C)[0,1]:.4f}")
print(f"income in thousands: mean {(I/1000).mean():.4f}, var {(I/1000).var():.4f}")
print(f"Var(S) {S.var():.0f}; Var(I)+Var(C)-2Cov {I.var()+C.var()-2*np.cov(I, C)[0,1]:.0f}; ignoring Cov {I.var()+C.var():.0f}")
pu = h.urban.mean(); cu, cr = C[h.urban == 1].mean(), C[h.urban == 0].mean()
print(f"P(urban) {pu:.3f}; E(C|urban) {cu:.2f}; E(C|rural) {cr:.2f}; iterated {pu*cu + (1-pu)*cr:.2f} = E(C) {C.mean():.2f}")
b = np.cov(I, C)[0, 1] / I.var(); a = C.mean() - b * I.mean()
print(f"slope Cov/Var {b:.4f}; intercept {a:.2f}")
v = I.var() * 4 + C.var() * 9 + 2 * 2 * 3 * np.cov(I, C)[0, 1]
print(f"Var(2I+3C): formula {v:.0f}, direct {(2*I + 3*C).var():.0f}")

# ---------------------------------------------------------------
print("\n=== Experiment 4: dependence without correlation ===")
z = pd.read_excel(BOOK, sheet_name="Zero_Correlation", header=3, usecols="B")
X = z.iloc[:, 0]; Y = X**2
print(f"Corr(X, X^2) {np.corrcoef(X, Y)[0,1]:.4f}; Corr(|X|, X^2) {np.corrcoef(X.abs(), Y)[0,1]:.4f}")

# ---------------------------------------------------------------
print("\n=== Experiment 5: portfolio ===")
p = pd.read_excel(BOOK, sheet_name="Portfolio", header=3, usecols="A:C")
A, B = p["Asset A (%)"], p["Asset B (%)"]
vA, vB, cAB = A.var(), B.var(), np.cov(A, B)[0, 1]
print(f"E(A) {A.mean():.3f}, E(B) {B.mean():.3f}, Var(A) {vA:.3f}, Var(B) {vB:.3f}, Cov {cAB:.3f}, Corr {np.corrcoef(A, B)[0,1]:.3f}")
for w in [0.5, (vB - cAB) / (vA + vB - 2*cAB), 1.0, 0.0]:
    vp = w**2*vA + (1-w)**2*vB + 2*w*(1-w)*cAB; direct = (w*A + (1-w)*B).var()
    print(f"w = {w:.4f}: Var(P) formula {vp:.3f}, direct {direct:.3f}, SD {np.sqrt(vp):.3f}; "
          f"weighted SD {w*np.sqrt(vA)+(1-w)*np.sqrt(vB):.3f}")

# ---------------------------------------------------------------
print("\n=== Experiment 6: why divide by n - 1 (simulation) ===")
rng = np.random.RandomState(5); reps = 100000
for m in [2, 5, 30]:
    draws = rng.randint(1, 7, (reps, m))          # samples of m die rolls; true variance 35/12
    print(f"sample size {m:2d}: mean of s^2 (n-1) {draws.var(axis=1, ddof=1).mean():.4f}; "
          f"mean of (n) version {draws.var(axis=1, ddof=0).mean():.4f}; truth {35/12:.4f}")

# ---------------------------------------------------------------
print("\n=== Experiment 7: the variance of a mean falls like 1/n ===")
rng = np.random.RandomState(6)
for m in [1, 4, 16, 64]:
    means = rng.randint(1, 7, (50000, m)).mean(axis=1)
    print(f"n = {m:2d}: Var(mean) {means.var():.4f}; sigma^2/n {35/12/m:.4f}")

# ---------------------------------------------------------------
print("\n=== Experiment 8: correlated terms break the 1/n rule ===")
rng = np.random.RandomState(8); m, rho = 16, 0.6
for r in [0.0, rho]:
    e = rng.randn(50000, m); u = np.empty_like(e); u[:, 0] = e[:, 0]
    for t in range(1, m): u[:, t] = r * u[:, t-1] + np.sqrt(1 - r**2) * e[:, t]   # unit variance, AR(1)
    print(f"rho = {r}: Var(mean of 16) {u.mean(axis=1).var():.4f}; naive sigma^2/n {1/m:.4f}")
