EXPECTATION, VARIANCE AND COVARIANCE: THE PROBABILITY FOUNDATIONS OF LINEAR REGRESSION
Preliminary Module of the course on Linear Regression Models (before Module 0). Manhar Singh, November 2026.
Notes: 44 pages. Instructor answer key for the six applied problems: 24 pages.

FOLDERS
  notes/                 PDF of the notes, LaTeX source, and lrm-notes.sty (keep the .sty next to the .tex to compile).
  overleaf_single_file/  The same notes as one self-contained .tex file (style inlined): paste into Overleaf and compile.
  workbook/              Student practice workbook (blue = data, black = live formulas, yellow = exercise answer cells).
  code/                  Python and R scripts that reproduce every number in the notes.
  instructor/            NOT FOR STUDENTS: instructor workbook with answers filled in, and the scripts that build the workbooks.
                         (The builder scripts can regenerate the instructor answers, so keep them out of student hands.)

COMPILING: pdflatex, run twice (for the table of contents). Uses pgfplots, natbib, listings.
NOTE: the R scripts were written to mirror the Python but were not run for this edition; please run them once before class.
References were added from knowledge of the literature; check volumes and pages before quoting formally.

RUNNING THE CODE: copy workbook/Foundations_Practice_Data.xlsx into code/ first (the scripts read it).
The answer-key scripts in instructor/ read the same workbook.
The answer key (instructor/module_P_answer_key.tex) is a single self-contained file.
