BASICS OF DATA, VARIABLES AND DISTRIBUTION: TYPES OF DATA, TYPES OF VARIABLES, EXPECTATION, VARIANCE AND COMMON DISTRIBUTIONS
Module 1 of the course on Linear Regression Models. Manhar Singh, November 2026. Notes: 32 pages.

FOLDERS
  notes/                 PDF of the notes, LaTeX source, and lrm-notes.sty (keep the .sty next to the .tex to compile).
  overleaf_single_file/  The same notes as one self-contained .tex file (style inlined): paste into Overleaf and compile.
  code/                  module1_examples.py reproduces every number in the notes (needs numpy, scipy, statsmodels;
                         simulated data, no input files). module1_examples.R is the R companion; simulated results
                         differ in the decimals because R's random numbers differ.

COMPILING: pdflatex, run twice (for the table of contents).
This module has no practice workbook and no instructor material.
NOTE: the R script was not run for this edition; please run it once before class.
