"""Module 1 -- Basics of Data, Variables and Distribution.
Every number printed in the Module 1 notes is produced by this script.
Run from top to bottom:  python module1_examples.py
"""
import numpy as np
from scipy import stats
import statsmodels.api as sm

np.set_printoptions(precision=4, suppress=True)

def ols(y, *xs):
    """OLS with an intercept; returns the fitted statsmodels result."""
    X = sm.add_constant(np.column_stack(xs))
    return sm.OLS(y, X).fit()

# ---------------------------------------------------------------
print("\n=== Experiment 1: a balanced panel as an N x T table (long form) ===")
N, T = 3, 4
ids = np.repeat(np.arange(1, N + 1), T); years = np.tile(np.arange(2021, 2021 + T), N)
print("rows in long form:", N * T, "| first rows:", list(zip(ids[:5], years[:5])))

# ---------------------------------------------------------------
print("\n=== Experiment 2: endogeneity from an omitted (latent) variable ===")
rng = np.random.RandomState(1)
n, reps = 1000, 2000
b_short, b_long, b_iv = [], [], []
for _ in range(reps):
    ability = rng.randn(n)                       # latent, unobserved
    z = rng.randn(n)                             # instrument, e.g. distance to college
    exper = rng.uniform(0, 20, n)                # observed control
    school = 12 + 1.0 * ability + 0.8 * z + rng.randn(n)
    logw = 1.0 + 0.08 * school + 0.02 * exper + 0.10 * ability + 0.3 * rng.randn(n)
    b_short.append(ols(logw, school, exper).params[1])            # ability omitted
    b_long.append(ols(logw, school, exper, ability).params[1])    # infeasible: ability observed
    # IV by two-stage least squares (by hand)
    s_hat = ols(school, z, exper).fittedvalues
    b_iv.append(ols(logw, s_hat, exper).params[1])
for name, b in [("OLS, ability omitted", b_short), ("OLS, ability included", b_long), ("IV with z", b_iv)]:
    b = np.array(b); print(f"{name:24s} mean {b.mean():.4f}  sd {b.std():.4f}")
print("true return to schooling: 0.0800")

# ---------------------------------------------------------------
print("\n=== Experiment 3: moments of a fair die ===")
faces = np.arange(1, 7)
EX = faces.mean(); EX2 = (faces ** 2).mean(); VX = EX2 - EX ** 2
print(f"E(X) = {EX:.4f}, E(X^2) = {EX2:.4f}, Var(X) = {VX:.4f}, sd = {np.sqrt(VX):.4f}")
rolls = np.random.RandomState(2).randint(1, 7, 100000)
print(f"100,000 simulated rolls: mean {rolls.mean():.4f}, var {rolls.var(ddof=1):.4f}")

# ---------------------------------------------------------------
print("\n=== Experiment 4: zero correlation is not independence ===")
rng = np.random.RandomState(3)
x = rng.uniform(-1, 1, 10000); y = x ** 2
print(f"corr(x, x^2) = {np.corrcoef(x, y)[0, 1]:.4f}  (y is an exact function of x)")

# ---------------------------------------------------------------
print("\n=== Worked example: covariance, correlation and the slope ===")
X = np.array([10, 20, 30, 40, 50.]); Y = np.array([8, 15, 24, 30, 38.])
sxy = np.cov(X, Y, ddof=1)[0, 1]; sx2 = X.var(ddof=1); sy2 = Y.var(ddof=1)
print(f"s_xy = {sxy:.2f}, s_x^2 = {sx2:.2f}, s_y^2 = {sy2:.2f}, r = {sxy/np.sqrt(sx2*sy2):.4f}, s_xy/s_x^2 = {sxy/sx2:.4f}")
print("OLS slope check:", round(ols(Y, X).params[1], 4))

# ---------------------------------------------------------------
print("\n=== Experiment 5: simulated moments of the three distributions ===")
rng = np.random.RandomState(123)
u = rng.uniform(0, 1, 10000); z = rng.normal(0, 1, 10000); t5 = rng.standard_t(5, 10000)
for name, d, m, v in [("U(0,1)", u, 0.5, 1/12), ("N(0,1)", z, 0, 1), ("t(5)", t5, 0, 5/3)]:
    print(f"{name:7s} mean {d.mean():7.4f} (theory {m:.4f})  var {d.var(ddof=1):.4f} (theory {v:.4f})"
          f"  skew {stats.skew(d):6.3f}  kurt {stats.kurtosis(d, fisher=False):6.3f}")

# ---------------------------------------------------------------
print("\n=== Experiment 6: central limit theorem with uniform draws ===")
rng = np.random.RandomState(4)
for k in [1, 2, 12]:
    avg = rng.uniform(0, 1, (10000, k)).mean(axis=1)
    jb, p = stats.jarque_bera(avg)
    print(f"k = {k:2d}: mean {avg.mean():.4f}, var {avg.var(ddof=1):.5f} (theory {1/(12*k):.5f}), "
          f"skew {stats.skew(avg):6.3f}, kurt {stats.kurtosis(avg, fisher=False):.3f}, JB p-value {p:.3f}")

# ---------------------------------------------------------------
print("\n=== Experiment 7: tail probabilities and critical values ===")
for k in [5, 10, 20, 30, 60, 120]:
    print(f"df {k:4d}: 5% two-sided critical value {stats.t.ppf(0.975, k):.3f}; "
          f"P(|t| > 1.96) = {2*stats.t.sf(1.96, k):.4f}")
print(f"normal : critical value {stats.norm.ppf(0.975):.3f}; P(|Z| > 1.96) = {2*stats.norm.sf(1.96):.4f}")
print(f"P(|Z|<1) = {stats.norm.cdf(1)-stats.norm.cdf(-1):.4f}, P(|Z|<2) = {stats.norm.cdf(2)-stats.norm.cdf(-2):.4f}, "
      f"P(|Z|<3) = {stats.norm.cdf(3)-stats.norm.cdf(-3):.4f}")
