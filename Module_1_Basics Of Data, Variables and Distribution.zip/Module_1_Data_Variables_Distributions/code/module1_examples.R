# Module 1 -- Basics of Data, Variables and Distribution
# R companion to module1_examples.py. Base R only.
# Deterministic results match the notes exactly; simulations give the same
# pattern but different decimals (R and Python draw different random numbers).

# ---------------------------------------------------------------
cat("\n=== Experiment: endogeneity from an omitted (latent) variable ===\n")
set.seed(1); n <- 1000; reps <- 2000
b <- matrix(NA, reps, 3, dimnames = list(NULL, c("OLS_omitted", "OLS_included", "IV")))
for (r in 1:reps) {
  ability <- rnorm(n); z <- rnorm(n); exper <- runif(n, 0, 20)
  school <- 12 + 1.0 * ability + 0.8 * z + rnorm(n)
  logw <- 1 + 0.08 * school + 0.02 * exper + 0.10 * ability + 0.3 * rnorm(n)
  b[r, 1] <- coef(lm(logw ~ school + exper))["school"]
  b[r, 2] <- coef(lm(logw ~ school + exper + ability))["school"]
  s_hat <- fitted(lm(school ~ z + exper))
  b[r, 3] <- coef(lm(logw ~ s_hat + exper))["s_hat"]
}
print(round(colMeans(b), 4)); print(round(apply(b, 2, sd), 4))
cat("true return to schooling: 0.08\n")

# ---------------------------------------------------------------
cat("\n=== Experiment: moments of a fair die ===\n")
faces <- 1:6
EX <- mean(faces); EX2 <- mean(faces^2)
print(c(EX = EX, EX2 = EX2, Var = EX2 - EX^2, sd = sqrt(EX2 - EX^2)))
set.seed(2); rolls <- sample(1:6, 1e5, replace = TRUE)
print(c(mean = mean(rolls), var = var(rolls)))

# ---------------------------------------------------------------
cat("\n=== Experiment: zero correlation is not independence ===\n")
set.seed(3); x <- runif(1e4, -1, 1); print(cor(x, x^2))

# ---------------------------------------------------------------
cat("\n=== Worked example: covariance, correlation and the slope ===\n")
x <- c(10, 20, 30, 40, 50); y <- c(8, 15, 24, 30, 38)
print(c(s_xy = cov(x, y), s_x2 = var(x), s_y2 = var(y), r = cor(x, y),
        ratio = cov(x, y) / var(x), ols_slope = unname(coef(lm(y ~ x))[2])))

# ---------------------------------------------------------------
cat("\n=== Experiment: simulated moments of the three distributions ===\n")
kurt <- function(v) mean((v - mean(v))^4) / mean((v - mean(v))^2)^2
skew <- function(v) mean((v - mean(v))^3) / mean((v - mean(v))^2)^1.5
set.seed(123)
u <- runif(1e4); z <- rnorm(1e4); t5 <- rt(1e4, df = 5)
print(round(sapply(list(U01 = u, N01 = z, t5 = t5),
  function(v) c(mean = mean(v), var = var(v), skew = skew(v), kurt = kurt(v))), 4))

# ---------------------------------------------------------------
cat("\n=== Experiment: central limit theorem with uniform draws ===\n")
jb <- function(v) { n <- length(v); s <- skew(v); k <- kurt(v)
  stat <- n / 6 * (s^2 + (k - 3)^2 / 4); c(JB = stat, p = 1 - pchisq(stat, 2)) }
set.seed(4)
for (k in c(1, 2, 12)) {
  avg <- rowMeans(matrix(runif(1e4 * k), ncol = k))
  cat(sprintf("k = %2d: mean %.4f var %.5f (theory %.5f) kurt %.3f JB p %.3f\n",
              k, mean(avg), var(avg), 1 / (12 * k), kurt(avg), jb(avg)["p"]))
}
hist(avg, breaks = 50, main = "Averages of 12 uniform draws")

# ---------------------------------------------------------------
cat("\n=== Experiment: tail probabilities and critical values ===\n")
k <- c(5, 10, 20, 30, 60, 120)
print(data.frame(df = k, crit = round(qt(0.975, k), 3), size_if_196 = round(2 * pt(-1.96, k), 4)))
print(round(pnorm(c(1, 2, 3)) - pnorm(-c(1, 2, 3)), 4))
