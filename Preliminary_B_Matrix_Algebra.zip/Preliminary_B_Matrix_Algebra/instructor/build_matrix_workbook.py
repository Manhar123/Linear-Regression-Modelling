"""Builds Matrix_Practice_Data.xlsx (and, with --instructor, Matrix_Practice_Data_INSTRUCTOR.xlsx):
synthetic (made-up) practice data for Preliminary Module B, Matrix Algebra for Regression.
Inputs are blue; every result is a live Excel formula (MMULT, TRANSPOSE, MINVERSE, MDETERM, SUMPRODUCT...)."""
import sys
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter as L
from openpyxl.worksheet.formula import ArrayFormula
import matrix_data as d

FONT = "Arial"
BLUE = Font(name=FONT, color="0000FF", size=10); BLACK = Font(name=FONT, color="000000", size=10)
BOLD = Font(name=FONT, bold=True, size=10); HEAD = Font(name=FONT, bold=True, color="FFFFFF", size=10)
TITLE = Font(name=FONT, bold=True, size=14, color="785064"); NOTE = Font(name=FONT, italic=True, size=9, color="555555")
SEPIA = PatternFill("solid", fgColor="785064"); LIGHT = PatternFill("solid", fgColor="EDE6DF"); YELLOW = PatternFill("solid", fgColor="FFFF00")
thin = Side(style="thin", color="BBBBBB"); BOX = Border(left=thin, right=thin, top=thin, bottom=thin)
INSTRUCTOR = "--instructor" in sys.argv
OUT = "Matrix_Practice_Data_INSTRUCTOR.xlsx" if INSTRUCTOR else "Matrix_Practice_Data.xlsx"
wb = Workbook()

def cell(ws, r, c, v, font=BLACK, fmt="0.####", fill=None):
    x = ws.cell(row=r, column=c, value=v); x.font = font; x.border = BOX
    if fmt and not isinstance(v, str): x.number_format = fmt
    if fmt and isinstance(v, str) and v.startswith("="): x.number_format = fmt
    if fill: x.fill = fill
    return x

def lab(ws, r, c, text, bold=False):
    x = ws.cell(row=r, column=c, value=text); x.font = BOLD if bold else BLACK; x.fill = LIGHT; x.border = BOX
    return x

def title(ws, t, note):
    ws["A1"] = t; ws["A1"].font = TITLE; ws["A2"] = note; ws["A2"].font = NOTE

def rng_(r, c, nr, nc):
    return f"{L(c)}{r}:{L(c + nc - 1)}{r + nr - 1}"

def matrix(ws, r, c, M, name, font=BLUE, fmt="0.####"):
    """Write a numeric matrix with its name above; return its range."""
    lab(ws, r, c, name, True)
    for i, row in enumerate(M):
        for j, v in enumerate(row): cell(ws, r + 1 + i, c + j, v, font, fmt)
    return rng_(r + 1, c, len(M), len(M[0]))

def arr(ws, r, c, nr, nc, formula, name, fmt="0.####"):
    """Array formula filling an nr x nc block, with its name above; return its range."""
    lab(ws, r, c, name, True)
    ref = rng_(r + 1, c, nr, nc)
    ws.cell(row=r + 1, column=c).value = ArrayFormula(ref, formula)
    for i in range(nr):
        for j in range(nc):
            x = ws.cell(row=r + 1 + i, column=c + j); x.border = BOX; x.font = BLACK; x.number_format = fmt
    return ref

def scalar(ws, r, c, text, formula, fmt="0.####", array=False):
    lab(ws, r, c, text)
    if array:
        ref = f"{L(c + 1)}{r}"; ws.cell(row=r, column=c + 1).value = ArrayFormula(ref, formula)
        x = ws.cell(row=r, column=c + 1); x.font = BLACK; x.border = BOX; x.number_format = fmt
    else:
        cell(ws, r, c + 1, formula, fmt=fmt)
    return f"{L(c + 1)}{r}"

def widths(ws, first=30, rest=11, n=20):
    ws.column_dimensions["A"].width = first
    for j in range(2, n + 2): ws.column_dimensions[L(j)].width = rest

REF = {}   # cells referred to by the Exercises sheet

# =====================================================================
ws = wb.active; ws.title = "README"
ws.column_dimensions["A"].width = 3; ws.column_dimensions["B"].width = 24; ws.column_dimensions["C"].width = 100
ws["B2"] = "Matrix practice data: matrix algebra for regression"; ws["B2"].font = TITLE
ws["B3"] = "Companion workbook to Preliminary Module B of the course on Linear Regression Models (Manhar Singh, November 2026)."; ws["B3"].font = NOTE
rows = [
    ("What this is", "Small synthetic (made-up) data sets for practising the matrix algebra of regression by hand and in Excel. "
     "The matrices are small enough to check with pencil and paper. The shop data describe no real shops."),
    ("Colour legend", "Blue = fixed inputs (edit them and every result updates). Black = formulas. Yellow = a parameter you may "
     "change, or your answer (Exercises sheet). The instructor version has every answer cell filled with a working formula."),
    ("Array formulas", "MMULT, TRANSPOSE and MINVERSE return whole matrices. In Excel 365 they spill automatically. In older Excel, "
     "select the output block, type the formula and press Ctrl+Shift+Enter. Blocks in this workbook are already entered as arrays."),
    ("M1_Operations", "Transpose, addition, multiplication, (AB)' = B'A', AB versus BA, the identity, the sum vector of ones."),
    ("M2_Shop_Regression", "Eight shops: sales on advertising and floor area. Builds X, X', X'X, X'Y, |X'X|, (X'X)^-1, b = (X'X)^-1 X'Y, "
     "fitted values, residuals, X'e = 0, s^2, Var(b) = s^2 (X'X)^-1, standard errors and t ratios; compared with LINEST."),
    ("M3_Rank", "Linear dependence: X3 = 2 X2 (Asteriou and Hall), the dummy-variable trap, and a near-dependence whose strength you "
     "control with the yellow cell. Watch |X'X| go to zero and (X'X)^-1 explode."),
    ("M4_Systems", "Three systems Ax = b: a unique solution, no solution and infinitely many solutions."),
    ("M5_Quadratic_Forms", "x'Ax for a positive definite and an indefinite matrix; leading principal minors; a'X'Xa = (Xa)'(Xa) >= 0."),
    ("M6_Eigenvalues", "Eigenvalues and eigenvectors of a 2 x 2 matrix; the correlation matrix of two regressors with correlation r: "
     "eigenvalues 1 + r and 1 - r, condition number and VIF."),
    ("M7_Projections", "The hat matrix P = X(X'X)^-1 X' and the residual maker M = I - P for the shop data: PP = P, trace(P) = k, "
     "trace(M) = n - k, PY = fitted values, MY = residuals, MX = 0; the centring matrix."),
    ("M8_RSS_Gradient", "RSS(b) = (Y - Xb)'(Y - Xb) and its gradient -2X'Y + 2X'Xb for any b you type in; both are minimised / zero at OLS."),
    ("M9_Random_Vectors", "Three assets: mean vector, covariance matrix, portfolio mean w'mu and variance w'Sigma w, AΣA' for two "
     "portfolios, checked against 240 simulated months."),
    ("Exercises", "Twelve exercises with yellow answer cells."),
    ("Reproducing in R/Python", "matrix_examples.py and matrix_examples.R reproduce every number quoted in the notes from the same data."),
]
for i, (a, b) in enumerate(rows):
    r = 5 + i; ws.cell(row=r, column=2, value=a).font = BOLD
    x = ws.cell(row=r, column=3, value=b); x.font = BLACK; x.alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[r].height = 40

# =====================================================================
ws = wb.create_sheet("M1_Operations"); widths(ws, 26, 9)
title(ws, "Matrix operations", "A is 2 x 3, B is 3 x 2, C is 2 x 2 (blue inputs). Every result is a formula.")
rA = matrix(ws, 4, 1, d.A, "A (2 x 3)"); rB = matrix(ws, 4, 6, d.B, "B (3 x 2)"); rC = matrix(ws, 4, 10, d.C, "C (2 x 2)")
rAt = arr(ws, 9, 1, 3, 2, f"=TRANSPOSE({rA})", "A' (3 x 2)")
rAB = arr(ws, 9, 6, 2, 2, f"=MMULT({rA},{rB})", "AB (2 x 2)")
rBA = arr(ws, 9, 10, 3, 3, f"=MMULT({rB},{rA})", "BA (3 x 3)")
rABt = arr(ws, 15, 1, 2, 2, f"=TRANSPOSE(MMULT({rA},{rB}))", "(AB)'")
rBtAt = arr(ws, 15, 6, 2, 2, f"=MMULT(TRANSPOSE({rB}),TRANSPOSE({rA}))", "B'A'")
rApB = arr(ws, 15, 10, 2, 3, f"={rA}+TRANSPOSE({rB})", "A + B'")
rCC = arr(ws, 19, 1, 2, 2, f"=MMULT({rC},{rC})", "CC = C^2")
rI = matrix(ws, 19, 6, [[1, 0], [0, 1]], "I (2 x 2)")
rCI = arr(ws, 19, 10, 2, 2, f"=MMULT({rC},{rI})", "CI (= C)")
rAAt = arr(ws, 23, 1, 2, 2, f"=MMULT({rA},TRANSPOSE({rA}))", "AA' (symmetric)")
rAtA = arr(ws, 23, 6, 3, 3, f"=MMULT(TRANSPOSE({rA}),{rA})", "A'A (symmetric)")
lab(ws, 28, 1, "Sum vector: for x = (2, 4, 3, 6, 5, 8, 7, 9)'", True)
xv = d.SHOP["adv"]
for i, v in enumerate(xv): cell(ws, 29 + i, 1, v, BLUE)
for i in range(8): cell(ws, 29 + i, 2, 1, BLUE)
lab(ws, 28, 2, "i (ones)", True)
REF["iota_x"] = scalar(ws, 29, 4, "i'x = sum of x", "=SUMPRODUCT(B29:B36,A29:A36)", array=False)
REF["xx"] = scalar(ws, 30, 4, "x'x = sum of squares", "=SUMPRODUCT(A29:A36,A29:A36)")
scalar(ws, 31, 4, "i'x / i'i = mean", "=E29/SUMPRODUCT(B29:B36,B29:B36)")
scalar(ws, 32, 4, "Check: SUM(x)", "=SUM(A29:A36)")
REF["AB"] = rAB; REF["C"] = rC

# =====================================================================
ws = wb.create_sheet("M2_Shop_Regression"); widths(ws, 30, 10, 22)
title(ws, "Eight kirana shops: the regression done with matrices",
      "Sales and advertising in Rs '000 a month; floor area in tens of square metres. Synthetic data. Model: SALES = b1 + b2 ADV + b3 AREA + u.")
hdr = ["Shop", "Sales Y", "Constant", "Advertising", "Area"]
for j, h in enumerate(hdr):
    x = ws.cell(row=4, column=1 + j, value=h); x.font = HEAD; x.fill = SEPIA; x.border = BOX
for i in range(8):
    r = 5 + i; cell(ws, r, 1, i + 1); cell(ws, r, 2, d.SHOP["sales"][i], BLUE); cell(ws, r, 3, 1, BLUE)
    cell(ws, r, 4, d.SHOP["adv"][i], BLUE); cell(ws, r, 5, d.SHOP["area"][i], BLUE)
X = "C5:E12"; Y = "B5:B12"
rXt = arr(ws, 3, 7, 3, 8, f"=TRANSPOSE({X})", "X' (3 x 8)")
rXX = arr(ws, 8, 7, 3, 3, f"=MMULT(TRANSPOSE({X}),{X})", "X'X (3 x 3)", "0")
rXY = arr(ws, 8, 11, 3, 1, f"=MMULT(TRANSPOSE({X}),{Y})", "X'Y", "0")
REF["detXX"] = scalar(ws, 13, 7, "|X'X| = MDETERM(X'X)", f"=MDETERM({rXX})", "0.00")
rInv = arr(ws, 15, 7, 3, 3, f"=MINVERSE({rXX})", "(X'X)^-1", "0.000000")
rChk = arr(ws, 15, 11, 3, 3, f"=MMULT({rXX},{rInv})", "(X'X)(X'X)^-1 = I", "0.000")
rb = arr(ws, 20, 7, 3, 1, f"=MMULT({rInv},{rXY})", "b = (X'X)^-1 X'Y", "0.0000")
for i, nm in enumerate(["b1 (constant)", "b2 (advertising)", "b3 (area)"]): ws.cell(row=21 + i, column=8, value=nm).font = NOTE
REF["b"] = rb
header_cols = ["Fitted", "Residual e", "e^2"]
for j, h in enumerate(header_cols):
    x = ws.cell(row=14, column=1 + j + 1, value=h); x.font = HEAD; x.fill = SEPIA; x.border = BOX
for i in range(8):
    r = 15 + i
    cell(ws, r, 1, i + 1)
    cell(ws, r, 2, f"=MMULT(C{5+i}:E{5+i},$G$21:$G$23)", fmt="0.0000")
    cell(ws, r, 3, f"=B{5+i}-B{r}", fmt="0.0000"); cell(ws, r, 4, f"=C{r}^2", fmt="0.0000")
rXe = arr(ws, 25, 7, 3, 1, f"=MMULT(TRANSPOSE({X}),C15:C22)", "X'e (should be 0)", "0.000000")
REF["RSS"] = scalar(ws, 24, 1, "RSS = e'e", "=SUMPRODUCT(C15:C22,C15:C22)", "0.0000")
scalar(ws, 25, 1, "n", "=COUNT(B5:B12)", "0"); scalar(ws, 26, 1, "k", "=COLUMNS(C5:E5)", "0")
REF["s2"] = scalar(ws, 27, 1, "s^2 = RSS/(n-k)", "=B24/(B25-B26)", "0.0000")
rV = arr(ws, 29, 7, 3, 3, f"=B27*{rInv}", "Var(b) = s^2 (X'X)^-1", "0.000000")
lab(ws, 29, 11, "se(b)", True); lab(ws, 29, 12, "t = b/se", True)
for i in range(3):
    r = 30 + i
    cell(ws, r, 11, f"=SQRT(INDEX({rV},{i+1},{i+1}))", fmt="0.0000"); cell(ws, r, 12, f"=G{21+i}/K{r}", fmt="0.00")
REF["se2"] = "K31"; REF["V"] = rV; REF["inv"] = rInv; REF["XX"] = rXX
rL = arr(ws, 34, 7, 1, 3, f"=LINEST({Y},D5:E12)", "LINEST: b3, b2, b1 (Excel's order is reversed)", "0.0000")
scalar(ws, 28, 1, "R^2 = 1 - RSS/TSS", f"=1-B24/DEVSQ({Y})", "0.0000")

# =====================================================================
ws = wb.create_sheet("M3_Rank"); widths(ws, 30, 10, 24)
title(ws, "Linear dependence, rank and near-singularity", "Three small data sets. Compare |X'X| and (X'X)^-1 across them.")
# (a) Asteriou-Hall X3 = 2 X2
lab(ws, 4, 1, "(a) X3 = 2 X2 exactly (Asteriou and Hall)", True)
for j, h in enumerate(["Y", "Const", "X2", "X3 = 2 X2"]):
    x = ws.cell(row=5, column=1 + j, value=h); x.font = HEAD; x.fill = SEPIA; x.border = BOX
for i in range(6):
    r = 6 + i; cell(ws, r, 1, d.AH_Y[i], BLUE); cell(ws, r, 2, 1, BLUE); cell(ws, r, 3, d.AH_X2[i], BLUE); cell(ws, r, 4, f"=2*C{r}")
rXXa = arr(ws, 5, 6, 3, 3, "=MMULT(TRANSPOSE(B6:D11),B6:D11)", "X'X", "0")
REF["deta"] = scalar(ws, 9, 6, "|X'X|", f"=MDETERM({rXXa})", "0.00")
lab(ws, 10, 6, "MINVERSE(X'X) returns an error here (X'X is singular): try it in a spare cell.")
scalar(ws, 11, 6, "-2*X2 + 1*X3 for each row (all 0)", "=SUMPRODUCT(ABS(-2*C6:C11+D6:D11))", "0", array=True)
# (b) dummy trap
lab(ws, 14, 1, "(b) Dummy-variable trap: constant + North + South", True)
for j, h in enumerate(["Sales", "Const", "North", "South"]):
    x = ws.cell(row=15, column=1 + j, value=h); x.font = HEAD; x.fill = SEPIA; x.border = BOX
for i in range(8):
    r = 16 + i; cell(ws, r, 1, d.SHOP["sales"][i], BLUE); cell(ws, r, 2, 1, BLUE); cell(ws, r, 3, d.SHOP["north"][i], BLUE)
    cell(ws, r, 4, f"=1-C{r}")
rXXb = arr(ws, 15, 6, 3, 3, "=MMULT(TRANSPOSE(B16:D23),B16:D23)", "X'X", "0")
REF["detb"] = scalar(ws, 19, 6, "|X'X|", f"=MDETERM({rXXb})", "0.00")
lab(ws, 20, 6, "Row 1 of X'X = row 2 + row 3: the constant = North + South.")
rXXb2 = arr(ws, 21, 6, 2, 2, "=MMULT(TRANSPOSE(B16:C23),B16:C23)", "X'X after dropping South", "0")
scalar(ws, 24, 6, "|X'X| after dropping South", f"=MDETERM({rXXb2})", "0.00")
rbb = arr(ws, 25, 6, 2, 1, "=MMULT(MINVERSE(MMULT(TRANSPOSE(B16:C23),B16:C23)),MMULT(TRANSPOSE(B16:C23),A16:A23))",
          "b: South mean, North - South", "0.000")
# (c) near-dependence
lab(ws, 29, 1, "(c) Near-dependence: X3 = 2 X2 + c v. Change c (yellow).", True)
lab(ws, 30, 1, "c ="); cell(ws, 30, 2, 1, BLUE, "0.####", YELLOW); REF["c"] = "B30"
for j, h in enumerate(["Sales", "Const", "Adv X2", "v", "X3 = 2X2 + cv"]):
    x = ws.cell(row=31, column=1 + j, value=h); x.font = HEAD; x.fill = SEPIA; x.border = BOX
for i in range(8):
    r = 32 + i; cell(ws, r, 1, d.SHOP["sales"][i], BLUE); cell(ws, r, 2, 1, BLUE); cell(ws, r, 3, d.SHOP["adv"][i], BLUE)
    cell(ws, r, 4, d.NEAR_V[i], BLUE); cell(ws, r, 5, f"=2*C{r}+$B$30*D{r}", fmt="0.####")
Xc = "B32:C39,E32:E39"
rXXc = arr(ws, 31, 7, 3, 3, "=MMULT(TRANSPOSE(CHOOSE({1,2,3},B32:B39,C32:C39,E32:E39)),CHOOSE({1,2,3},B32:B39,C32:C39,E32:E39))", "X'X", "0.####")
REF["detc"] = scalar(ws, 35, 7, "|X'X|", f"=MDETERM({rXXc})", "0.000000")
rInvc = arr(ws, 36, 7, 3, 3, f"=MINVERSE({rXXc})", "(X'X)^-1", "0.0000")
rbc = arr(ws, 40, 7, 3, 1, f"=MMULT({rInvc},MMULT(TRANSPOSE(CHOOSE({{1,2,3}},B32:B39,C32:C39,E32:E39)),A32:A39))", "b", "0.0000")
scalar(ws, 44, 7, "b2 + 2 b3 (stable)", "=G42+2*G43", "0.0000")
scalar(ws, 45, 7, "corr(X2, X3)", "=CORREL(C32:C39,E32:E39)", "0.000000")
REF["b2c"] = "G42"

# =====================================================================
ws = wb.create_sheet("M4_Systems"); widths(ws, 30, 10)
title(ws, "Systems of linear equations Ax = b", "Unique, none, infinitely many.")
rA1 = matrix(ws, 4, 1, d.SYS_A1, "A1"); rb1 = matrix(ws, 4, 5, [[v] for v in d.SYS_b1], "b1")
REF["detA1"] = scalar(ws, 9, 1, "|A1|", f"=MDETERM({rA1})", "0.00")
rx1 = arr(ws, 4, 7, 3, 1, f"=MMULT(MINVERSE({rA1}),{rb1})", "x = A1^-1 b1", "0.0000")
arr(ws, 4, 9, 3, 1, f"=MMULT({rA1},{rx1})", "check A1 x", "0.0000")
rA2 = matrix(ws, 12, 1, d.SYS_A2, "A2 (row 3 = row 1 + row 2)")
REF["detA2"] = scalar(ws, 17, 1, "|A2|", f"=MDETERM({rA2})", "0.00")
matrix(ws, 12, 5, [[v] for v in d.SYS_b2_bad], "b (inconsistent)")
lab(ws, 17, 4, "6 + 7 = 13, not 10: no x can satisfy all three rows.")
rbok = matrix(ws, 19, 5, [[v] for v in d.SYS_b2_ok], "b (consistent)")
lab(ws, 19, 1, "Infinitely many solutions x = x0 + t d", True)
rx0 = matrix(ws, 20, 1, [[v] for v in [1, 1, 1]], "x0 (a particular solution)")
rd = matrix(ws, 20, 3, [[v] for v in [-5, -2, 3]], "d (A2 d = 0)")
lab(ws, 25, 1, "t ="); cell(ws, 25, 2, 2, BLUE, "0.####", YELLOW)
rxt = arr(ws, 26, 1, 3, 1, f"={rx0}+B25*{rd}", "x = x0 + t d", "0.####")
arr(ws, 26, 3, 3, 1, f"=MMULT({rA2},{rxt})", "A2 x (= b for every t)", "0.####")
arr(ws, 26, 5, 3, 1, f"=MMULT({rA2},{rd})", "A2 d", "0.####")

# =====================================================================
ws = wb.create_sheet("M5_Quadratic_Forms"); widths(ws, 32, 10)
title(ws, "Quadratic forms and definiteness", "Change x (yellow) and watch the sign of x'Ax.")
rQ1 = matrix(ws, 4, 1, d.Q_PD, "A (positive definite)"); rQ2 = matrix(ws, 4, 5, d.Q_IND, "B (indefinite)")
lab(ws, 9, 1, "x", True)
for i, v in enumerate(d.Q_X): cell(ws, 10 + i, 1, v, BLUE, "0.####", YELLOW)
REF["xAx"] = scalar(ws, 14, 1, "x'Ax", f"=MMULT(TRANSPOSE(A10:A12),MMULT({rQ1},A10:A12))", "0.####", array=True)
REF["xBx"] = scalar(ws, 15, 1, "x'Bx", f"=MMULT(TRANSPOSE(A10:A12),MMULT({rQ2},A10:A12))", "0.####", array=True)
lab(ws, 17, 1, "Leading principal minors", True); lab(ws, 17, 2, "A", True); lab(ws, 17, 3, "B", True)
for k in range(1, 4):
    r = 17 + k; lab(ws, r, 1, f"order {k}")
    cell(ws, r, 2, f"=MDETERM(A5:{L(k)}{4+k})" if k > 1 else "=A5", fmt="0.####")
    cell(ws, r, 3, f"=MDETERM(E5:{L(4+k)}{4+k})" if k > 1 else "=E5", fmt="0.####")
REF["minorB2"] = "C19"
lab(ws, 21, 1, "Positive definite? (all minors > 0)")
cell(ws, 21, 2, '=IF(AND(B18>0,B19>0,B20>0),"Yes","No")'); cell(ws, 21, 3, '=IF(AND(C18>0,C19>0,C20>0),"Yes","No")')
lab(ws, 23, 1, "a'X'Xa = (Xa)'(Xa) >= 0, shop X", True)
lab(ws, 24, 1, "a", True)
for i, v in enumerate([1, -2, 1]): cell(ws, 25 + i, 1, v, BLUE, "0.####", YELLOW)
scalar(ws, 28, 1, "a'(X'X)a", "=MMULT(TRANSPOSE(A25:A27),MMULT(M2_Shop_Regression!G9:I11,A25:A27))", "0.####", array=True)
scalar(ws, 29, 1, "sum of squares of Xa", "=SUMPRODUCT(MMULT(M2_Shop_Regression!C5:E12,A25:A27)^2)", "0.####", array=True)

# =====================================================================
ws = wb.create_sheet("M6_Eigenvalues"); widths(ws, 34, 11)
title(ws, "Eigenvalues and eigenvectors of 2 x 2 symmetric matrices", "lambda = [tr +/- sqrt(tr^2 - 4 det)] / 2")
rE = matrix(ws, 4, 1, d.EIG_A, "A (symmetric)")
scalar(ws, 8, 1, "trace", "=A5+B6"); scalar(ws, 9, 1, "determinant", f"=MDETERM({rE})")
REF["l1"] = scalar(ws, 10, 1, "lambda1 (larger)", "=(B8+SQRT(B8^2-4*B9))/2", "0.####")
scalar(ws, 11, 1, "lambda2 (smaller)", "=(B8-SQRT(B8^2-4*B9))/2", "0.####")
scalar(ws, 12, 1, "lambda1 + lambda2 (= trace)", "=B10+B11"); scalar(ws, 13, 1, "lambda1 x lambda2 (= det)", "=B10*B11")
lab(ws, 15, 1, "Eigenvector for lambda1: (b, lambda1 - a), normalised", True)
cell(ws, 16, 1, "=B5/SQRT(B5^2+(B10-A5)^2)", fmt="0.0000"); cell(ws, 17, 1, "=(B10-A5)/SQRT(B5^2+(B10-A5)^2)", fmt="0.0000")
arr(ws, 15, 3, 2, 1, f"=MMULT({rE},A16:A17)", "A v", "0.0000"); arr(ws, 15, 4, 2, 1, "=B10*A16:A17", "lambda1 v", "0.0000")
lab(ws, 20, 1, "Correlation matrix of two regressors", True)
lab(ws, 21, 1, "r ="); cell(ws, 21, 2, d.EIG_R, BLUE, "0.####", YELLOW)
rR = arr(ws, 22, 1, 2, 2, "=CHOOSE({1,2;3,4},1,B21,B21,1)", "R", "0.####")
scalar(ws, 26, 1, "lambda max = 1 + |r|", "=1+ABS(B21)"); scalar(ws, 27, 1, "lambda min = 1 - |r|", "=1-ABS(B21)")
scalar(ws, 28, 1, "|R| = 1 - r^2 (= product)", f"=MDETERM({rR})")
REF["cond"] = scalar(ws, 29, 1, "condition number sqrt(lmax/lmin)", "=SQRT(B26/B27)", "0.00")
scalar(ws, 30, 1, "VIF = 1/(1 - r^2)", "=1/(1-B21^2)", "0.00")
rRi = arr(ws, 31, 1, 2, 2, f"=MINVERSE({rR})", "R^-1 (diagonal = VIF)", "0.00")

# =====================================================================
ws = wb.create_sheet("M7_Projections"); widths(ws, 26, 8, 20)
title(ws, "Projection matrices for the shop data", "P = X(X'X)^-1 X' (8 x 8), M = I - P.")
Xs = "M2_Shop_Regression!C5:E12"; Ys = "M2_Shop_Regression!B5:B12"
rP = arr(ws, 4, 1, 8, 8, f"=MMULT({Xs},MMULT(MINVERSE(MMULT(TRANSPOSE({Xs}),{Xs})),TRANSPOSE({Xs})))", "P (hat matrix)", "0.000")
rIn = matrix(ws, 4, 11, np.eye(8, dtype=int).tolist(), "I (8 x 8)", "0")
rM = arr(ws, 14, 1, 8, 8, f"={rIn}-{rP}", "M = I - P (residual maker)", "0.000")
REF["trP"] = scalar(ws, 24, 1, "trace(P) (= k)", f"=SUMPRODUCT({rP}*{rIn})", "0.0000")
REF["trM"] = scalar(ws, 25, 1, "trace(M) (= n - k)", f"=SUMPRODUCT({rM}*{rIn})", "0.0000")
scalar(ws, 26, 1, "max |PP - P|", f"=MAX(ABS(MMULT({rP},{rP})-{rP}))", "0.0E+00", array=True)
scalar(ws, 27, 1, "max |MX|", f"=MAX(ABS(MMULT({rM},{Xs})))", "0.0E+00", array=True)
scalar(ws, 28, 1, "max |PM|", f"=MAX(ABS(MMULT({rP},{rM})))", "0.0E+00", array=True)
arr(ws, 14, 11, 8, 1, f"=MMULT({rP},{Ys})", "PY = fitted", "0.0000")
arr(ws, 14, 13, 8, 1, f"=MMULT({rM},{Ys})", "MY = residuals", "0.0000")
rM0 = arr(ws, 24, 11, 8, 8, f"={rIn}-1/8", "M0 = I - ii'/n (centring)", "0.000")
arr(ws, 33, 11, 8, 1, f"=MMULT({rM0},{Ys})", "M0 Y = Y - mean", "0.000")
REF["h11"] = "A5"

# =====================================================================
ws = wb.create_sheet("M8_RSS_Gradient"); widths(ws, 34, 12)
title(ws, "RSS(b) and its gradient for the shop data", "Type any b (yellow). RSS(b) = (Y - Xb)'(Y - Xb); gradient = -2X'Y + 2X'Xb.")
lab(ws, 4, 1, "b (try the OLS values, then change them)", True)
for i, v in enumerate([10, 2, 3]): cell(ws, 5 + i, 1, v, BLUE, "0.####", YELLOW)
REF["RSSb"] = scalar(ws, 9, 1, "RSS(b)", f"=SUMPRODUCT(({Ys}-MMULT({Xs},A5:A7))^2)", "0.0000", array=True)
arr(ws, 11, 1, 3, 1, f"=-2*MMULT(TRANSPOSE({Xs}),{Ys})+2*MMULT(MMULT(TRANSPOSE({Xs}),{Xs}),A5:A7)", "gradient dRSS/db", "0.0000")
scalar(ws, 16, 1, "RSS at OLS (from M2)", "=M2_Shop_Regression!B24", "0.0000")
arr(ws, 18, 1, 3, 3, f"=2*MMULT(TRANSPOSE({Xs}),{Xs})", "Hessian 2X'X", "0")

# =====================================================================
ws = wb.create_sheet("M9_Random_Vectors"); widths(ws, 30, 10)
title(ws, "Random vectors: three assets (monthly returns, per cent)", "Population mean vector and covariance matrix (blue); weights (yellow).")
rmu = matrix(ws, 4, 1, [[v] for v in d.MU], "mu"); rS = matrix(ws, 4, 3, d.SIGMA, "Sigma")
rw = matrix(ws, 4, 7, [[v] for v in d.W], "w (weights)")
for i in range(3): ws.cell(row=5 + i, column=7).fill = YELLOW
REF["wmu"] = scalar(ws, 9, 1, "portfolio mean w'mu", f"=MMULT(TRANSPOSE({rw}),{rmu})", "0.0000", array=True)
REF["wSw"] = scalar(ws, 10, 1, "portfolio variance w'Sigma w", f"=MMULT(TRANSPOSE({rw}),MMULT({rS},{rw}))", "0.0000", array=True)
rAp = matrix(ws, 12, 1, d.APORT, "A (two portfolios)")
arr(ws, 12, 5, 2, 1, f"=MMULT({rAp},{rmu})", "A mu", "0.0000")
rASA = arr(ws, 12, 7, 2, 2, f"=MMULT({rAp},MMULT({rS},TRANSPOSE({rAp})))", "A Sigma A'", "0.0000")
REF["ASA12"] = "H13"
sim = d.simulated_returns()
for j, h in enumerate(["Month", "Asset 1", "Asset 2", "Asset 3", "Portfolio w'r"]):
    x = ws.cell(row=17, column=1 + j, value=h); x.font = HEAD; x.fill = SEPIA; x.border = BOX
for i in range(len(sim)):
    r = 18 + i; cell(ws, r, 1, i + 1)
    for j in range(3): cell(ws, r, 2 + j, float(sim[i, j]), BLUE, "0.00")
    cell(ws, r, 5, f"=MMULT(B{r}:D{r},$G$5:$G$7)", fmt="0.0000")
last = 17 + len(sim)
lab(ws, 17, 7, "Sample covariance matrix (COVARIANCE.S)", True)
cols3 = ["B", "C", "D"]
for i in range(3):
    for j in range(3):
        cell(ws, 18 + i, 7 + j, f"=_xlfn.COVARIANCE.S({cols3[i]}18:{cols3[i]}{last},{cols3[j]}18:{cols3[j]}{last})", fmt="0.00")
scalar(ws, 22, 7, "w' S w (sample)", "=MMULT(TRANSPOSE(G5:G7),MMULT(G18:I20,G5:G7))", "0.0000", array=True)
scalar(ws, 23, 7, "VAR.S of portfolio column", f"=_xlfn.VAR.S(E18:E{last})", "0.0000")

# =====================================================================
ws = wb.create_sheet("Exercises")
ws.column_dimensions["A"].width = 4; ws.column_dimensions["B"].width = 100; ws.column_dimensions["C"].width = 16
ws["B1"] = "Exercises"; ws["B1"].font = TITLE
ws["B2"] = "Type your answer in the yellow cell. Use the sheets named in each question."; ws["B2"].font = NOTE
ex = [
    ("M1: What is the sum of all four elements of AB? Check that AB and BA are not even the same size.", "=SUM(M1_Operations!F10:G11)"),
    ("M1: For the advertising data x, compute x'x - (i'x)^2/8, the sum of squared deviations from the mean.", "=M1_Operations!E30-M1_Operations!E29^2/8"),
    ("M2: What is the trace of X'X (sum of its diagonal elements)?", "=M2_Shop_Regression!G9+M2_Shop_Regression!H10+M2_Shop_Regression!I11"),
    ("M2: Compute the 3 x 3 determinant |X'X| by cofactor expansion along the first row and compare with MDETERM.",
     "=M2_Shop_Regression!G9*(M2_Shop_Regression!H10*M2_Shop_Regression!I11-M2_Shop_Regression!I10*M2_Shop_Regression!H11)-M2_Shop_Regression!H9*(M2_Shop_Regression!G10*M2_Shop_Regression!I11-M2_Shop_Regression!I10*M2_Shop_Regression!G11)+M2_Shop_Regression!I9*(M2_Shop_Regression!G10*M2_Shop_Regression!H11-M2_Shop_Regression!H10*M2_Shop_Regression!G11)"),
    ("M2: What is the t ratio for H0: b2 = 2 (advertising)? Use b2 and se(b2).", "=(M2_Shop_Regression!G22-2)/M2_Shop_Regression!K31"),
    ("M2: Using Var(b), what is the standard error of b2 + b3? (Var(b2) + Var(b3) + 2 Cov(b2, b3).)",
     "=SQRT(M2_Shop_Regression!H31+M2_Shop_Regression!I32+2*M2_Shop_Regression!H32)"),
    ("M3: Set c = 0.01 in part (c). What is b2 now? What is b2 + 2 b3?", "=M3_Rank!G42"),
    ("M4: Find the value of t for which x = x0 + t d has third element equal to 0.", "=-1/3"),
    ("M5: Is the 2nd leading principal minor of B positive or negative? What does that tell you?", "=M5_Quadratic_Forms!C19"),
    ("M6: Set r = 0.99. What are the condition number and the VIF?", "=SQRT((1+0.99)/(1-0.99))"),
    ("M7: What is the leverage (diagonal element of P) of shop 6? Which shop has the largest leverage?", "=M7_Projections!F10"),
    ("M9: Change the weights to (1/3, 1/3, 1/3). What is the portfolio variance w'Sigma w?",
     "=MMULT({0.333333333333333,0.333333333333333,0.333333333333333},MMULT(M9_Random_Vectors!C5:E7,{0.333333333333333;0.333333333333333;0.333333333333333}))"),
]
for k, (q, f) in enumerate(ex):
    r = 4 + k; ws.cell(row=r, column=1, value=k + 1).font = BOLD
    x = ws.cell(row=r, column=2, value=q); x.font = BLACK; x.alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[r].height = 30
    a = ws.cell(row=r, column=3); a.fill = YELLOW; a.border = BOX; a.number_format = "0.0000"
    if INSTRUCTOR:
        if "MMULT(" in f: ws.cell(row=r, column=3).value = ArrayFormula(f"C{r}", f)
        else: a.value = f
        a.font = BLACK
for s in wb.worksheets:
    if s.title not in ("README", "Exercises"): s.sheet_view.zoomScale = 90
wb.save(OUT); print("saved", OUT)
