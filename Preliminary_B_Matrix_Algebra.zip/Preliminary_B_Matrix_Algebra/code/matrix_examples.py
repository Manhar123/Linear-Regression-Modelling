"""Preliminary Module B -- Matrix Algebra for Regression.
Every number printed in the notes is produced by this script (from matrix_data.py, the same
numbers as Matrix_Practice_Data.xlsx). Run:  python matrix_examples.py
"""
import numpy as np
import sympy as sp
import statsmodels.api as sm
import matrix_data as d

np.set_printoptions(suppress=True, linewidth=120)
A = np.array(d.A, float); B = np.array(d.B, float); C = np.array(d.C, float)
X = np.column_stack([np.ones(8), d.SHOP["adv"], d.SHOP["area"]]); Y = np.array(d.SHOP["sales"], float); n, k = X.shape

print("=== Chapter 2-3: operations ===")
print("AB =\n", A @ B, "\nBA =\n", B @ A, "\n(AB)' =\n", (A @ B).T, "\nB'A' =\n", B.T @ A.T, "\nA'A =\n", A.T @ A)
x = np.array(d.SHOP["adv"], float); i8 = np.ones(8)
print(f"i'x {i8 @ x}, x'x {x @ x}, mean {i8 @ x / (i8 @ i8)}, sum sq dev {x @ x - (i8 @ x)**2 / 8}")
M0 = np.eye(8) - np.outer(i8, i8) / 8; print("M0 x =", M0 @ x, " x'M0x =", x @ M0 @ x)
print("C^2 =\n", C @ C)

print("\n=== Chapter 3: X'X and X'Y for the shop data ===")
XtX = X.T @ X; XtY = X.T @ Y; print("X'X =\n", XtX, "\nX'Y =", XtY, "\nY'Y =", Y @ Y)

print("\n=== Chapter 4: rank ===")
AH = np.column_stack([np.ones(6), d.AH_X2, 2 * np.array(d.AH_X2)])
for nm, M in [("shop X", X), ("A&H X", AH), ("dummy trap X", np.column_stack([np.ones(8), d.SHOP["north"], 1 - np.array(d.SHOP["north"])])),
              ("A (2x3)", A), ("A2", np.array(d.SYS_A2, float))]:
    print(f"rank of {nm}: {np.linalg.matrix_rank(M)}; singular values {np.round(np.linalg.svd(M, compute_uv=False), 6)}")
print("row echelon form of A2:", sp.Matrix(d.SYS_A2).rref())
print("row echelon form of A&H X'X:", sp.Matrix(AH.T @ AH).rref())
print("null space of A&H X:", sp.Matrix(AH).nullspace())
print("rank X'X shop", np.linalg.matrix_rank(XtX), " rank X'X A&H", np.linalg.matrix_rank(AH.T @ AH))
for c in [1, 0.1, 0.01, 1e-6, 1e-12]:
    Xc = np.column_stack([np.ones(8), x, 2 * x + c * np.array(d.NEAR_V)])
    sv = np.linalg.svd(Xc, compute_uv=False)
    print(f"c {c:g}: singular values {sv}, numpy rank {np.linalg.matrix_rank(Xc)}, det X'X {np.linalg.det(Xc.T @ Xc):.6g}, "
          f"cond(X) {sv[0]/sv[-1]:.4g}")
Xc = np.column_stack([np.ones(8), x, 2 * x + np.array(d.NEAR_V)])
bc = np.linalg.solve(Xc.T @ Xc, Xc.T @ Y); print("near-dependence c = 1: X'X\n", Xc.T @ Xc, "\n det", np.linalg.det(Xc.T @ Xc), "b", bc, "b2+2b3", bc[1] + 2 * bc[2])
Xc = np.column_stack([np.ones(8), x, 2 * x + 0.01 * np.array(d.NEAR_V)])
bc = np.linalg.solve(Xc.T @ Xc, Xc.T @ Y); print("c = 0.01: det", np.linalg.det(Xc.T @ Xc), "b", bc, "b2+2b3", bc[1] + 2 * bc[2])

print("\n=== Chapter 5: determinant and inverse ===")
print("det C", np.linalg.det(C), "C^-1\n", np.linalg.inv(C))
print("det X'X", np.linalg.det(XtX))
print("cofactor expansion:", 8 * (284 * 316 - 282 * 282) - 44 * (44 * 316 - 282 * 48) + 48 * (44 * 282 - 284 * 48))
print("terms:", 8 * (284 * 316 - 282 * 282), -44 * (44 * 316 - 282 * 48), 48 * (44 * 282 - 284 * 48))
adj = sp.Matrix(XtX.astype(int)).adjugate(); print("adj(X'X) =", adj)
print("(X'X)^-1 =\n", np.linalg.inv(XtX)); print("(X'X)^-1 * 6816 =\n", np.round(np.linalg.inv(XtX) * 6816, 6))
Xs = X.copy(); Xs[:, 2] *= 10
print(f"area in sq m instead of tens: det X'X {np.linalg.det(Xs.T @ Xs):.6g} (x100 = {6816*100}); b {np.linalg.solve(Xs.T @ Xs, Xs.T @ Y)}")
Xs2 = X.copy(); Xs2[:, 1:] /= 1000
print(f"both regressors divided by 1000: det X'X {np.linalg.det(Xs2.T @ Xs2):.6g}")
print("cond(X'X) shop", np.linalg.cond(XtX), " cond scaled-columns", np.linalg.cond(Xs2.T @ Xs2))
# condition index with columns scaled to unit length (Belsley)
Xu = X / np.sqrt((X**2).sum(axis=0)); sv = np.linalg.svd(Xu, compute_uv=False); print("Belsley condition number shop (unit-length columns):", sv[0] / sv[-1])
Xu2 = Xs2 / np.sqrt((Xs2**2).sum(axis=0)); print("  same after rescaling:", (lambda s: s[0] / s[-1])(np.linalg.svd(Xu2, compute_uv=False)))

print("\n=== Chapter 6: systems ===")
A1 = np.array(d.SYS_A1, float); print("A1 x = b1 solution", np.linalg.solve(A1, d.SYS_b1), "det", np.linalg.det(A1))
print("A1^-1 =\n", np.linalg.inv(A1), "\n10*A1^-1 =\n", np.round(10 * np.linalg.inv(A1), 6))
A2 = sp.Matrix(d.SYS_A2)
for b in [d.SYS_b2_bad, d.SYS_b2_ok]:
    aug = A2.row_join(sp.Matrix(b)); print(f"b {b}: rank A {A2.rank()}, rank [A b] {aug.rank()}, rref {aug.rref()[0].tolist()}")
print("general solution for consistent b:", sp.linsolve((A2, sp.Matrix(d.SYS_b2_ok))))
# normal equations under perfect collinearity: consistent
AHt = sp.Matrix(AH.astype(int)); yAH = sp.Matrix(d.AH_Y)
NE = AHt.T * AHt; rhs = AHt.T * yAH
print("A&H normal equations: rank X'X", NE.rank(), " rank [X'X X'Y]", NE.row_join(rhs).rank())
print("  solutions:", sp.linsolve((NE, rhs)))
bp = np.linalg.pinv(AH) @ np.array(d.AH_Y, float); print("  minimum-norm (pinv) solution", bp, " b2 + 2 b3", bp[1] + 2 * bp[2])
print("  simple regression slope", np.polyfit(d.AH_X2, d.AH_Y, 1))

print("\n=== Chapter 7: quadratic forms ===")
Q1 = np.array(d.Q_PD, float); Q2 = np.array(d.Q_IND, float); xq = np.array(d.Q_X, float)
print("x'Ax", xq @ Q1 @ xq, " x'Bx", xq @ Q2 @ xq, " eig A", np.linalg.eigvalsh(Q1), " eig B", np.linalg.eigvalsh(Q2))
print("B with x = (1,0,0):", Q2[0, 0], " x = (1,-1,0):", np.array([1, -1, 0]) @ Q2 @ np.array([1, -1, 0]))
a = np.array([1, -2, 1.0]); print("a'X'Xa", a @ XtX @ a, " Xa", X @ a)
V = (np.sum((Y - X @ np.linalg.solve(XtX, XtY))**2) / (n - k)) * np.linalg.inv(XtX)
print("eig of X'X", np.linalg.eigvalsh(XtX), " eig Var(b)", np.linalg.eigvalsh(V))
print("dummy-trap X'X eig", np.linalg.eigvalsh(np.array([[8, 4, 4], [4, 4, 0], [4, 0, 4.0]])))

print("\n=== Chapter 8: eigenvalues ===")
E = np.array(d.EIG_A, float); lam, vec = np.linalg.eigh(E); print("eig", lam, "\nvectors\n", vec)
print("C Lambda C' =\n", vec @ np.diag(lam) @ vec.T, "\nC'C =\n", vec.T @ vec)
print("E^-1 via spectral:", vec @ np.diag(1 / lam) @ vec.T, " inv", np.linalg.inv(E))
lamX, vecX = np.linalg.eigh(XtX); print("X'X eigenvalues", lamX, " sum", lamX.sum(), " trace", np.trace(XtX), " product", lamX.prod())
print("cond(X'X) = lmax/lmin", lamX[-1] / lamX[0])
for r in [0, 0.5, 0.9, 0.99, 0.999]:
    print(f"r {r}: eig {1+r:.3f}, {1-r:.3f}; cond sqrt {np.sqrt((1+r)/(1-r)):.2f}; VIF {1/(1-r**2):.2f}")
L = sm.datasets.longley.load_pandas().data; XL = sm.add_constant(L.drop(columns="TOTEMP")).to_numpy(float)
XLu = XL / np.sqrt((XL**2).sum(axis=0)); svL = np.linalg.svd(XLu, compute_uv=False)
print("Longley: condition number (unit-length columns)", svL[0] / svL[-1], " condition indexes", np.round(svL[0] / svL, 1))

print("\n=== Chapter 9: projections and trace ===")
P = X @ np.linalg.inv(XtX) @ X.T; M = np.eye(n) - P
print("trace P", np.trace(P), " trace M", np.trace(M), " max|PP-P|", np.abs(P @ P - P).max(), " max|MX|", np.abs(M @ X).max())
print("leverages h_tt", np.round(np.diag(P), 4), " sum", np.diag(P).sum())
print("eig P", np.round(np.linalg.eigvalsh(P), 10)); print("rank P", np.linalg.matrix_rank(P), " rank M", np.linalg.matrix_rank(M))
print("tr(AB) = tr(BA):", np.trace(A @ B), np.trace(B @ A))
e = M @ Y; print("e = MY", np.round(e, 4), " e'e", e @ e, " Y'MY", Y @ M @ Y)
print("R2 = Y'P M0 ... : ", 1 - (e @ e) / (Y @ M0 @ Y), " TSS", Y @ M0 @ Y)
rng = np.random.RandomState(91); reps = 100000; sig = 2.0
U = rng.randn(reps, n) * sig; RSS = ((U @ M) * U).sum(axis=1)
print(f"Monte Carlo E(e'e): mean {RSS.mean():.4f} vs sigma^2 (n-k) = {sig**2*(n-k)}; mean e'e/n {RSS.mean()/n:.4f}; mean e'e/(n-k) {RSS.mean()/(n-k):.4f}")
# Frisch-Waugh in matrix form
X1 = X[:, :2]; X2c = X[:, 2]; M1 = np.eye(n) - X1 @ np.linalg.inv(X1.T @ X1) @ X1.T
print("FWL: (X2'M1X2)^-1 X2'M1Y =", (X2c @ M1 @ Y) / (X2c @ M1 @ X2c), " full b3", np.linalg.solve(XtX, XtY)[2])

print("\n=== Chapter 10: vector calculus ===")
b = np.linalg.solve(XtX, XtY); print("b", b)
for bb in [np.array([10, 2, 3.0]), b]:
    print(f"b {np.round(bb, 4)}: RSS {np.sum((Y - X @ bb)**2):.4f}, gradient {np.round(-2 * XtY + 2 * XtX @ bb, 6)}")
bt = np.array([10, 2, 3.0]); print("RSS(bt) - RSS(b) =", np.sum((Y - X @ bt)**2) - np.sum((Y - X @ b)**2), " (bt-b)'X'X(bt-b) =", (bt - b) @ XtX @ (bt - b))
# numerical gradient check
h = 1e-6; g = [(np.sum((Y - X @ (bt + h * np.eye(3)[j]))**2) - np.sum((Y - X @ (bt - h * np.eye(3)[j]))**2)) / (2 * h) for j in range(3)]
print("numerical gradient at bt", np.round(g, 4))
# restricted LS: b2 = b3 via Lagrangian
R = np.array([[0, 1, -1.0]]); r = np.array([0.0]); XtXi = np.linalg.inv(XtX)
lam_ = np.linalg.solve(R @ XtXi @ R.T, R @ b - r); bR = b - XtXi @ R.T @ lam_
print("restricted LS b2 = b3:", bR, " lambda", lam_, " RSS_R", np.sum((Y - X @ bR)**2), " RSS_U", np.sum((Y - X @ b)**2))
Xr = np.column_stack([np.ones(8), x + np.array(d.SHOP["area"])]); print("  check by substitution:", np.linalg.lstsq(Xr, Y, rcond=None)[0])

print("\n=== Chapter 11: random vectors ===")
mu = np.array(d.MU); S = np.array(d.SIGMA); w = np.array(d.W); Ap = np.array(d.APORT)
print("w'mu", w @ mu, " w'Sw", w @ S @ w, " A mu", Ap @ mu, "\nA S A'\n", Ap @ S @ Ap.T)
print("eig Sigma", np.linalg.eigvalsh(S), " corr matrix\n", np.round(S / np.sqrt(np.outer(np.diag(S), np.diag(S))), 4))
sim = d.simulated_returns(); Ssim = np.cov(sim.T); print("sample mean", sim.mean(0).round(3), "\nsample cov\n", Ssim.round(3))
print("w'S_hat w", w @ Ssim @ w, " var of portfolio column", np.var(sim @ w, ddof=1))
s2 = np.sum((Y - X @ b)**2) / (n - k); V = s2 * XtXi; c = np.array([0, 1, 1.0])
print("Var(b) =\n", V, "\nse(b2+b3) =", np.sqrt(c @ V @ c), " b2+b3", c @ b, " se", np.sqrt(np.diag(V)))
f = sm.OLS(Y, X).fit(); print("statsmodels check:", f.params, f.bse, f.t_test("x1 + x2 = 0").sd)
# Var(Ay) Monte Carlo
rng = np.random.RandomState(92); Z = rng.multivariate_normal(mu, S, size=200000); Pz = Z @ Ap.T
print("MC Var(Az):\n", np.cov(Pz.T).round(3))
