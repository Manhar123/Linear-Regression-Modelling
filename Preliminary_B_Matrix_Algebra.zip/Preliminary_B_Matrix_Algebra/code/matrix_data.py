"""Synthetic (made-up) data used by Preliminary Module B (matrix algebra).
Imported by build_matrix_workbook.py and matrix_examples.py so both use identical numbers."""
import numpy as np

# Eight kirana shops: monthly sales (Rs '000), advertising (Rs '000), floor area (tens of sq. m), region
SHOP = dict(
    adv=[2, 4, 3, 6, 5, 8, 7, 9],
    area=[3, 5, 6, 4, 8, 6, 9, 7],
    sales=[24, 31, 34, 36, 43, 45, 50, 49],
    north=[1, 0, 1, 1, 0, 0, 1, 0],
)
# Operations sheet
A = [[1, 2, 0], [3, -1, 4]]          # 2 x 3
B = [[2, 1], [0, 3], [-1, 2]]        # 3 x 2
C = [[4, 1], [2, 3]]                 # 2 x 2
# Asteriou-Hall perfect collinearity example
AH_X2 = [1, 2, 3, 4, 5, 6]
AH_Y = [5, 8, 9, 13, 14, 18]
NEAR_V = [1, -1, 0, 1, -1, 0, 1, -1]
# Systems of equations
SYS_A1 = [[2, 1, -1], [1, 3, 2], [1, 0, 1]]; SYS_b1 = [1, 13, 4]   # solution (1, 2, 3)
SYS_A2 = [[1, 2, 3], [2, 1, 4], [3, 3, 7]]   # row 3 = row 1 + row 2: singular
SYS_b2_bad = [6, 7, 10]                        # inconsistent (10 != 6 + 7)
SYS_b2_ok = [6, 7, 13]                         # consistent
# Quadratic forms
Q_PD = [[4, 2, 0], [2, 3, 1], [0, 1, 2]]
Q_IND = [[1, 3, 0], [3, 2, 0], [0, 0, 1]]
Q_X = [1, -2, 1]
# Eigenvalues
EIG_A = [[5, 2], [2, 2]]
EIG_R = 0.9
# Random vectors: three assets (monthly returns, per cent)
MU = [1.0, 0.8, 1.2]
SIGMA = [[16.0, 6.0, 4.0], [6.0, 9.0, -1.5], [4.0, -1.5, 25.0]]
W = [0.5, 0.3, 0.2]
APORT = [[0.5, 0.3, 0.2], [0.0, 0.5, 0.5]]
def simulated_returns(n=240, seed=2026):
    rng = np.random.RandomState(seed)
    L = np.linalg.cholesky(np.array(SIGMA))
    return np.round(np.array(MU) + rng.randn(n, 3) @ L.T, 2)
