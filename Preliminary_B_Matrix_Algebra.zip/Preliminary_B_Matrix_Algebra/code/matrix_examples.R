# Preliminary Module B -- Matrix Algebra for Regression
# R companion to matrix_examples.py. Needs Matrix_Practice_Data.xlsx and the package readxl.
library(readxl)
shop <- read_excel("Matrix_Practice_Data.xlsx", sheet = "M2_Shop_Regression", range = "A4:E12")
X <- as.matrix(shop[, c("Constant", "Advertising", "Area")]); Y <- shop$`Sales Y`; n <- nrow(X); k <- ncol(X)

cat("=== Operations ===\n")
A <- matrix(c(1, 2, 0, 3, -1, 4), 2, byrow = TRUE); B <- matrix(c(2, 1, 0, 3, -1, 2), 3, byrow = TRUE)
print(A %*% B); print(B %*% A); print(t(A %*% B)); print(t(B) %*% t(A)); print(t(A) %*% A)
x <- X[, 2]; i8 <- rep(1, 8); cat(sum(i8 * x), sum(x^2), mean(x), sum(x^2) - sum(x)^2 / 8, "\n")
M0 <- diag(8) - matrix(1 / 8, 8, 8); print(M0 %*% x); print(crossprod(X)); print(crossprod(X, Y))

cat("\n=== Rank ===\n")
X_ah <- cbind(1, 1:6, 2 * (1:6)); X_dt <- cbind(1, c(1, 0, 1, 1, 0, 0, 1, 0), 1 - c(1, 0, 1, 1, 0, 0, 1, 0))
A2 <- matrix(c(1, 2, 3, 2, 1, 4, 3, 3, 7), 3, byrow = TRUE)
for (M in list(X, X_ah, X_dt, A, A2)) cat("rank", qr(M)$rank, " singular values", round(svd(M)$d, 6), "\n")
v <- c(1, -1, 0, 1, -1, 0, 1, -1)
for (cc in c(1, 0.1, 0.01, 1e-6)) { Xc <- cbind(1, x, 2 * x + cc * v); cat(cc, svd(Xc)$d, det(crossprod(Xc)), "\n") }

cat("\n=== Determinant and inverse ===\n")
C <- matrix(c(4, 1, 2, 3), 2, byrow = TRUE); print(det(C)); print(solve(C))
XtX <- crossprod(X); print(det(XtX)); print(solve(XtX)); print(solve(XtX) * det(XtX))   # adjugate

cat("\n=== Systems ===\n")
A1 <- matrix(c(2, 1, -1, 1, 3, 2, 1, 0, 1), 3, byrow = TRUE); print(solve(A1, c(1, 13, 4))); print(10 * solve(A1))
cat(qr(A2)$rank, qr(cbind(A2, c(6, 7, 10)))$rank, qr(cbind(A2, c(6, 7, 13)))$rank, "\n")
print(A2 %*% (c(1, 1, 1) + 2 * c(-5, -2, 3)))
library(MASS); print(ginv(X_ah) %*% c(5, 8, 9, 13, 14, 18))           # minimum-norm solution

cat("\n=== Quadratic forms and eigenvalues ===\n")
Q1 <- matrix(c(4, 2, 0, 2, 3, 1, 0, 1, 2), 3); Q2 <- matrix(c(1, 3, 0, 3, 2, 0, 0, 0, 1), 3); xq <- c(1, -2, 1)
print(c(t(xq) %*% Q1 %*% xq, t(xq) %*% Q2 %*% xq)); print(eigen(Q1)$values); print(eigen(Q2)$values)
print(sapply(1:3, function(j) det(Q1[1:j, 1:j, drop = FALSE])))
a <- c(1, -2, 1); print(t(a) %*% XtX %*% a); print(eigen(XtX)$values)
E <- matrix(c(5, 2, 2, 2), 2); e <- eigen(E); print(e); print(e$vectors %*% diag(e$values) %*% t(e$vectors))
Xu <- sweep(X, 2, sqrt(colSums(X^2)), "/"); d <- svd(Xu)$d; cat("condition number", d[1] / d[3], "\n")

cat("\n=== Projections and trace ===\n")
P <- X %*% solve(XtX) %*% t(X); M <- diag(n) - P
cat(sum(diag(P)), sum(diag(M)), max(abs(P %*% P - P)), max(abs(M %*% X)), "\n"); print(round(diag(P), 4))
e <- M %*% Y; cat("e'e", sum(e^2), "\n")
set.seed(91); U <- matrix(rnorm(100000 * n, 0, 2), ncol = n); RSS <- rowSums((U %*% M) * U)
cat("mean e'e", mean(RSS), " (sigma^2 (n - k) = 20)\n")

cat("\n=== Calculus ===\n")
b <- solve(XtX, crossprod(X, Y)); print(b)
for (bb in list(c(10, 2, 3), as.vector(b))) cat(sum((Y - X %*% bb)^2), -2 * crossprod(X, Y) + 2 * XtX %*% bb, "\n")
R <- matrix(c(0, 1, -1), 1); bR <- b - solve(XtX) %*% t(R) %*% solve(R %*% solve(XtX) %*% t(R)) %*% (R %*% b); print(bR)

cat("\n=== Random vectors ===\n")
mu <- c(1.0, 0.8, 1.2); S <- matrix(c(16, 6, 4, 6, 9, -1.5, 4, -1.5, 25), 3); w <- c(0.5, 0.3, 0.2)
cat(sum(w * mu), t(w) %*% S %*% w, "\n"); Ap <- rbind(c(0.5, 0.3, 0.2), c(0, 0.5, 0.5)); print(Ap %*% S %*% t(Ap))
f <- lm(Y ~ X - 1); V <- vcov(f); print(V); cc <- c(0, 1, 1); cat("se(b2+b3)", sqrt(t(cc) %*% V %*% cc), "\n")
