BASIC FRAMEWORK OF THE SIMPLE LINEAR REGRESSION: THE CLASSICAL LINEAR REGRESSION MODEL, ORDINARY LEAST SQUARES AND ITS ASSUMPTIONS
Module 3 of the course on Linear Regression Models. Manhar Singh, November 2026. Notes: 31 pages.

FOLDERS
  notes/                 PDF of the notes, LaTeX source, and lrm-notes.sty (keep the .sty next to the .tex to compile).
  overleaf_single_file/  The same notes as one self-contained .tex file (style inlined): paste into Overleaf and compile.
  data/                  engel.csv: food expenditure and income of 235 Belgian households (Koenker and Bassett), from Module 2.
  code/                  module3_examples.py reproduces every number in the notes (needs numpy, pandas, statsmodels;
                         it reads engel.csv if present, otherwise loads the same data from statsmodels).
                         module3_examples.R reads engel.csv: copy it from data/ into code/ first. Simulations in R give
                         the same pattern but different decimals.
                         module_3_template.tex, module3_coords.py and build_module3.py regenerate the notes' .tex
                         (the figures' plotted points) if you change the data.

COMPILING: pdflatex, run twice (for the table of contents).
This module has no practice workbook and no instructor material.
NOTE: the R script was not run for this edition; please run it once before class.
