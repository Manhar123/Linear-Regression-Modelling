"""Module 3 -- Basic Framework of the Simple Linear Regression.
Every number printed in the Module 3 notes is produced by this script.
Run from top to bottom:  python module3_examples.py   (reads engel.csv, written by module2_examples.py,
or loads the same data from statsmodels if the file is absent)
"""
import os
import numpy as np
import pandas as pd
import statsmodels.api as sm

engel = pd.read_csv("engel.csv") if os.path.exists("engel.csv") else sm.datasets.engel.load_pandas().data
X = engel["income"].to_numpy(); Y = engel["foodexp"].to_numpy(); n = len(X)

# ---------------------------------------------------------------
print("=== Worked example: five households (Module 1 data) ===")
x5 = np.array([10, 20, 30, 40, 50.]); y5 = np.array([8, 15, 24, 30, 38.])
b5 = ((x5 - x5.mean()) * (y5 - y5.mean())).sum() / ((x5 - x5.mean()) ** 2).sum()
a5 = y5.mean() - b5 * x5.mean()
yhat5 = a5 + b5 * x5; e5 = y5 - yhat5
print(f"beta_hat {b5:.4f}, alpha_hat {a5:.4f}")
print("fitted:", np.round(yhat5, 2), "residuals:", np.round(e5, 2), f"RSS {np.sum(e5**2):.3f}")
print(f"sum x {x5.sum()}, sum y {y5.sum()}, sum xy {np.sum(x5*y5)}, sum x^2 {np.sum(x5**2)}")

# ---------------------------------------------------------------
print("\n=== Experiment 1: one population line, many sample lines ===")
rng = np.random.RandomState(31)
alpha, beta, sigma, ns = 2.0, 0.5, 1.5, 25
xs = np.linspace(1, 20, ns)                       # X fixed in repeated samples
est = []
for r in range(1000):
    y = alpha + beta * xs + sigma * rng.randn(ns)
    b = np.cov(xs, y, ddof=1)[0, 1] / np.var(xs, ddof=1); a = y.mean() - b * xs.mean()
    est.append((a, b))
est = np.array(est)
print(f"true alpha {alpha}, beta {beta}; mean of 1000 estimates: alpha {est[:,0].mean():.4f}, beta {est[:,1].mean():.4f}")
print(f"sd across samples: alpha {est[:,0].std():.4f}, beta {est[:,1].std():.4f}; "
      f"range of beta_hat {est[:,1].min():.3f} to {est[:,1].max():.3f}")
first5 = est[:5]; print("first five sample lines (a, b):", np.round(first5, 3).tolist())

# ---------------------------------------------------------------
print("\n=== Experiment 2: four ways to fit a line (Engel data, sorted by income) ===")
o = np.argsort(X); xo, yo = X[o], Y[o]
def line_through(x1, y1, x2, y2):
    b = (y2 - y1) / (x2 - x1); return y1 - b * x1, b
fits = {
    "first and last observation": line_through(xo[0], yo[0], xo[-1], yo[-1]),
    "average of first two / last two": line_through(xo[:2].mean(), yo[:2].mean(), xo[-2:].mean(), yo[-2:].mean()),
    "group means (lower / upper half)": line_through(xo[:n//2].mean(), yo[:n//2].mean(), xo[n//2:].mean(), yo[n//2:].mean()),
}
res = sm.OLS(Y, sm.add_constant(X)).fit()
fits["ordinary least squares"] = tuple(res.params)
for k, (a, b) in fits.items():
    e = Y - a - b * X
    print(f"{k:34s}: a = {a:8.2f}, b = {b:.4f}, sum of residuals = {e.sum():9.1f}, RSS = {np.sum(e**2)/1e6:.3f} million")
e_mean = Y - Y.mean()
print(f"{'horizontal line at mean of Y':34s}: sum of residuals = {e_mean.sum():.1f}, RSS = {np.sum(e_mean**2)/1e6:.3f} million")

# ---------------------------------------------------------------
print("\n=== Experiment 3: OLS by the normal equations, by hand ===")
Sx, Sy, Sxy, Sxx = X.sum(), Y.sum(), (X * Y).sum(), (X ** 2).sum()
b_hat = (Sxy - Sx * Sy / n) / (Sxx - Sx ** 2 / n); a_hat = Y.mean() - b_hat * X.mean()
print(f"n {n}, sum X {Sx:.1f}, sum Y {Sy:.1f}, sum XY {Sxy:.1f}, sum X^2 {Sxx:.1f}")
print(f"by hand: alpha {a_hat:.4f}, beta {b_hat:.6f}; statsmodels: {res.params[0]:.4f}, {res.params[1]:.6f}")
# second-order condition: determinant of the Hessian
H = 2 * np.array([[n, Sx], [Sx, Sxx]]); print(f"Hessian determinant {np.linalg.det(H):.3e} (> 0: minimum)")

# ---------------------------------------------------------------
print("\n=== Experiment 4: four expressions for beta_hat give one number ===")
x = X - X.mean(); y = Y - Y.mean()
forms = {
    "(4.20) raw sums": (Sxy - Sx * Sy / n) / (Sxx - Sx ** 2 / n),
    "deviations": (x * y).sum() / (x ** 2).sum(),
    "Cov/Var": np.cov(X, Y, ddof=1)[0, 1] / np.var(X, ddof=1),
    "r * sY/sX": np.corrcoef(X, Y)[0, 1] * Y.std(ddof=1) / X.std(ddof=1),
}
for k, v in forms.items(): print(f"{k:16s} {v:.10f}")

# ---------------------------------------------------------------
print("\n=== Experiment 5: numerical properties of the OLS line ===")
e = res.resid; yhat = res.fittedvalues
print(f"sum of residuals {e.sum():.2e}")
print(f"line passes through means: a + b*mean(X) = {a_hat + b_hat*X.mean():.4f}, mean(Y) = {Y.mean():.4f}")
print(f"sum X*e {np.sum(X*e):.2e}; corr(X, e) {np.corrcoef(X, e)[0,1]:.2e}; corr(yhat, e) {np.corrcoef(yhat, e)[0,1]:.2e}")
print(f"mean of fitted {yhat.mean():.4f} = mean of Y {Y.mean():.4f}")

# ---------------------------------------------------------------
print("\n=== Experiment 6: units of measurement ===")
r_k = sm.OLS(Y / 1000, sm.add_constant(X / 1000)).fit()
r_x = sm.OLS(Y, sm.add_constant(X / 1000)).fit()
print(f"both in thousands: a {r_k.params[0]:.4f}, b {r_k.params[1]:.4f}")
print(f"income in thousands, food in francs: a {r_x.params[0]:.2f}, b {r_x.params[1]:.2f}")
print(f"elasticity at the means: {b_hat * X.mean() / Y.mean():.3f}")

# ---------------------------------------------------------------
print("\n=== Experiment 7: what breaking an assumption does (snapshots, 2000 samples) ===")
rng = np.random.RandomState(37); reps = 2000
def sim(make_x, make_u, ns=50):
    A, B = [], []
    for _ in range(reps):
        xx = make_x(ns); uu = make_u(ns, xx)
        yy = alpha + beta * xx + uu
        b = np.cov(xx, yy, ddof=1)[0, 1] / np.var(xx, ddof=1); A.append(yy.mean() - b * xx.mean()); B.append(b)
    return np.mean(A), np.mean(B), np.std(B)
xfix = np.linspace(1, 20, 50)
cases = {
    "all assumptions hold":                 (lambda m: xfix, lambda m, xx: sigma * rng.randn(m)),
    "A4 broken: E(u) = 3":                  (lambda m: xfix, lambda m, xx: 3 + sigma * rng.randn(m)),
    "A2 nearly broken: X in [9.9, 10.1]":   (lambda m: np.linspace(9.9, 10.1, m), lambda m, xx: sigma * rng.randn(m)),
    "A3 broken: Cov(X, u) > 0":             (lambda m: xfix, lambda m, xx: 0.15 * (xx - xx.mean()) + sigma * rng.randn(m)),
    "A5 broken: Var(u) rises with X":       (lambda m: xfix, lambda m, xx: 0.25 * xx * rng.randn(m)),
}
for k, (mx, mu) in cases.items():
    a_, b_, sd_ = sim(mx, mu)
    print(f"{k:38s}: mean alpha_hat {a_:7.3f}, mean beta_hat {b_:.4f}, sd beta_hat {sd_:.4f}")

# ---------------------------------------------------------------
# figure coordinates
def coords(xs_, ys_, nd=2): return " ".join(f"({p:.{nd}f},{q:.{nd}f})" for p, q in zip(xs_, ys_))
rng = np.random.RandomState(31)
out = {}
lines = []
for r in range(5):
    yy = alpha + beta * xs + sigma * rng.randn(ns)
    b = np.cov(xs, yy, ddof=1)[0, 1] / np.var(xs, ddof=1); a = yy.mean() - b * xs.mean()
    lines.append((a, b))
    if r == 0: out["samp"] = coords(xs, yy); out["samp_a"], out["samp_b"] = round(a, 4), round(b, 4)
out["lines"] = lines
# small residual picture from the five households
out["hh"] = coords(x5, y5)
out["hh_segs"] = [(float(xv), float(yv), float(fv)) for xv, yv, fv in zip(x5, y5, yhat5)]
out["engel"] = coords(X, Y, 1)
out["fits"] = {k: (round(a, 3), round(b, 5)) for k, (a, b) in fits.items()}
with open("module3_coords.py", "w") as f: f.write("import numpy as np\nCOORDS = " + repr(out) + "\n")
print("\n[figure coordinates written to module3_coords.py]")
