# Module 3 -- Basic Framework of the Simple Linear Regression
# R companion to module3_examples.py. Base R only. Reads engel.csv (exported by module2_examples.py).
# Deterministic results match the notes; simulations give the same pattern, different decimals.

engel <- read.csv("engel.csv")
X <- engel$income; Y <- engel$foodexp; n <- length(X)

cat("=== Worked example: five households ===\n")
x5 <- c(10, 20, 30, 40, 50); y5 <- c(8, 15, 24, 30, 38)
f5 <- lm(y5 ~ x5); print(coef(f5)); print(round(cbind(fitted = fitted(f5), resid = resid(f5)), 2))
cat("RSS:", sum(resid(f5)^2), "\n")

cat("\n=== Experiment 1: one population line, many sample lines ===\n")
set.seed(31); alpha <- 2; beta <- 0.5; sigma <- 1.5; xs <- seq(1, 20, length.out = 25)
est <- t(replicate(1000, { y <- alpha + beta * xs + sigma * rnorm(25); coef(lm(y ~ xs)) }))
print(colMeans(est)); print(apply(est, 2, sd)); print(range(est[, 2]))

cat("\n=== Experiment 2: four ways to fit a line ===\n")
o <- order(X); xo <- X[o]; yo <- Y[o]; h <- n %/% 2
through <- function(x1, y1, x2, y2) { b <- (y2 - y1) / (x2 - x1); c(a = y1 - b * x1, b = b) }
fits <- rbind(first_last = through(xo[1], yo[1], xo[n], yo[n]),
              two_two    = through(mean(xo[1:2]), mean(yo[1:2]), mean(xo[(n-1):n]), mean(yo[(n-1):n])),
              halves     = through(mean(xo[1:h]), mean(yo[1:h]), mean(xo[(h+1):n]), mean(yo[(h+1):n])),
              ols        = unname(coef(lm(Y ~ X))))
print(t(apply(fits, 1, function(f) { e <- Y - f[1] - f[2] * X; c(f, sum_e = sum(e), RSS_mn = sum(e^2) / 1e6) })))
cat("horizontal line at mean: RSS", sum((Y - mean(Y))^2) / 1e6, "million\n")

cat("\n=== Experiment 3: the normal equations by hand ===\n")
Sx <- sum(X); Sy <- sum(Y); Sxy <- sum(X * Y); Sxx <- sum(X^2)
b_hat <- (Sxy - Sx * Sy / n) / (Sxx - Sx^2 / n); a_hat <- mean(Y) - b_hat * mean(X)
print(c(a_hat = a_hat, b_hat = b_hat)); print(coef(lm(Y ~ X)))
cat("Hessian determinant:", det(2 * matrix(c(n, Sx, Sx, Sxx), 2)), "\n")

cat("\n=== Experiment 4: four expressions for beta_hat ===\n")
x <- X - mean(X); y <- Y - mean(Y)
print(c(raw = b_hat, dev = sum(x * y) / sum(x^2), covvar = cov(X, Y) / var(X),
        r_ratio = cor(X, Y) * sd(Y) / sd(X)), digits = 12)

cat("\n=== Experiment 5: numerical properties of the OLS line ===\n")
fit <- lm(Y ~ X); e <- resid(fit); yhat <- fitted(fit)
print(c(sum_e = sum(e), through_means = unname(coef(fit)[1] + coef(fit)[2] * mean(X) - mean(Y)),
        cor_X_e = cor(X, e), cor_yhat_e = cor(yhat, e), mean_yhat_minus_mean_Y = mean(yhat) - mean(Y)))

cat("\n=== Experiment 6: units of measurement ===\n")
print(coef(lm(I(Y / 1000) ~ I(X / 1000)))); print(coef(lm(Y ~ I(X / 1000))))
cat("elasticity at the means:", b_hat * mean(X) / mean(Y), "\n")

cat("\n=== Experiment 7: breaking one assumption at a time ===\n")
set.seed(37); reps <- 2000; xfix <- seq(1, 20, length.out = 50)
sim <- function(make_x, make_u) {
  est <- t(replicate(reps, { x <- make_x(); y <- 2 + 0.5 * x + make_u(x); coef(lm(y ~ x)) }))
  c(alpha = mean(est[, 1]), beta = mean(est[, 2]), sd_beta = sd(est[, 2])) }
print(round(rbind(
  all_hold  = sim(function() xfix, function(x) 1.5 * rnorm(50)),
  A4_Eu_3   = sim(function() xfix, function(x) 3 + 1.5 * rnorm(50)),
  A2_tinyX  = sim(function() seq(9.9, 10.1, length.out = 50), function(x) 1.5 * rnorm(50)),
  A3_covXu  = sim(function() xfix, function(x) 0.15 * (x - mean(x)) + 1.5 * rnorm(50)),
  A5_hetero = sim(function() xfix, function(x) 0.25 * x * rnorm(50))), 4))
