"""Fill the figure placeholders in module_3_template.tex and write
module_3_simple_regression.tex (uses lrm-notes.sty) and a standalone copy."""
from module3_coords import COORDS

t = open("module_3_template.tex").read()
c = dict(COORDS)
lines = c.pop("lines")
srf = []
for i, (a, b) in enumerate(lines):
    opt = "slate,dashed,line width=0.6pt" + ("" if i == len(lines) - 1 else ",forget plot")
    srf.append(f"\\addplot[{opt},domain=0:21] {{{a:.4f}+{b:.4f}*x}};")
c["srflines"] = "\n".join(srf)
segs = c.pop("hh_segs")
c["hhsegs"] = "\n".join(f"\\addplot[rust,line width=1pt] coordinates {{({x},{y}) ({x},{f})}};" for x, y, f in segs)
fits = list(c.pop("fits").values())
for i, (a, b) in enumerate(fits, 1):
    c[f"f{i}"] = f"{a}+{b}*x"
for k in ("samp_a", "samp_b"):
    c.pop(k, None)
for k, v in c.items():
    t = t.replace(f"@@{k}@@", str(v))
assert "@@" not in t, "unfilled placeholder"
open("module_3_simple_regression.tex", "w").write(t)

sty = open("lrm-notes.sty").read()
body = "\n".join(l for l in sty.splitlines()
                 if not l.startswith(("\\NeedsTeXFormat", "\\ProvidesPackage", "\\endinput")))
body = body.replace("\\RequirePackage", "\\usepackage")
block = ("% ===== House style (inlined from lrm-notes.sty) =====\n\\makeatletter\n" + body +
         "\n\\makeatother\n% ===== End of house style =====\n")
open("standalone/module_3_simple_regression.tex", "w").write(t.replace("\\usepackage{lrm-notes}", block, 1))
print("written")
