"""Builds Multicollinearity_Practice_Data.xlsx (and, with --instructor, the _INSTRUCTOR version) for Module 9.
Every diagnostic is a live Excel formula: CORREL, LINEST (with statistics), VIF = 1/(1 - R^2)."""
import sys
import numpy as np, pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter as L
import module9_data as d

FONT = "Arial"
BLUE = Font(name=FONT, color="0000FF", size=10); BLACK = Font(name=FONT, color="000000", size=10)
BOLD = Font(name=FONT, bold=True, size=10); HEAD = Font(name=FONT, bold=True, color="FFFFFF", size=10)
TITLE = Font(name=FONT, bold=True, size=14, color="785064"); NOTE = Font(name=FONT, italic=True, size=9, color="555555")
SEPIA = PatternFill("solid", fgColor="785064"); LIGHT = PatternFill("solid", fgColor="EDE6DF"); YELLOW = PatternFill("solid", fgColor="FFFF00")
thin = Side(style="thin", color="BBBBBB"); BOX = Border(left=thin, right=thin, top=thin, bottom=thin)
INSTRUCTOR = "--instructor" in sys.argv
OUT = "Multicollinearity_Practice_Data_INSTRUCTOR.xlsx" if INSTRUCTOR else "Multicollinearity_Practice_Data.xlsx"
wb = Workbook()

def cell(ws, r, c, v, font=BLACK, fmt="0.####", fill=None):
    x = ws.cell(row=r, column=c, value=v); x.font = font; x.border = BOX; x.number_format = fmt
    if fill: x.fill = fill
    return x
def lab(ws, r, c, t, bold=False):
    x = ws.cell(row=r, column=c, value=t); x.font = BOLD if bold else BLACK; x.fill = LIGHT; x.border = BOX
def head(ws, r, c, labels):
    for j, h in enumerate(labels):
        x = ws.cell(row=r, column=c + j, value=h); x.font = HEAD; x.fill = SEPIA; x.border = BOX; x.alignment = Alignment(horizontal="center", wrap_text=True)
def title(ws, t, note): ws["A1"] = t; ws["A1"].font = TITLE; ws["A2"] = note; ws["A2"].font = NOTE

def data_block(ws, cols, arrays, fmts):
    head(ws, 4, 1, ["Obs"] + cols)
    n = len(arrays[0])
    for i in range(n):
        cell(ws, 5 + i, 1, i + 1)
        for j, (a, f) in enumerate(zip(arrays, fmts)): cell(ws, 5 + i, 2 + j, float(a[i]), BLUE, f)
    return 5, 4 + n

def colrng(c, r0, r1): return f"{c}{r0}:{c}{r1}"
def multi(cols, r0, r1):
    if len(cols) == 1: return colrng(cols[0], r0, r1)
    return "CHOOSE({" + ",".join(str(i + 1) for i in range(len(cols))) + "}," + ",".join(colrng(c, r0, r1) for c in cols) + ")"

def diagnostics(ws, r, c, names, letters, r0, r1, ycol=None):
    """Correlation matrix, auxiliary R^2, tolerance and VIF for regressors in columns `letters`."""
    lab(ws, r, c, "Correlation matrix", True)
    for j, nm in enumerate(names): lab(ws, r + 1, c + 1 + j, nm, True); lab(ws, r + 2 + j, c, nm, True)
    for i, li in enumerate(letters):
        for j, lj in enumerate(letters): cell(ws, r + 2 + i, c + 1 + j, f"=CORREL({colrng(li, r0, r1)},{colrng(lj, r0, r1)})", fmt="0.0000")
    rr = r + 3 + len(names)
    head(ws, rr, c, ["Regressor", "Aux R^2", "Tolerance", "VIF"])
    for i, (nm, li) in enumerate(zip(names, letters)):
        others = [x for x in letters if x != li]
        cell(ws, rr + 1 + i, c, nm, BOLD)
        cell(ws, rr + 1 + i, c + 1, f"=INDEX(LINEST({colrng(li, r0, r1)},{multi(others, r0, r1)},TRUE,TRUE),3,1)", fmt="0.000000")
        cell(ws, rr + 1 + i, c + 2, f"=1-{L(c+1)}{rr+1+i}", fmt="0.000000")
        cell(ws, rr + 1 + i, c + 3, f"=1/{L(c+2)}{rr+1+i}", fmt="0.0")
    return rr

def regression(ws, r, c, ycol, names, letters, r0, r1, label):
    """Coefficients, standard errors and t ratios from LINEST (whose output order is reversed)."""
    lab(ws, r, c, label, True)
    head(ws, r + 1, c, ["Term", "Coefficient", "Std error", "t"])
    k = len(letters); X = multi(letters, r0, r1); Y = colrng(ycol, r0, r1)
    terms = ["Constant"] + names
    for i, t in enumerate(terms):
        pos = k + 1 if i == 0 else k + 1 - i
        cell(ws, r + 2 + i, c, t, BOLD)
        cell(ws, r + 2 + i, c + 1, f"=INDEX(LINEST({Y},{X},TRUE,TRUE),1,{pos})", fmt="0.0000")
        cell(ws, r + 2 + i, c + 2, f"=INDEX(LINEST({Y},{X},TRUE,TRUE),2,{pos})", fmt="0.0000")
        cell(ws, r + 2 + i, c + 3, f"={L(c+1)}{r+2+i}/{L(c+2)}{r+2+i}", fmt="0.00")
    rr = r + 2 + len(terms)
    lab(ws, rr, c, "R^2"); cell(ws, rr, c + 1, f"=INDEX(LINEST({Y},{X},TRUE,TRUE),3,1)", fmt="0.0000")
    lab(ws, rr + 1, c, "F (overall)"); cell(ws, rr + 1, c + 1, f"=INDEX(LINEST({Y},{X},TRUE,TRUE),4,1)", fmt="0.00")
    return rr + 1

def widths(ws, n=24, w=11):
    for j in range(1, n): ws.column_dimensions[L(j)].width = w

REF = {}
# README
ws = wb.active; ws.title = "README"; ws.column_dimensions["B"].width = 22; ws.column_dimensions["C"].width = 100
ws["B2"] = "Detecting multicollinearity: practice data"; ws["B2"].font = TITLE
ws["B3"] = "Companion workbook to Module 9 of the course on Linear Regression Models (Manhar Singh, November 2026)."; ws["B3"].font = NOTE
rows = [("What this is", "Five data sets with the standard multicollinearity diagnostics computed by live Excel formulas: correlation "
         "matrices (CORREL), auxiliary regressions (LINEST with statistics), tolerance and VIF, and the regressions themselves."),
        ("Data", "Induced, Hidden and Households are synthetic (made-up). Longley is the real US employment data of Longley (1967). "
         "Fertility is the real US data of Whittington, Alm and Peters (1990), as distributed with Wooldridge's textbook."),
        ("Colour legend", "Blue = data. Black = formulas. Yellow = your answers on the Exercises sheet."),
        ("LINEST", "LINEST(y, X, TRUE, TRUE) returns coefficients in REVERSE order of the columns of X, with the constant last; "
         "row 2 holds standard errors, row 3 column 1 holds R^2, row 4 column 1 the F statistic. Non-adjacent X columns are combined with CHOOSE."),
        ("Induced", "25 observations with X3 almost exactly 4 x X2 (correlation 0.999993)."),
        ("Hidden", "60 observations: X4 = X2 + X3 + small noise. No pairwise correlation exceeds 0.68, but every VIF exceeds 140."),
        ("Households", "50 households: consumption, income and wealth (Rs '000 a week); wealth is roughly ten times income."),
        ("Longley", "US employment and six regressors, 1947-1962: the classic collinear data set (Module 8)."),
        ("Fertility", "US general fertility rate, the real personal tax exemption and two of its lags, 1913-1984; the long-run "
         "propensity estimated directly by reparametrisation.")]
for i, (a, b) in enumerate(rows):
    ws.cell(row=5 + i, column=2, value=a).font = BOLD; x = ws.cell(row=5 + i, column=3, value=b); x.font = BLACK
    x.alignment = Alignment(wrap_text=True, vertical="top"); ws.row_dimensions[5 + i].height = 40

# Induced
ws = wb.create_sheet("Induced"); widths(ws); x2, x3, y = d.induced()
title(ws, "Induced multicollinearity", "Y, X2 and X3 for 25 observations (synthetic).")
r0, r1 = data_block(ws, ["Y", "X2", "X3"], [y, x2, x3], ["0.0", "0.0", "0.0"])
rr = diagnostics(ws, 4, 6, ["X2", "X3"], ["C", "D"], r0, r1); REF["ind_vif"] = f"I{rr+1}"
e = regression(ws, 4, 12, "B", ["X2", "X3"], ["C", "D"], r0, r1, "Y on X2 and X3")
e = regression(ws, 13, 12, "B", ["X2"], ["C"], r0, r1, "Y on X2 alone")
e = regression(ws, 21, 12, "B", ["X3"], ["D"], r0, r1, "Y on X3 alone")
e = regression(ws, 29, 12, "C", ["X3"], ["D"], r0, r1, "Auxiliary: X2 on X3")
# Hidden
ws = wb.create_sheet("Hidden"); widths(ws); x2, x3, x4, y = d.hidden()
title(ws, "A dependency hidden from pairwise correlations", "60 observations (synthetic). X4 is close to X2 + X3.")
r0, r1 = data_block(ws, ["Y", "X2", "X3", "X4"], [y, x2, x3, x4], ["0.00"] * 4)
rr = diagnostics(ws, 4, 7, ["X2", "X3", "X4"], ["C", "D", "E"], r0, r1); REF["hid_vif4"] = f"J{rr+3}"; REF["hid_r34"] = "J8"
regression(ws, 4, 13, "B", ["X2", "X3", "X4"], ["C", "D", "E"], r0, r1, "Y on X2, X3, X4")
# Households
ws = wb.create_sheet("Households"); widths(ws); c_, inc, wl = d.households()
title(ws, "Consumption, income and wealth", "50 households, Rs '000 a week (synthetic).")
r0, r1 = data_block(ws, ["Consumption", "Income", "Wealth"], [c_, inc, wl], ["0.00", "0.0", "0"])
rr = diagnostics(ws, 4, 6, ["Income", "Wealth"], ["C", "D"], r0, r1); REF["hh_vif"] = f"I{rr+1}"
regression(ws, 4, 12, "B", ["Income", "Wealth"], ["C", "D"], r0, r1, "Consumption on income and wealth")
regression(ws, 13, 12, "B", ["Income"], ["C"], r0, r1, "Consumption on income")
regression(ws, 21, 12, "B", ["Wealth"], ["D"], r0, r1, "Consumption on wealth")
REF["hh_tinc"] = "O7"
# Longley
ws = wb.create_sheet("Longley"); widths(ws); Lg = pd.read_csv("longley.csv")
title(ws, "Longley (1967): US employment, 1947-1962", "Real data. TOTEMP = total employment (thousands).")
cols = list(Lg.columns); r0, r1 = data_block(ws, cols, [Lg[c].to_numpy() for c in cols], ["0"] + ["0.0"] * 6)
letters = ["C", "D", "E", "F", "G", "H"]
rr = diagnostics(ws, 4, 10, cols[1:], letters, r0, r1); REF["long_vif_gnp"] = f"M{rr+2}"
regression(ws, 4, 16, "B", cols[1:], letters, r0, r1, "TOTEMP on all six")
# Fertility
ws = wb.create_sheet("Fertility"); widths(ws); F = pd.read_csv("fertil3.csv").dropna(subset=["pe_2"])
title(ws, "Fertility and the personal exemption, US 1915-1984", "gfr = births per 1,000 women aged 15-44; pe = real personal exemption ($). d1 = pe_1 - pe, d2 = pe_2 - pe (formulas).")
cols = ["gfr", "pe", "pe_1", "pe_2", "ww2", "pill"]; r0, r1 = data_block(ws, ["Year"] + cols, [F.year.to_numpy()] + [F[c].to_numpy() for c in cols], ["0", "0.00", "0.00", "0.00", "0.00", "0", "0"])
head(ws, 4, 9, ["d1", "d2"])
for i in range(r0, r1 + 1): cell(ws, i, 9, f"=E{i}-D{i}", fmt="0.00"); cell(ws, i, 10, f"=F{i}-D{i}", fmt="0.00")
rr = diagnostics(ws, 4, 12, ["pe", "pe_1", "pe_2", "ww2", "pill"], ["D", "E", "F", "G", "H"], r0, r1)
regression(ws, 4, 18, "C", ["pe", "pe_1", "pe_2", "ww2", "pill"], ["D", "E", "F", "G", "H"], r0, r1, "gfr on pe and two lags")
regression(ws, 16, 18, "C", ["pe (= LRP)", "d1", "d2", "ww2", "pill"], ["D", "I", "J", "G", "H"], r0, r1, "Reparametrised: coefficient on pe = long-run propensity")
REF["lrp"] = "S19"; REF["lrp_se"] = "T19"
# Exercises
ws = wb.create_sheet("Exercises"); ws.column_dimensions["B"].width = 100; ws.column_dimensions["C"].width = 16
ws["B1"] = "Exercises"; ws["B1"].font = TITLE; ws["B2"] = "Type your answer in the yellow cell."; ws["B2"].font = NOTE
ex = [("Induced: what is the VIF of X2? How many times larger is its standard error than with uncorrelated regressors?", f"=Induced!{REF['ind_vif']}"),
      ("Induced: the coefficient on X2 alone is about 1.03 and on X3 alone about 0.26. Why is the second about one quarter of the first?", "=0.25"),
      ("Hidden: what is the largest pairwise correlation among X2, X3 and X4? (Use the correlation matrix.)", "=MAX(Hidden!H7,Hidden!H8,Hidden!I8)"),
      ("Hidden: what is the VIF of X4?", f"=Hidden!{REF['hid_vif4']}"),
      ("Households: what is the t ratio of income in the regression with both income and wealth?", "=Households!O7"),
      ("Households: is the overall F significant at 5%? Report F.", "=Households!M10"),
      ("Longley: which regressor has the largest VIF? Report it.", "=MAX(Longley!M15:M20)"),
      ("Fertility: what is the estimated long-run propensity and its standard error? (Report the LRP.)", "=Fertility!S19"),
      ("Fertility: compute the LRP as the sum of the three lag coefficients from the first regression.", "=Fertility!S7+Fertility!S8+Fertility!S9")]
for k, (q, f) in enumerate(ex):
    r = 4 + k; ws.cell(row=r, column=1, value=k + 1).font = BOLD
    x = ws.cell(row=r, column=2, value=q); x.font = BLACK; x.alignment = Alignment(wrap_text=True, vertical="top"); ws.row_dimensions[r].height = 30
    a = ws.cell(row=r, column=3); a.fill = YELLOW; a.border = BOX; a.number_format = "0.0000"
    if INSTRUCTOR: a.value = f; a.font = BLACK
for s in wb.worksheets:
    if s.title not in ("README", "Exercises"): s.freeze_panes = "A5"
wb.save(OUT); print("saved", OUT)
