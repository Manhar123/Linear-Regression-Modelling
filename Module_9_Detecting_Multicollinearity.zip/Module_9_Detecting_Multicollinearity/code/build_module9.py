"""Fill figure placeholders in module_9_template.tex."""
from module9_coords import COORDS
t = open("module_9_template.tex").read(); c = COORDS
t = t.replace("@@msefull@@", " ".join(f"({b},{mf:.4f})" for b, mf, ms, bi in c["mse"]))
t = t.replace("@@msedrop@@", " ".join(f"({b},{min(ms, 8.9):.4f})" for b, mf, ms, bi in c["mse"]))
names = ["GNP deflator", "GNP", "unemployment", "armed forces", "population", "year"]
styles = ["slate", "rust", "sepia", "black!60,dashed", "slate,dashed", "rust,dotted,line width=1.3pt"]
pp = []
path = [(max(k, 1e-4), b) for k, b in c["ridgepath"]]
for j, (nm, st) in enumerate(zip(names, styles)):
    pp.append(f"\\addplot[{st}] coordinates {{" + " ".join(f"({k:.6f},{max(-1.19, min(2.59, b[j])):.4f})" for k, b in path) + "};")
    pp.append(f"\\addlegendentry{{{nm}}}")
t = t.replace("@@ridgeplots@@", "\n".join(pp))
assert "@@" not in t
open("module_9_detecting_multicollinearity.tex", "w").write(t); print("written")
