# Module 9 -- Detection of Multicollinearity
# R companion to module9_examples.py. Needs Multicollinearity_Practice_Data.xlsx, longley.csv, metal.csv, fertil3.csv
# and the packages readxl, car and MASS. Deterministic results match the notes; simulations give the same pattern.
library(readxl); library(car); library(MASS)
book <- "Multicollinearity_Practice_Data.xlsx"
longley <- read.csv("longley.csv"); metal <- read.csv("metal.csv"); fert <- read.csv("fertil3.csv")
bkw <- function(X) { Xs <- sweep(X, 2, sqrt(colSums(X^2)), "/"); s <- svd(Xs)
  phi <- sweep(s$v^2, 2, s$d^2, "/"); prop <- t(phi / rowSums(phi)); colnames(prop) <- colnames(X)
  round(cbind(index = s$d[1] / s$d, prop), 3) }

cat("=== Experiment 1: induced ===\n")
ind <- read_excel(book, sheet = "Induced", range = "B4:D29")
f <- lm(Y ~ X2 + X3, data = ind); print(summary(f)); print(cor(ind)); print(vif(f))
print(coef(summary(lm(Y ~ X2, data = ind)))); print(coef(summary(lm(Y ~ X3, data = ind)))); print(summary(lm(X2 ~ X3, data = ind)))
print(bkw(model.matrix(f))); print(linearHypothesis(f, "X2 + 4*X3 = 0"))

cat("\n=== Experiment 2: hidden dependency ===\n")
hid <- read_excel(book, sheet = "Hidden", range = "B4:E64")
fh <- lm(Y ~ X2 + X3 + X4, data = hid); print(cor(hid[, -1])); print(vif(fh)); print(summary(fh)); print(bkw(model.matrix(fh)))

cat("\n=== Experiment 3: Longley ===\n")
fL <- lm(TOTEMP ~ ., data = longley); v <- vif(fL); print(cbind(R2 = 1 - 1 / v, tol = 1 / v, VIF = v)); print(mean(v))
print(bkw(model.matrix(fL))); R <- cor(longley[, -1]); n <- 16; k <- 6
fg <- -(n - 1 - (2 * k + 5) / 6) * log(det(R)); cat("Farrar-Glauber", fg, pchisq(fg, k * (k - 1) / 2, lower.tail = FALSE), "\n")

cat("\n=== Experiment 4: fertility ===\n")
F3 <- subset(fert, !is.na(pe_2)); ff <- lm(gfr ~ pe + pe_1 + pe_2 + ww2 + pill, data = F3)
print(summary(ff)); print(vif(ff)); print(linearHypothesis(ff, c("pe = 0", "pe_1 = 0", "pe_2 = 0")))
print(summary(lm(gfr ~ pe + I(pe_1 - pe) + I(pe_2 - pe) + ww2 + pill, data = F3))$coefficients[2, ])

cat("\n=== Experiment 5: remedies ===\n")
DL <- as.data.frame(diff(as.matrix(longley))); fD <- lm(TOTEMP ~ GNPDEFL + GNP + UNEMP + ARMED + POP, data = DL); print(summary(fD)); print(vif(fD))
Z <- scale(longley[, -1]) * sqrt(16 / 15); yz <- scale(longley$TOTEMP) * sqrt(16 / 15)
for (kk in c(0, 0.001, 0.01, 0.1)) print(round(solve(crossprod(Z) / 16 + kk * diag(6), crossprod(Z, yz) / 16), 3))
pc <- prcomp(longley[, -1], scale. = TRUE); print(summary(pc))
cu <- lm(log(va) ~ log(labor) + log(capital), data = metal); cr <- lm(log(va / labor) ~ log(capital / labor), data = metal)
print(c(se_unrestricted = coef(summary(cu))[3, 2], se_restricted = coef(summary(cr))[2, 2]))

cat("\n=== Experiment 6: drop or keep (MSE) ===\n")
set.seed(906); n <- 30; r <- 0.95
a1 <- as.vector(scale(rnorm(n))) * sqrt(n / (n - 1)); a2 <- resid(lm(rnorm(n) ~ a1)); a2 <- a2 / sqrt(mean(a2^2))
z3 <- r * a1 + sqrt(1 - r^2) * a2
for (b3 in c(0, 0.5, 1, 1.25, 2, 3)) {
  est <- replicate(20000, { y <- 1 + a1 + b3 * z3 + 2 * rnorm(n); c(coef(lm(y ~ a1 + z3))[2], coef(lm(y ~ a1))[2]) })
  cat(b3, "MSE full", mean((est[1, ] - 1)^2), "dropped", mean((est[2, ] - 1)^2), "\n") }
