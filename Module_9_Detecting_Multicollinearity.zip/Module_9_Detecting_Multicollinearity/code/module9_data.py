"""Synthetic (made-up) data sets for Module 9, shared by the workbook builder and module9_examples.py."""
import numpy as np

def induced():          # 25 observations; X3 is almost exactly 4 * X2 (cf. Asteriou-Hall's Example 1)
    r = np.random.RandomState(901); x2 = np.round(r.uniform(40, 300, 25), 1)
    x3 = np.round(4 * x2 + r.normal(0, 1.0, 25), 1)
    y = np.round(36 + 0.83 * x2 + r.normal(0, 40, 25), 1)
    return x2, x3, y

def hidden():           # 60 observations; X4 = X2 + X3 + small noise; pairwise correlations are moderate
    r = np.random.RandomState(902); x2 = np.round(r.normal(10, 2, 60), 2); x3 = np.round(r.normal(10, 2, 60), 2)
    x4 = np.round(x2 + x3 + r.normal(0, 0.15, 60), 2); y = np.round(5 + 1.0 * x2 + 1.0 * x3 + 0.5 * x4 + r.normal(0, 2, 60), 2)
    return x2, x3, x4, y

def households():       # 50 households: weekly consumption, income and wealth (Rs '000), Gujarati-style
    r = np.random.RandomState(903); inc = np.round(r.uniform(8, 30, 50), 1)
    wealth = np.round(10 * inc + r.normal(0, 6, 50), 0)
    cons = np.round(2 + 0.5 * inc + 0.02 * wealth + r.normal(0, 1.5, 50), 2)
    return cons, inc, wealth
