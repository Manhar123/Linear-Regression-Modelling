"""Module 9 -- Detection of Multicollinearity (and what to do about it).
Every number printed in the Module 9 notes is produced by this script.
Needs longley.csv (Module 8), metal.csv (Module 7) and fertil3.csv (Wooldridge data, written here from the
Python package `wooldridge`). Run:  python module9_examples.py
"""
import numpy as np, pandas as pd
from scipy import stats
import statsmodels.api as sm, statsmodels.formula.api as smf
import module9_data as d
np.set_printoptions(suppress=True, linewidth=130)
longley = pd.read_csv("longley.csv"); metal = pd.read_csv("metal.csv"); fert = pd.read_csv("fertil3.csv")
out = {}

def vifs(X):
    res = {}
    for c in X.columns:
        r2 = sm.OLS(X[c], sm.add_constant(X.drop(columns=c))).fit().rsquared; res[c] = (r2, 1 - r2, 1 / (1 - r2))
    return res

def belsley(X):
    """Condition indexes and variance-decomposition proportions (Belsley, Kuh and Welsch 1980)."""
    Xc = sm.add_constant(X).to_numpy(float); Xs = Xc / np.sqrt((Xc**2).sum(0))
    U, s, Vt = np.linalg.svd(Xs, full_matrices=False); V = Vt.T
    phi = V**2 / s**2; prop = (phi / phi.sum(1, keepdims=True)).T   # rows: dimensions, cols: coefficients
    return s[0] / s, prop

print("=== Experiment 1: induced multicollinearity ===")
x2, x3, y = d.induced(); D = pd.DataFrame({"y": y, "x2": x2, "x3": x3})
print("corr matrix\n", D.corr().round(6))
f = smf.ols("y ~ x2 + x3", D).fit(); print(f.summary().tables[1]); print(f"R2 {f.rsquared:.4f}, F {f.fvalue:.2f} (p {f.f_pvalue:.2e})")
for v in ["x2", "x3"]:
    g = smf.ols(f"y ~ {v}", D).fit(); print(f"y on {v} alone: coef {g.params[v]:.4f} se {g.bse[v]:.4f} t {g.tvalues[v]:.2f} R2 {g.rsquared:.4f}")
a = smf.ols("x2 ~ x3", D).fit(); print(f"aux x2 on x3: coef {a.params['x3']:.5f} se {a.bse['x3']:.6f} t {a.tvalues['x3']:.1f} R2 {a.rsquared:.6f}")
print("VIF", {k: round(v[2], 1) for k, v in vifs(D[["x2", "x3"]]).items()})
ci, pr = belsley(D[["x2", "x3"]]); print("condition indexes", ci.round(1)); print("variance proportions (rows = dims)\n", pr.round(3))
print("se of b2 + 4 b3:", np.sqrt(np.array([0, 1, 4]) @ f.cov_params().to_numpy() @ np.array([0, 1, 4])), " estimate", f.params["x2"] + 4 * f.params["x3"])
out["induced"] = {"b": f.params.round(4).tolist(), "se": f.bse.round(4).tolist()}

print("\n=== Experiment 2: pairwise correlations can miss it ===")
x2, x3, x4, y = d.hidden(); H = pd.DataFrame({"y": y, "x2": x2, "x3": x3, "x4": x4})
print("corr\n", H[["x2", "x3", "x4"]].corr().round(3))
print("aux R2 / VIF", {k: (round(v[0], 4), round(v[2], 1)) for k, v in vifs(H[["x2", "x3", "x4"]]).items()})
fh = smf.ols("y ~ x2 + x3 + x4", H).fit(); print(fh.summary().tables[1]); print(f"R2 {fh.rsquared:.4f}")
ci, pr = belsley(H[["x2", "x3", "x4"]]); print("condition indexes", ci.round(1)); print("proportions\n", pr.round(3))
print("determinant of correlation matrix", np.linalg.det(H[["x2", "x3", "x4"]].corr().to_numpy()))

print("\n=== Experiment 3: Longley, full diagnostics ===")
XL = longley.drop(columns="TOTEMP"); fL = sm.OLS(longley.TOTEMP, sm.add_constant(XL)).fit()
V = vifs(XL); print("aux R2, tolerance, VIF:"); [print(f"  {k:8s} {v[0]:.5f} {v[1]:.5f} {v[2]:9.1f}") for k, v in V.items()]
print(f"overall R2 {fL.rsquared:.5f} -> Klein's rule flags:", [k for k, v in V.items() if v[0] > fL.rsquared])
print("mean VIF", np.mean([v[2] for v in V.values()]))
ci, pr = belsley(XL); names = ["const"] + list(XL.columns)
print("condition indexes", ci.round(1))
print(pd.DataFrame(pr, columns=names, index=[f"dim{i+1}" for i in range(7)]).round(3))
R = XL.corr().to_numpy(); print("det(R)", np.linalg.det(R), " eig R", np.linalg.eigvalsh(R).round(5))
lam, vec = np.linalg.eigh(R); print("eigenvector of smallest eigenvalue of R:", dict(zip(XL.columns, vec[:, 0].round(3))))
# Farrar-Glauber chi-square of the correlation matrix
n, k = len(XL), XL.shape[1]; fg = -(n - 1 - (2 * k + 5) / 6) * np.log(np.linalg.det(R)); print(f"Farrar-Glauber chi2 {fg:.1f}, df {k*(k-1)//2}, p {stats.chi2.sf(fg, k*(k-1)//2):.2e}")
out["longley_vif"] = {k: v[2] for k, v in V.items()}; out["longley_ci"] = ci.tolist(); out["longley_prop"] = pr.tolist()

print("\n=== Experiment 4: distributed lag of the personal exemption (Wooldridge fertil3) ===")
F3 = fert.dropna(subset=["pe_2"]).copy()
ff = smf.ols("gfr ~ pe + pe_1 + pe_2 + ww2 + pill", F3).fit(); print(ff.summary().tables[1]); print(f"n {int(ff.nobs)} R2 {ff.rsquared:.4f}")
print("corr of lags\n", F3[["pe", "pe_1", "pe_2"]].corr().round(3))
print("VIF", {k: round(v[2], 1) for k, v in vifs(F3[["pe", "pe_1", "pe_2", "ww2", "pill"]]).items()})
print(ff.f_test("pe = 0, pe_1 = 0, pe_2 = 0"))
lrp = ff.params[["pe", "pe_1", "pe_2"]].sum(); print(ff.t_test("pe + pe_1 + pe_2 = 0"))
F3["d1"] = F3.pe_1 - F3.pe; F3["d2"] = F3.pe_2 - F3.pe
fr = smf.ols("gfr ~ pe + d1 + d2 + ww2 + pill", F3).fit(); print(f"reparametrised: coef on pe = LRP {fr.params['pe']:.4f} se {fr.bse['pe']:.4f} t {fr.tvalues['pe']:.2f}")
print("VIF after reparametrisation", {k: round(v[2], 2) for k, v in vifs(F3[["pe", "d1", "d2", "ww2", "pill"]]).items()})

print("\n=== Experiment 5: remedies on Longley ===")
# (a) drop: shown in Module 8. (b) transform: real GNP per head, differences
L2 = longley.copy(); L2["RGNP"] = L2.GNP / L2.GNPDEFL; L2["RGNPpc"] = L2.RGNP / L2.POP * 1000
fT = sm.OLS(L2.TOTEMP, sm.add_constant(L2[["RGNP", "UNEMP", "ARMED", "YEAR"]])).fit()
print("real GNP model:", fT.params.round(4).to_dict(), "t", fT.tvalues.round(2).to_dict(), f"R2 {fT.rsquared:.4f}")
print("  VIF", {k: round(v[2], 1) for k, v in vifs(L2[["RGNP", "UNEMP", "ARMED", "YEAR"]]).items()})
DL = longley.diff().dropna(); fD = sm.OLS(DL.TOTEMP, sm.add_constant(DL[["GNPDEFL", "GNP", "UNEMP", "ARMED", "POP"]])).fit()
print("first differences (YEAR drops out):", fD.params.round(4).to_dict(), "t", fD.tvalues.round(2).to_dict(), f"R2 {fD.rsquared:.4f}")
print("  VIF", {k: round(v[2], 1) for k, v in vifs(DL[["GNPDEFL", "GNP", "UNEMP", "ARMED", "POP"]]).items()})
# (c) ridge trace on standardised data
Z = (XL - XL.mean()) / XL.std(ddof=0); yz = (longley.TOTEMP - longley.TOTEMP.mean()) / longley.TOTEMP.std(ddof=0)
Zm = Z.to_numpy(); ridge = {}
for kk in [0, 0.001, 0.005, 0.01, 0.02, 0.05, 0.1, 0.2]:
    b = np.linalg.solve(Zm.T @ Zm / 16 + kk * np.eye(6), Zm.T @ yz.to_numpy() / 16); ridge[kk] = b
    print(f"ridge k {kk:5}: standardised coefs {np.round(b, 3)}")
out["ridge"] = {str(k): v.tolist() for k, v in ridge.items()}
kgrid = np.concatenate([[0], np.logspace(-4, 0, 40)])
out["ridgepath"] = [(float(kk), np.linalg.solve(Zm.T @ Zm / 16 + kk * np.eye(6), Zm.T @ yz.to_numpy() / 16).tolist()) for kk in kgrid]
# (d) principal components
lamz, vecz = np.linalg.eigh(Zm.T @ Zm / 16); order = np.argsort(lamz)[::-1]; lamz, vecz = lamz[order], vecz[:, order]
print("PC variance shares", (lamz / lamz.sum()).round(4)); print("PC1 loadings", dict(zip(XL.columns, vecz[:, 0].round(3))))
PC = Zm @ vecz[:, :3]; fP = sm.OLS(yz, sm.add_constant(PC)).fit(); print(f"PCR on 3 components: R2 {fP.rsquared:.4f}, t {fP.tvalues.round(2).tolist()}")
bP = vecz[:, :3] @ fP.params[1:].to_numpy(); print("implied standardised coefs", dict(zip(XL.columns, bP.round(3))))
# (e) prior information: Cobb-Douglas CRS on metal data
metal["ll"], metal["lk"], metal["lq"] = np.log(metal.labor), np.log(metal.capital), np.log(metal.va)
cu = smf.ols("lq ~ ll + lk", metal).fit(); cr = smf.ols("I(lq-ll) ~ I(lk-ll)", metal).fit()
print(f"metal: corr(lnL,lnK) {metal.ll.corr(metal.lk):.3f}; VIF {1/(1-metal.ll.corr(metal.lk)**2):.2f}; unrestricted beta {cu.params['lk']:.4f} ({cu.bse['lk']:.4f}); "
      f"restricted beta {cr.params.iloc[1]:.4f} ({cr.bse.iloc[1]:.4f})")

print("\n=== Experiment 6: to drop or not to drop (MSE, Monte Carlo) ===")
rng = np.random.RandomState(906); n = 30; reps = 20000; r = 0.95; mc = []
a1 = rng.randn(n); a2 = rng.randn(n); a1 = (a1 - a1.mean()) / a1.std(); a2 = a2 - a2.mean(); a2 -= (a2 @ a1) / (a1 @ a1) * a1; a2 /= a2.std()
z2 = a1; z3 = r * a1 + np.sqrt(1 - r**2) * a2; X = np.column_stack([np.ones(n), z2, z3]); Xs = X[:, :2]
P = np.linalg.inv(X.T @ X) @ X.T; Ps = np.linalg.inv(Xs.T @ Xs) @ Xs.T
for b3 in [0.0, 0.25, 0.5, 1.0, 1.25, 1.5, 2.0, 3.0]:
    Y = X @ np.array([1, 1.0, b3]) + 2 * rng.randn(reps, n); bf = Y @ P[1]; bs = Y @ Ps[1]
    mf, ms = np.mean((bf - 1)**2), np.mean((bs - 1)**2); mc.append((b3, mf, ms, bs.mean() - 1))
    print(f"beta3 {b3}: MSE(b2) full {mf:.4f}, dropped {ms:.4f} (bias {bs.mean()-1:+.3f}); {'drop' if ms < mf else 'keep'}")
out["mse"] = mc
th = 2 * np.sqrt((1 - r**2) / n / 1) ; print(f"break-even |beta3| = sigma*sqrt(1/(n var z3 (1-r^2)))... sd of b3 in full model {2*np.sqrt(np.linalg.inv(X.T@X)[2,2]):.4f}")

print("\n=== Experiment 7: a high VIF need not be harmful ===")
rng = np.random.RandomState(907)
for nn in [30, 3000]:
    a1 = rng.randn(nn); z3 = 0.97 * a1 + np.sqrt(1 - 0.97**2) * rng.randn(nn); yv = 1 + 0.5 * a1 + 0.5 * z3 + rng.randn(nn)
    fz = sm.OLS(yv, sm.add_constant(np.column_stack([a1, z3]))).fit(); vf = 1 / (1 - np.corrcoef(a1, z3)[0, 1]**2)
    print(f"n {nn}: VIF {vf:.1f}; b2 {fz.params[1]:.3f} (se {fz.bse[1]:.3f}, t {fz.tvalues[1]:.1f}); b3 {fz.params[2]:.3f} (se {fz.bse[2]:.3f}, t {fz.tvalues[2]:.1f})")

print("\n=== Experiment 8: households (consumption, income, wealth) ===")
c, inc, wl = d.households(); Hh = pd.DataFrame({"cons": c, "inc": inc, "wealth": wl})
print("corr\n", Hh.corr().round(4)); fh2 = smf.ols("cons ~ inc + wealth", Hh).fit(); print(fh2.summary().tables[1]); print(f"R2 {fh2.rsquared:.4f} F {fh2.fvalue:.1f}")
for v in ["inc", "wealth"]:
    g = smf.ols(f"cons ~ {v}", Hh).fit(); print(f"cons on {v}: {g.params[v]:.4f} ({g.bse[v]:.4f}) t {g.tvalues[v]:.2f}")
print("VIF", {k: round(v[2], 2) for k, v in vifs(Hh[["inc", "wealth"]]).items()})
ci, pr = belsley(Hh[["inc", "wealth"]]); print("condition indexes", ci.round(1)); print(pr.round(3))
print(fh2.f_test("inc = 0, wealth = 0"))
with open("module9_coords.py", "w") as fh: fh.write("import numpy as np\nCOORDS = " + repr(out) + "\n")
print("\n[written module9_coords.py]")
