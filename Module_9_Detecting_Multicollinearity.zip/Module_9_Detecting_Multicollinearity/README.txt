DETECTING MULTICOLLINEARITY: CORRELATIONS, AUXILIARY REGRESSIONS, VARIANCE INFLATION, CONDITION INDEXES,
AND WHAT TO DO ABOUT IT
Module 9 of the course on Linear Regression Models. Manhar Singh, November 2026. Notes: 31 pages.

FOLDERS
  notes/                 PDF of the notes, LaTeX source, and lrm-notes.sty (keep the .sty next to the .tex to compile).
  overleaf_single_file/  The same notes as one self-contained .tex file (style inlined): paste into Overleaf and compile.
  workbook/              Multicollinearity_Practice_Data.xlsx: student workbook (sheets Induced, Hidden, Households,
                         Longley, Fertility, Exercises). Blue = data, black = live formulas, yellow = exercise answer cells.
  data/                  longley.csv  Longley (1967) US macroeconomic data (from Module 8)
                         metal.csv    US primary metals industry (Hildebrand and Liu, from Module 7)
                         fertil3.csv  US fertility and the personal tax exemption, 1913-1984 (Wooldridge FERTIL3)
  code/                  module9_examples.py reproduces every number in the notes (needs numpy, pandas, scipy, statsmodels;
                         imports module9_data.py, which generates the synthetic Induced, Hidden and Households data).
                         module9_examples.R (needs readxl) and module9_examples.inp (GRETL) follow the same steps; the R
                         script also reads the workbook. Copy the CSV files from data/ and the workbook into code/ first.
                         module_9_template.tex, module9_coords.py and build_module9.py regenerate the notes' .tex.
  instructor/            NOT FOR STUDENTS: the instructor workbook with the Exercises answers filled in, and
                         build_module9_workbook.py, which builds both workbooks (run with --instructor for the answer version;
                         needs module9_data.py, longley.csv and fertil3.csv alongside). Keep the builder out of student hands.

COMPILING: pdflatex, run twice (for the table of contents).
NOTE: the R and GRETL scripts were not run for this edition; please run them once before class.
