# Module 0 -- An Introduction to the Linear Regression Course
# R companion to module0_examples.py. Base R only.
# Simulations give the same pattern as the notes but different decimals.

cat("=== Experiment 1: two independent random walks ===\n")
set.seed(7); T <- 200
y <- cumsum(rnorm(T)); x <- cumsum(rnorm(T))
fit <- lm(y ~ x)
dw <- sum(diff(resid(fit))^2) / sum(resid(fit)^2)
cat(sprintf("slope %.3f, t = %.2f, R^2 = %.3f, DW = %.3f\n",
            coef(fit)[2], summary(fit)$coefficients[2, 3], summary(fit)$r.squared, dw))

cat("\n=== Experiments 2 and 3: how often does that happen? ===\n")
set.seed(8); reps <- 2000; rej <- c(random_walk = 0, white_noise = 0, differenced = 0); r2 <- numeric(reps)
tstat <- function(m) summary(m)$coefficients[2, 3]
for (r in 1:reps) {
  y <- cumsum(rnorm(T)); x <- cumsum(rnorm(T))
  m <- lm(y ~ x); r2[r] <- summary(m)$r.squared
  rej["random_walk"] <- rej["random_walk"] + (abs(tstat(m)) > 1.96)
  rej["differenced"] <- rej["differenced"] + (abs(tstat(lm(diff(y) ~ diff(x)))) > 1.96)
  y0 <- rnorm(T); x0 <- rnorm(T)
  rej["white_noise"] <- rej["white_noise"] + (abs(tstat(lm(y0 ~ x0))) > 1.96)
}
print(round(100 * rej / reps, 1)); cat("median R^2 (random walks):", round(median(r2), 3), "\n")
