"""Module 0 -- An Introduction to the Linear Regression Course.
Every number printed in the Module 0 notes is produced by this script.
Run from top to bottom:  python module0_examples.py
"""
import numpy as np
import statsmodels.api as sm
from statsmodels.stats.stattools import durbin_watson

# ---------------------------------------------------------------
print("=== Experiment 1: a regression that passes every naive test and means nothing ===")
rng = np.random.RandomState(7)
T = 200
y = np.cumsum(rng.randn(T))          # two random walks, generated independently
x = np.cumsum(rng.randn(T))
res = sm.OLS(y, sm.add_constant(x)).fit()
print(f"slope {res.params[1]:.3f}, t = {res.tvalues[1]:.2f}, R^2 = {res.rsquared:.3f}, DW = {durbin_watson(res.resid):.3f}")

# ---------------------------------------------------------------
print("\n=== Experiment 2: how often does that happen? ===")
rng = np.random.RandomState(8)
reps = 2000
rej_rw, rej_wn, r2_rw = 0, 0, []
for _ in range(reps):
    y = np.cumsum(rng.randn(T)); x = np.cumsum(rng.randn(T))
    r = sm.OLS(y, sm.add_constant(x)).fit()
    rej_rw += abs(r.tvalues[1]) > 1.96; r2_rw.append(r.rsquared)
    y0 = rng.randn(T); x0 = rng.randn(T)                       # independent white noise
    rej_wn += abs(sm.OLS(y0, sm.add_constant(x0)).fit().tvalues[1]) > 1.96
print(f"random walks : |t| > 1.96 in {100*rej_rw/reps:.1f}% of {reps} samples; median R^2 {np.median(r2_rw):.3f}")
print(f"white noise  : |t| > 1.96 in {100*rej_wn/reps:.1f}% of {reps} samples")

# ---------------------------------------------------------------
print("\n=== Experiment 3: differencing (Module 2) removes the illusion ===")
rng = np.random.RandomState(8)
rej_d = 0
for _ in range(reps):
    y = np.cumsum(rng.randn(T)); x = np.cumsum(rng.randn(T))
    r = sm.OLS(np.diff(y), sm.add_constant(np.diff(x))).fit()
    rej_d += abs(r.tvalues[1]) > 1.96
    rng.randn(T); rng.randn(T)   # keep the random stream aligned with Experiment 2
print(f"first differences: |t| > 1.96 in {100*rej_d/reps:.1f}% of samples")
