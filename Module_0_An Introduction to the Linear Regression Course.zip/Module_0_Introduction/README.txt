AN INTRODUCTION TO THE LINEAR REGRESSION COURSE: ECONOMETRICS, THE STAGES OF APPLIED WORK AND A MAP OF THE NINETEEN MODULES
Module 0 of the course on Linear Regression Models. Manhar Singh, November 2026. Notes: 27 pages.

FOLDERS
  notes/                 PDF of the notes, LaTeX source, and lrm-notes.sty (keep the .sty next to the .tex to compile).
  overleaf_single_file/  The same notes as one self-contained .tex file (style inlined): paste into Overleaf and compile.
  code/                  module0_examples.py reproduces every number in the notes (spurious-regression experiments;
                         needs numpy and statsmodels). module0_examples.R is a base-R companion: same pattern,
                         different decimals because R's random numbers differ.

COMPILING: pdflatex, run twice (for the table of contents).
This module has no practice workbook and no instructor material.
NOTE: the R script was not run for this edition; please run it once before class.
