STATISTICAL INFERENCE AND LARGE-SAMPLE THEORY: ESTIMATORS, THE LAW OF LARGE NUMBERS, THE CENTRAL LIMIT THEOREM,
THE DELTA METHOD AND MAXIMUM LIKELIHOOD
Preliminary Module C of the course on Linear Regression Models. Manhar Singh, November 2026. Notes: 36 pages.

FOLDERS
  notes/                 PDF of the notes, LaTeX source, and lrm-notes.sty (keep the .sty next to the .tex to compile).
  overleaf_single_file/  The same notes as one self-contained .tex file (style inlined): paste into Overleaf and compile.
  workbook/              Student practice workbook (blue = data, black = live formulas, yellow = exercise answer cells).
  code/                  Python and R scripts that reproduce every number in the notes.
  instructor/            NOT FOR STUDENTS: instructor workbook with answers filled in, and the scripts that build the workbooks.
                         (The builder scripts can regenerate the instructor answers, so keep them out of student hands.)

COMPILING: pdflatex, run twice (for the table of contents). Uses pgfplots, natbib, listings.
NOTE: the R scripts were written to mirror the Python but were not run for this edition; please run them once before class.
References were added from knowledge of the literature; check volumes and pages before quoting formally.

RUNNING THE CODE: infer_examples.py needs numpy, pandas, scipy and statsmodels; it reads macro.csv, engel.csv and wage2.csv
(included in code/) and imports infer_data.py. It writes infer_coords.py, from which build_modulePC.py fills
module_PC_template.tex to produce module_PC_inference.tex (copy notes/lrm-notes.sty into code/ to compile it there).
