"""Fill figure placeholders in module_PC_template.tex."""
import numpy as np
from infer_coords import COORDS
t = open("module_PC_template.tex").read(); c = COORDS
clip = lambda v, a, b: max(a, min(b, v))
t = t.replace("@@llndie@@", " ".join(f"({i},{dm:.4f})" for i, dm, cm in c["lln"]))
t = t.replace("@@llncau@@", " ".join(f"({i},{clip(cm,-5.9,5.9):.4f})" for i, dm, cm in c["lln"]))
def hist(counts, lo, hi):
    e = np.linspace(lo, hi, len(counts) + 1); w = e[1] - e[0]; dens = [k / (500 * w) for k in counts]
    return " ".join(f"({x:.4f},{v:.4f})" for x, v in zip(e, dens + [dens[-1]]))
t = t.replace("@@clt1@@", hist(c["clt"][1], 0, 8)).replace("@@clt5@@", hist(c["clt"][5], 0, 5)).replace("@@clt30@@", hist(c["clt"][30], 0, 5))
assert "@@" not in t
open("module_PC_inference.tex", "w").write(t); print("written")
