# Preliminary Module C -- Statistical Inference and Large-Sample Theory
# R companion to infer_examples.py. Needs Inference_Practice_Data.xlsx, macro.csv, engel.csv, wage2.csv;
# packages readxl and car. Workbook-based results match the notes; simulations give the same pattern.
library(readxl); library(car)
book <- "Inference_Practice_Data.xlsx"
macro <- read.csv("macro.csv"); engel <- read.csv("engel.csv"); wage <- read.csv("wage2.csv")

cat("=== Estimators ===\n")
S <- as.matrix(read_excel(book, sheet = "C1_Estimators", range = "B4:K204"))
est <- cbind(mean = rowMeans(S), median = apply(S, 1, median), first = S[, 1])
print(rbind(average = colMeans(est), variance = apply(est, 2, function(v) mean((v - mean(v))^2)), MSE = colMeans((est - 50)^2)))
set.seed(311); Sb <- matrix(rnorm(2e6, 50, 10), ncol = 10); dev <- rowSums((Sb - rowMeans(Sb))^2)
print(sapply(c(9, 10, 11), function(d) mean((dev / d - 100)^2)))         # about 2222, 1900, 1818

cat("\n=== Law of large numbers ===\n")
L <- read_excel(book, sheet = "C2_LLN", range = "A4:D1004")
for (m in c(10, 100, 1000)) cat(m, mean(L$Die[1:m]), mean(L$Cauchy[1:m]), median(L$Cauchy[1:m]), "\n")

cat("\n=== Central limit theorem ===\n")
W <- as.matrix(read_excel(book, sheet = "C3_CLT", range = "B4:AE504"))
for (m in c(1, 5, 30)) { mb <- rowMeans(W[, 1:m, drop = FALSE])
  sk <- mean((mb - mean(mb))^3) / sd(mb)^3
  cat(sprintf("n %2d: sd %.3f (theory %.3f), skewness %.3f\n", m, sd(mb), 2 / sqrt(m), sk)) }
set.seed(314)
for (m in c(5, 30, 100, 1000)) { tt <- replicate(20000, { z <- rexp(m, 1 / 2); (mean(z) - 2) / (sd(z) / sqrt(m)) })
  cat(m, mean(abs(tt) > 1.96), mean(tt < -1.96), mean(tt > 1.96), "\n") }

cat("\n=== OLS with skewed errors ===\n")
set.seed(315)
for (m in c(10, 30, 200)) { x <- runif(m, 0, 10)
  rej <- replicate(20000, { y <- 1 + 0.5 * x + (rchisq(m, 1) - 1) / sqrt(2) * 2; s <- summary(lm(y ~ x))$coefficients
    abs((s[2, 1] - 0.5) / s[2, 2]) > qt(0.975, m - 2) })
  cat(m, mean(rej), "\n") }

cat("\n=== Delta method ===\n")
du <- diff(macro$unemp); g <- 100 * diff(log(macro$realgdp)); fo <- lm(du ~ g)
print(deltaMethod(fo, "-b0/b1", parameterNames = c("b0", "b1")))
fw <- lm(lwage ~ educ + exper + tenure + married + black + south + urban, data = wage)
print(deltaMethod(fw, "100*(exp(b5)-1)", parameterNames = paste0("b", 0:7)))
fe <- lm(foodexp ~ income, data = engel); xb <- mean(engel$income)
print(deltaMethod(fe, paste0("b1*", xb, "/(b0+b1*", xb, ")"), parameterNames = c("b0", "b1")))
lc <- log(macro$realcons); ly <- log(macro$realdpi); n0 <- length(lc)
fa <- lm(lc[-1] ~ ly[-1] + lc[-n0]); print(deltaMethod(fa, "b1/(1-b2)", parameterNames = c("b0", "b1", "b2")))

cat("\n=== Maximum likelihood and tests ===\n")
own <- read_excel(book, sheet = "C4_Likelihood", range = "B4:B54")[[1]]; k <- sum(own); n <- length(own); p <- k / n
ll <- function(q) k * log(q) + (n - k) * log(1 - q); print(optimize(ll, c(0.01, 0.99), maximum = TRUE))
for (p0 in c(0.5, 0.6, 0.8)) cat(p0, W = n * (p - p0)^2 / (p * (1 - p)), LR = 2 * (ll(p) - ll(p0)), LM = n * (p - p0)^2 / (p0 * (1 - p0)), "\n")
f3 <- lm(lwage ~ educ + exper + tenure, data = wage); print(logLik(f3)); print(c(AIC(f3), BIC(f3)))  # R counts sigma^2: k = 5
fr <- lm(lwage ~ educ + exper, data = wage); print(2 * (logLik(f3) - logLik(fr)))
