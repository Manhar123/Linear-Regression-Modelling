"""Synthetic (made-up) data for Preliminary Module C (statistical inference and large-sample theory).
Imported by build_inference_workbook.py and infer_examples.py so both use identical numbers."""
import numpy as np

def estimator_samples():      # 200 samples of n = 10 from N(50, 10^2): daily sales of a stall (Rs '00)
    return np.round(np.random.RandomState(301).normal(50, 10, (200, 10)), 1)

def lln_draws():              # 1,000 die rolls and 1,000 standard Cauchy draws
    r = np.random.RandomState(302)
    return r.randint(1, 7, 1000), np.round(r.standard_cauchy(1000), 3)

def clt_draws():              # 500 samples of 30 waiting times, exponential with mean 2 minutes
    return np.round(np.random.RandomState(303).exponential(2.0, (500, 30)), 3)

def smartphone():             # 50 households: 1 = owns a smartphone (true p = 0.7)
    return (np.random.RandomState(304).rand(50) < 0.7).astype(int)

def small_regression():       # 20 observations for the normal likelihood of a regression
    r = np.random.RandomState(305); x = np.round(r.uniform(1, 10, 20), 1)
    y = np.round(3 + 1.5 * x + 2 * r.randn(20), 2)
    return x, y
