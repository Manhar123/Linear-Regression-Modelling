"""Preliminary Module C -- Statistical Inference and Large-Sample Theory.
Every number printed in the notes is produced by this script.
Needs macro.csv and engel.csv (Module 2) and wage2.csv (Module 7). Run:  python infer_examples.py
"""
import numpy as np, pandas as pd
from scipy import stats
import statsmodels.api as sm, statsmodels.formula.api as smf
import infer_data as d
np.set_printoptions(suppress=True, linewidth=120)
macro = pd.read_csv("macro.csv"); engel = pd.read_csv("engel.csv"); wage = pd.read_csv("wage2.csv")
out = {}

print("=== Chapter 2: estimators (200 samples of 10 from N(50, 100)) ===")
S = d.estimator_samples(); n = 10
est = {"mean": S.mean(1), "median": np.median(S, 1), "first obs": S[:, 0]}
for k, v in est.items():
    print(f"{k:10s}: average {v.mean():.3f}, bias {v.mean()-50:+.3f}, variance {v.var():.3f}, MSE {np.mean((v-50)**2):.3f}")
print("theory: mean var 10, median var approx pi/2*10 = 15.7, first obs var 100")
dev = ((S - S.mean(1, keepdims=True))**2).sum(1)
for div, lab in [(n - 1, "n-1"), (n, "n"), (n + 1, "n+1")]:
    v = dev / div; print(f"variance estimator /{lab}: average {v.mean():.2f}, bias {v.mean()-100:+.2f}, var {v.var():.1f}, MSE {np.mean((v-100)**2):.1f}")
print("theory MSE: /n-1", 2e4/9, " /n", 1.9e4/10*1, (2*n-1)*1e4/n**2, " /n+1", 2e4/11)
rng = np.random.RandomState(311); Sb = rng.normal(50, 10, (200000, 10)); devb = ((Sb - Sb.mean(1, keepdims=True))**2).sum(1)
for div in [9, 10, 11]: print(f"  200,000 samples /{div}: MSE {np.mean((devb/div-100)**2):.1f}")

print("\n=== Chapter 3: law of large numbers ===")
die, cau = d.lln_draws()
for m in [10, 100, 1000]: print(f"die running mean after {m}: {die[:m].mean():.3f};  Cauchy running mean {cau[:m].mean():.3f}; Cauchy median {np.median(cau[:m]):.3f}")
out["lln"] = [(int(i), float(die[:i].mean()), float(cau[:i].mean())) for i in list(range(1, 50)) + list(range(50, 1001, 10))]
print("Cauchy max |draw|", np.abs(cau).max(), " at", np.argmax(np.abs(cau)) + 1)
rng = np.random.RandomState(312)
for m in [10, 100, 1000, 10000]:
    xb = rng.randint(1, 7, (5000, m)).mean(1); cheb = (35/12) / (m * 0.1**2)
    print(f"P(|mean - 3.5| > 0.1), n {m}: simulated {np.mean(np.abs(xb-3.5) > 0.1):.4f}; Chebyshev bound {min(cheb,1):.4f}")
# consistency vs unbiasedness
rng = np.random.RandomState(313)
for m in [10, 100, 1000]:
    Z = rng.normal(50, 10, (5000, m)); s2n = Z.var(1); first = Z[:, 0]
    print(f"n {m}: s2 (/n) mean {s2n.mean():.2f} sd {s2n.std():.2f}; first obs mean {first.mean():.2f} sd {first.std():.2f}")

print("\n=== Chapter 4: central limit theorem (exponential, mean 2) ===")
W = d.clt_draws(); clt = {}
for m in [1, 5, 30]:
    mb = W[:, :m].mean(1); sk = stats.skew(mb, bias=False)
    print(f"n {m}: mean of means {mb.mean():.3f}, sd {mb.std(ddof=1):.3f} (theory {2/np.sqrt(m):.3f}), skewness {sk:.3f} (theory {2/np.sqrt(m):.3f}), "
          f"share within mean +/- 1.96 sd {np.mean(np.abs(mb-2) < 1.96*2/np.sqrt(m)):.3f}")
    clt[m] = np.histogram(mb, bins=np.linspace(0, 8, 33) if m == 1 else np.linspace(0, 5, 41))[0].tolist()
out["clt"] = clt
rng = np.random.RandomState(314)
for m in [5, 30, 100, 1000]:
    Z = rng.exponential(2, (20000, m)); tt = (Z.mean(1) - 2) / (Z.std(1, ddof=1) / np.sqrt(m))
    print(f"t statistic with estimated sd, n {m}: P(|t|>1.96) {np.mean(np.abs(tt) > 1.96):.4f}; P(t<-1.96) {np.mean(tt < -1.96):.4f}; P(t>1.96) {np.mean(tt > 1.96):.4f}")

print("\n=== Chapter 5: large-sample OLS with non-normal errors ===")
rng = np.random.RandomState(315); reps = 20000; ols_mc = {}
for errname in ["skewed", "normal"]:
    for m in [10, 30, 200]:
        x = rng.uniform(0, 10, m); X = np.column_stack([np.ones(m), x]); XtXi = np.linalg.inv(X.T @ X)
        if errname == "skewed": U = (rng.chisquare(1, (reps, m)) - 1) / np.sqrt(2) * 2
        else: U = rng.randn(reps, m) * 2
        Y = 1 + 0.5 * x + U; B = Y @ (XtXi @ X.T).T; R = Y - B @ X.T; s2 = (R**2).sum(1) / (m - 2)
        t = (B[:, 1] - 0.5) / np.sqrt(s2 * XtXi[1, 1]); tc = stats.t.ppf(0.975, m - 2)
        ols_mc[(errname, m)] = (np.mean(np.abs(t) > tc), stats.skew(B[:, 1]), stats.kurtosis(B[:, 1]))
        print(f"{errname:6s} errors, n {m:3d}: size of 5% t test {np.mean(np.abs(t) > tc):.4f}; skewness of b {stats.skew(B[:,1]):.3f}; "
              f"excess kurtosis {stats.kurtosis(B[:,1]):.3f}")
print("chi2(1) error skewness", np.sqrt(8), " excess kurtosis 12")

print("\n=== Chapter 6: delta method ===")
du = np.diff(macro.unemp.to_numpy()); g = 100 * np.diff(np.log(macro.realgdp.to_numpy()))
fo = sm.OLS(du, sm.add_constant(g)).fit(); a, b = fo.params; V = fo.cov_params()
ratio = -a / b; G = np.array([-1 / b, a / b**2]); se_r = np.sqrt(G @ V @ G)
print(f"Okun: a {a:.5f} b {b:.5f}; Var(a) {V[0,0]:.7f} Var(b) {V[1,1]:.7f} Cov {V[0,1]:.8f}")
print(f"  -a/b {ratio:.4f}, gradient {G}, se {se_r:.4f}, 95% CI [{ratio-1.96*se_r:.3f}, {ratio+1.96*se_r:.3f}]; annual x4 {4*ratio:.3f} se {4*se_r:.3f}")
out["okun"] = dict(a=float(a), b=float(b), va=float(V[0, 0]), vb=float(V[1, 1]), cab=float(V[0, 1]), n=len(du))
# bootstrap check
rng = np.random.RandomState(316); bs = []
for _ in range(5000):
    idx = rng.randint(0, len(du), len(du)); f_ = np.polyfit(g[idx], du[idx], 1); bs.append(-f_[1] / f_[0])
print(f"  bootstrap se {np.std(bs):.4f}, 2.5-97.5% [{np.percentile(bs,2.5):.3f}, {np.percentile(bs,97.5):.3f}]")
fw = smf.ols("lwage ~ educ + exper + tenure + married + black + south + urban", wage).fit()
bb, sb = fw.params["black"], fw.bse["black"]; pct = np.exp(bb) - 1; se_pct = np.exp(bb) * sb
print(f"wage: black coef {bb:.5f} se {sb:.5f}; exact % effect {100*pct:.2f}% se {100*se_pct:.2f}; CI by delta [{100*(pct-1.96*se_pct):.2f}, {100*(pct+1.96*se_pct):.2f}], "
      f"CI by transforming endpoints [{100*(np.exp(bb-1.96*sb)-1):.2f}, {100*(np.exp(bb+1.96*sb)-1):.2f}]")
out["black"] = dict(b=float(bb), se=float(sb))
um, us = fw.params["urban"], fw.bse["urban"]; print(f"  urban coef {um:.4f} se {us:.4f}; % {100*(np.exp(um)-1):.2f} se {100*np.exp(um)*us:.2f}")
fe = sm.OLS(engel.foodexp, sm.add_constant(engel.income)).fit(); xb, yb = engel.income.mean(), engel.foodexp.mean()
el = fe.params.iloc[1] * xb / yb
Ve = fe.cov_params().to_numpy(); Ge = np.array([-fe.params.iloc[1] * xb / yb**2 * 1, xb / yb - fe.params.iloc[1] * xb**2 / yb**2])
# elasticity at means treating fitted mean: e = b xbar / (a + b xbar)
yhat = fe.params.iloc[0] + fe.params.iloc[1] * xb; el2 = fe.params.iloc[1] * xb / yhat
G2 = np.array([-fe.params.iloc[1] * xb / yhat**2, xb / yhat - fe.params.iloc[1] * xb**2 / yhat**2]); se_el = np.sqrt(G2 @ Ve @ G2)
print(f"Engel: elasticity at means {el:.4f} (= b xbar / (a + b xbar) {el2:.4f}), delta se {se_el:.4f}; a {fe.params.iloc[0]:.3f} b {fe.params.iloc[1]:.5f}")
out["engel"] = dict(a=float(fe.params.iloc[0]), b=float(fe.params.iloc[1]), va=float(Ve[0, 0]), vb=float(Ve[1, 1]), cab=float(Ve[0, 1]), xbar=float(xb))
lc = np.log(macro.realcons.to_numpy()); ly = np.log(macro.realdpi.to_numpy())
dadl = pd.DataFrame({"c": lc[1:], "y": ly[1:], "c1": lc[:-1]}); fa = smf.ols("c ~ y + c1", dadl).fit()
b0, ph = fa.params["y"], fa.params["c1"]; Va = fa.cov_params().loc[["y", "c1"], ["y", "c1"]].to_numpy()
lr = b0 / (1 - ph); Gl = np.array([1 / (1 - ph), b0 / (1 - ph)**2]); se_lr = np.sqrt(Gl @ Va @ Gl)
print(f"ADL consumption (logs): b0 {b0:.4f} ({fa.bse['y']:.4f}), phi {ph:.4f} ({fa.bse['c1']:.4f}), cov {Va[0,1]:.7f}; long-run elasticity {lr:.4f} se {se_lr:.4f}; "
      f"t for long-run = 1: {(lr-1)/se_lr:.2f}; n {int(fa.nobs)}")
out["adl"] = dict(b0=float(b0), ph=float(ph), v00=float(Va[0, 0]), v11=float(Va[1, 1]), v01=float(Va[0, 1]))
# MC: coverage of delta interval for -a/b with strong and weak slope
rng = np.random.RandomState(317); dm = {}
for lab, bt in [("strong slope (t about 13)", -0.27), ("weak slope (t about 1.5)", -0.03)]:
    cov = []; m = 200
    for _ in range(5000):
        x = g[:m] if len(g) >= m else g; y = 0.23 + bt * x + 0.25 * rng.randn(len(x))
        X = np.column_stack([np.ones(len(x)), x]); bh = np.linalg.lstsq(X, y, rcond=None)[0]; r_ = y - X @ bh
        Vh = (r_ @ r_) / (len(x) - 2) * np.linalg.inv(X.T @ X); rr = -bh[0] / bh[1]; Gh = np.array([-1 / bh[1], bh[0] / bh[1]**2])
        se_ = np.sqrt(Gh @ Vh @ Gh); cov.append(abs(rr - (-0.23 / bt)) <= 1.96 * se_)
    tb = bt / np.sqrt(0.25**2 / np.sum((g - g.mean())**2)); dm[lab] = (np.mean(cov), tb)
    print(f"delta-method 95% interval for -a/b, {lab}: coverage {np.mean(cov):.4f}; expected t of slope {tb:.1f}")

print("\n=== Chapter 7: maximum likelihood ===")
sm_ = d.smartphone(); k, N = sm_.sum(), len(sm_); ph_ = k / N
print(f"smartphones: {k} of {N}; p_hat {ph_:.2f}; logL(p_hat) {k*np.log(ph_)+(N-k)*np.log(1-ph_):.4f}; se {np.sqrt(ph_*(1-ph_)/N):.4f}")
for p0 in [0.5, 0.6, 0.7, 0.8]: print(f"  logL({p0}) = {k*np.log(p0)+(N-k)*np.log(1-p0):.4f}")
print(f"  second derivative at p_hat {-k/ph_**2-(N-k)/(1-ph_)**2:.3f}; information n/(p(1-p)) {N/(ph_*(1-ph_)):.3f}")
out["bern"] = dict(k=int(k), n=int(N))
x, y = d.small_regression(); X = np.column_stack([np.ones(20), x]); bols = np.linalg.lstsq(X, y, rcond=None)[0]; rss = np.sum((y - X @ bols)**2)
ll = lambda b, s2: -10 * np.log(2 * np.pi * s2) - np.sum((y - X @ b)**2) / (2 * s2)
print(f"small regression: b {bols}, RSS {rss:.4f}, s2 ML {rss/20:.4f}, s2 OLS {rss/18:.4f}; max logL {ll(bols, rss/20):.4f}; formula {-10*(1+np.log(2*np.pi)+np.log(rss/20)):.4f}")
print(f"  logL at b=(3,1.5), s2=4: {ll(np.array([3,1.5]),4):.4f}; at OLS b with s2 = 4: {ll(bols,4):.4f}")
print("  statsmodels llf:", sm.OLS(y, X).fit().llf)
fw3 = smf.ols("lwage ~ educ + exper + tenure", wage).fit(); nw = fw3.nobs
print(f"wage (Module 7): RSS {fw3.ssr:.3f}, n {nw}, logL formula {-nw/2*(1+np.log(2*np.pi)+np.log(fw3.ssr/nw)):.3f}, statsmodels {fw3.llf:.3f}")
rng = np.random.RandomState(318)
for m in [5, 20, 100]:
    Z = rng.normal(0, 1, (20000, m)); s2ml = Z.var(1)
    print(f"normal variance MLE n {m}: mean {s2ml.mean():.4f} (theory {(m-1)/m:.4f})")

print("\n=== Chapter 8: LR, Wald, LM ===")
def tests(k, N, p0):
    p = k / N
    W = N * (p - p0)**2 / (p * (1 - p)); LM = N * (p - p0)**2 / (p0 * (1 - p0))
    LR = 2 * (k * np.log(p / p0) + (N - k) * np.log((1 - p) / (1 - p0))); return W, LR, LM
for p0 in [0.5, 0.6, 0.8]:
    W, LR, LM = tests(k, N, p0)
    print(f"H0 p = {p0}: W {W:.3f} (p {stats.chi2.sf(W,1):.4f}), LR {LR:.3f} (p {stats.chi2.sf(LR,1):.4f}), LM {LM:.3f} (p {stats.chi2.sf(LM,1):.4f})")
print(f"  score at p0 = 0.6: {k/0.6-(N-k)/0.4:.3f}")
rng = np.random.RandomState(319); size_b = {}
for m in [10, 30, 100]:
    for p0 in [0.5, 0.9]:
        K = rng.binomial(m, p0, 50000).astype(float); p = K / m
        with np.errstate(divide="ignore", invalid="ignore"):
            W = np.where((p > 0) & (p < 1), m * (p - p0)**2 / (p * (1 - p)), np.inf)
            LM = m * (p - p0)**2 / (p0 * (1 - p0))
            t1 = np.where(K > 0, K * np.log(p / p0), 0); t2 = np.where(m - K > 0, (m - K) * np.log((1 - p) / (1 - p0)), 0); LR = 2 * (t1 + t2)
        c = stats.chi2.ppf(0.95, 1); size_b[(m, p0)] = (np.mean(W > c), np.mean(LR > c), np.mean(LM > c))
        print(f"n {m:3d}, p0 {p0}: size W {np.mean(W>c):.4f}  LR {np.mean(LR>c):.4f}  LM {np.mean(LM>c):.4f}")
# regression concentrated log-likelihood check
fr = smf.ols("lwage ~ educ + exper", wage).fit()
print(f"wage LR from llf {2*(fw3.llf-fr.llf):.4f} vs n ln(RSS_R/RSS_U) {nw*np.log(fr.ssr/fw3.ssr):.4f}")

print("\n=== Chapter 9: information criteria ===")
print(f"wage: AIC {fw3.aic:.3f} = -2 logL + 2k = {-2*fw3.llf+2*4:.3f}; BIC {fw3.bic:.3f} = {-2*fw3.llf+4*np.log(nw):.3f}")
out["size_b"] = {f"{m}_{p0}": v for (m, p0), v in size_b.items()}
with open("infer_coords.py", "w") as fh: fh.write("import numpy as np\nCOORDS = " + repr(out) + "\n")
print("\n[written infer_coords.py]")
