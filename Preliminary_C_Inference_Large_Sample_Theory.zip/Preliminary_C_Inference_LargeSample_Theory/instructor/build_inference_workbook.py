"""Builds Inference_Practice_Data.xlsx (and, with --instructor, Inference_Practice_Data_INSTRUCTOR.xlsx):
synthetic practice data for Preliminary Module C, Statistical Inference and Large-Sample Theory.
Inputs are blue; every result is a live Excel formula. Real-data inputs on C5_Delta_Method come from infer_examples.py."""
import sys
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter as L
from openpyxl.worksheet.formula import ArrayFormula
import infer_data as d
from infer_coords import COORDS as C

FONT = "Arial"
BLUE = Font(name=FONT, color="0000FF", size=10); BLACK = Font(name=FONT, color="000000", size=10)
BOLD = Font(name=FONT, bold=True, size=10); HEAD = Font(name=FONT, bold=True, color="FFFFFF", size=10)
TITLE = Font(name=FONT, bold=True, size=14, color="785064"); NOTE = Font(name=FONT, italic=True, size=9, color="555555")
SEPIA = PatternFill("solid", fgColor="785064"); LIGHT = PatternFill("solid", fgColor="EDE6DF"); YELLOW = PatternFill("solid", fgColor="FFFF00")
thin = Side(style="thin", color="BBBBBB"); BOX = Border(left=thin, right=thin, top=thin, bottom=thin)
INSTRUCTOR = "--instructor" in sys.argv
OUT = "Inference_Practice_Data_INSTRUCTOR.xlsx" if INSTRUCTOR else "Inference_Practice_Data.xlsx"
wb = Workbook()

def cell(ws, r, c, v, font=BLACK, fmt="0.####", fill=None):
    x = ws.cell(row=r, column=c, value=v); x.font = font; x.border = BOX; x.number_format = fmt
    if fill: x.fill = fill
    return x
def lab(ws, r, c, text, bold=False):
    x = ws.cell(row=r, column=c, value=text); x.font = BOLD if bold else BLACK; x.fill = LIGHT; x.border = BOX; return x
def head(ws, r, c, labels):
    for j, h in enumerate(labels):
        x = ws.cell(row=r, column=c + j, value=h); x.font = HEAD; x.fill = SEPIA; x.border = BOX
        x.alignment = Alignment(horizontal="center", wrap_text=True)
def title(ws, t, note): ws["A1"] = t; ws["A1"].font = TITLE; ws["A2"] = note; ws["A2"].font = NOTE
def pair(ws, r, c, text, f, fmt="0.####", fill=None, font=BLACK):
    lab(ws, r, c, text); cell(ws, r, c + 1, f, font, fmt, fill); return f"{L(c+1)}{r}"

# README ===============================================================
ws = wb.active; ws.title = "README"
ws.column_dimensions["A"].width = 3; ws.column_dimensions["B"].width = 22; ws.column_dimensions["C"].width = 100
ws["B2"] = "Inference practice data: estimators, large samples and likelihood"; ws["B2"].font = TITLE
ws["B3"] = "Companion workbook to Preliminary Module C of the course on Linear Regression Models (Manhar Singh, November 2026)."; ws["B3"].font = NOTE
rows = [
    ("What this is", "Synthetic (made-up) data generated with fixed random seeds, plus a few coefficient estimates from the real data used "
     "in Modules 5 and 7 (sheet C5). The synthetic data describe no real stalls, customers or households."),
    ("Colour legend", "Blue = inputs. Black = formulas. Yellow = a value you may change, or your answer on the Exercises sheet "
     "(the instructor version fills the answers in)."),
    ("C1_Estimators", "200 samples of 10 daily sales figures from a normal population with mean 50 and variance 100. Three estimators of "
     "the mean (mean, median, first observation) and three of the variance (dividing by n-1, n, n+1): bias, variance and MSE."),
    ("C2_LLN", "1,000 die rolls and 1,000 draws from a Cauchy distribution, with running means. The die mean settles at 3.5; the Cauchy mean never settles."),
    ("C3_CLT", "500 samples of 30 waiting times (exponential, mean 2 minutes). Means of the first 1, 5 and 30 observations: spread, skewness, histograms."),
    ("C4_Likelihood", "Bernoulli likelihood for smartphone ownership in 50 households, on a grid of p; and the normal log-likelihood of a "
     "20-observation regression for any (b1, b2, sigma^2) you type in."),
    ("C5_Delta_Method", "Delta-method standard errors for three non-linear functions of real regression coefficients: Okun's -a/b, "
     "the percentage effect exp(b) - 1 of a dummy, and a long-run elasticity b0 / (1 - phi)."),
    ("C6_Tests", "Wald, likelihood ratio and Lagrange multiplier tests of H0: p = p0 for the smartphone data; change p0 (yellow)."),
    ("Exercises", "Ten exercises with yellow answer cells."),
    ("Reproducing", "infer_examples.py and infer_examples.R reproduce every number in the notes from the same data."),
]
for i, (a, b) in enumerate(rows):
    r = 5 + i; ws.cell(row=r, column=2, value=a).font = BOLD
    x = ws.cell(row=r, column=3, value=b); x.font = BLACK; x.alignment = Alignment(wrap_text=True, vertical="top"); ws.row_dimensions[r].height = 40

# C1 ===================================================================
ws = wb.create_sheet("C1_Estimators"); S = d.estimator_samples()
title(ws, "Estimators of a mean and a variance: 200 samples of n = 10 from N(50, 100)", "Columns B-K are the data (blue). Columns L-Q are the estimates from each sample.")
head(ws, 4, 1, ["Sample"] + [f"x{j}" for j in range(1, 11)] + ["Mean", "Median", "First obs", "s2 (/n-1)", "s2 (/n)", "s2 (/n+1)"])
for i in range(200):
    r = 5 + i; cell(ws, r, 1, i + 1)
    for j in range(10): cell(ws, r, 2 + j, float(S[i, j]), BLUE, "0.0")
    cell(ws, r, 12, f"=AVERAGE(B{r}:K{r})", fmt="0.00"); cell(ws, r, 13, f"=MEDIAN(B{r}:K{r})", fmt="0.00"); cell(ws, r, 14, f"=B{r}", fmt="0.00")
    cell(ws, r, 15, f"=DEVSQ(B{r}:K{r})/9", fmt="0.00"); cell(ws, r, 16, f"=DEVSQ(B{r}:K{r})/10", fmt="0.00"); cell(ws, r, 17, f"=DEVSQ(B{r}:K{r})/11", fmt="0.00")
last = 204
for j in range(1, 18): ws.column_dimensions[L(j)].width = 8
ws.column_dimensions["S"].width = 26
lab(ws, 4, 19, "Truth", True); cell(ws, 4, 20, "mean 50", BOLD); cell(ws, 4, 21, "var 100", BOLD)
cell(ws, 5, 20, 50, BLUE); cell(ws, 5, 21, 100, BLUE); lab(ws, 5, 19, "true value")
head(ws, 7, 19, ["Statistic", "Mean", "Median", "First obs", "s2 /n-1", "s2 /n", "s2 /n+1"])
for k, (nm, f) in enumerate([("average of estimates", "AVERAGE({c}5:{c}%d)" % last), ("bias", None), ("variance (VAR.P)", "_xlfn.VAR.P({c}5:{c}%d)" % last), ("MSE", None)]):
    r = 8 + k; lab(ws, r, 19, nm)
    for j, col in enumerate(["L", "M", "N", "O", "P", "Q"]):
        tv = "$T$5" if j < 3 else "$U$5"
        if nm == "bias": fx = f"={L(20+j)}8-{tv}"
        elif nm == "MSE": fx = f"=SUMPRODUCT(({col}5:{col}{last}-{tv})^2)/COUNT({col}5:{col}{last})"
        else: fx = "=" + f.format(c=col)
        cell(ws, r, 20 + j, fx, fmt="0.00")
lab(ws, 13, 19, "Check: MSE = variance + bias^2 (mean)"); cell(ws, 13, 20, "=T10+T9^2", fmt="0.00")
ws["S15"] = "200 samples are too few to rank the three variance estimators reliably by MSE; see the notes (200,000 samples)."; ws["S15"].font = NOTE

# C2 ===================================================================
ws = wb.create_sheet("C2_LLN"); die, cau = d.lln_draws()
title(ws, "The law of large numbers: running means", "A die (mean 3.5) and a Cauchy variable (no mean).")
head(ws, 4, 1, ["Draw", "Die", "Running mean", "Cauchy", "Running mean", "Running median"])
for i in range(1000):
    r = 5 + i; cell(ws, r, 1, i + 1); cell(ws, r, 2, int(die[i]), BLUE, "0"); cell(ws, r, 3, f"=AVERAGE($B$5:B{r})", fmt="0.0000")
    cell(ws, r, 4, float(cau[i]), BLUE, "0.000"); cell(ws, r, 5, f"=AVERAGE($D$5:D{r})", fmt="0.0000"); cell(ws, r, 6, f"=MEDIAN($D$5:D{r})", fmt="0.0000")
for j, w in zip("ABCDEFGH", [8, 8, 13, 10, 13, 14, 30, 12]): ws.column_dimensions[j].width = w
pair(ws, 4, 7, "Largest |Cauchy draw|", "=MAX(ABS(D5:D1004))", "0.00")
ws.cell(row=4, column=8).value = ArrayFormula("H4", "=MAX(ABS(D5:D1004))")
pair(ws, 5, 7, "Die mean after 10, 100, 1000", "=C14", "0.000"); cell(ws, 5, 9, "=C104", fmt="0.000"); cell(ws, 5, 10, "=C1004", fmt="0.000")
pair(ws, 6, 7, "Cauchy mean after 10, 100, 1000", "=E14", "0.000"); cell(ws, 6, 9, "=E104", fmt="0.000"); cell(ws, 6, 10, "=E1004", fmt="0.000")

# C3 ===================================================================
ws = wb.create_sheet("C3_CLT"); Wd = d.clt_draws()
title(ws, "The central limit theorem: 500 samples of 30 waiting times (exponential, mean 2, sd 2)", "Columns B-AE are data (blue).")
head(ws, 4, 1, ["Sample"] + [f"w{j}" for j in range(1, 31)] + ["Mean of 1", "Mean of 5", "Mean of 30"])
for i in range(500):
    r = 5 + i; cell(ws, r, 1, i + 1)
    for j in range(30): cell(ws, r, 2 + j, float(Wd[i, j]), BLUE, "0.000")
    cell(ws, r, 32, f"=B{r}", fmt="0.000"); cell(ws, r, 33, f"=AVERAGE(B{r}:F{r})", fmt="0.000"); cell(ws, r, 34, f"=AVERAGE(B{r}:AE{r})", fmt="0.000")
for j in range(1, 35): ws.column_dimensions[L(j)].width = 7
ws.column_dimensions["AJ"].width = 30
head(ws, 4, 36, ["Statistic", "n = 1", "n = 5", "n = 30"])
lastc = 504
stats_rows = [("mean", "AVERAGE({c}5:{c}%d)" % lastc), ("standard deviation", "_xlfn.STDEV.S({c}5:{c}%d)" % lastc),
              ("theory sd = 2/sqrt(n)", None), ("skewness (SKEW)", "SKEW({c}5:{c}%d)" % lastc), ("theory skewness = 2/sqrt(n)", None),
              ("share within 2 +/- 1.96 x 2/sqrt(n)", None)]
for k, (nm, f) in enumerate(stats_rows):
    r = 5 + k; lab(ws, r, 36, nm)
    for j, (col, nn) in enumerate([("AF", 1), ("AG", 5), ("AH", 30)]):
        if nm.startswith("theory"): fx = f"=2/SQRT({nn})"
        elif nm.startswith("share"): fx = f'=COUNTIFS({col}5:{col}{lastc},">"&(2-1.96*2/SQRT({nn})),{col}5:{col}{lastc},"<"&(2+1.96*2/SQRT({nn})))/500'
        else: fx = "=" + f.format(c=col)
        cell(ws, r, 37 + j, fx, fmt="0.000")
head(ws, 13, 36, ["Bin upper limit", "count n=1", "count n=5", "count n=30"])
for k, ub in enumerate(np.arange(0.5, 8.01, 0.5)):
    r = 14 + k; cell(ws, r, 36, float(ub), BLUE, "0.0")
    for j, col in enumerate(["AF", "AG", "AH"]):
        cell(ws, r, 37 + j, f'=COUNTIFS({col}5:{col}{lastc},"<="&AJ{r},{col}5:{col}{lastc},">"&(AJ{r}-0.5))', fmt="0")

# C4 ===================================================================
ws = wb.create_sheet("C4_Likelihood"); smv = d.smartphone(); x, y = d.small_regression()
title(ws, "Maximum likelihood", "Part A: Bernoulli. Part B: normal linear regression.")
head(ws, 4, 1, ["Household", "Owns (1/0)"])
for i in range(50): cell(ws, 5 + i, 1, i + 1); cell(ws, 5 + i, 2, int(smv[i]), BLUE, "0")
for j, w in zip("ABCDEFGHIJ", [10, 10, 3, 30, 12, 3, 8, 12, 3, 12]): ws.column_dimensions[j].width = w
kR = pair(ws, 4, 4, "k = number owning", "=SUM(B5:B54)", "0"); nR = pair(ws, 5, 4, "n", "=COUNT(B5:B54)", "0")
pR = pair(ws, 6, 4, "p hat = k/n (MLE)", "=E4/E5", "0.0000")
pair(ws, 7, 4, "log L(p hat)", "=E4*LN(E6)+(E5-E4)*LN(1-E6)", "0.0000")
pair(ws, 8, 4, "second derivative at p hat", "=-E4/E6^2-(E5-E4)/(1-E6)^2", "0.000")
pair(ws, 9, 4, "se = sqrt(-1/second derivative)", "=SQRT(-1/E8)", "0.0000")
pair(ws, 10, 4, "se = sqrt(p(1-p)/n)", "=SQRT(E6*(1-E6)/E5)", "0.0000")
lab(ws, 12, 4, "Try any p (yellow):"); cell(ws, 12, 5, 0.6, BLUE, "0.####", YELLOW)
pair(ws, 13, 4, "log L(p)", "=E4*LN(E12)+(E5-E4)*LN(1-E12)", "0.0000")
pair(ws, 14, 4, "score dlogL/dp at p", "=E4/E12-(E5-E4)/(1-E12)", "0.000")
head(ws, 4, 7, ["p", "log L(p)"])
for k, p in enumerate(np.round(np.arange(0.02, 0.99, 0.02), 2)):
    r = 5 + k; cell(ws, r, 7, float(p), BLUE, "0.00"); cell(ws, r, 8, f"=$E$4*LN(G{r})+($E$5-$E$4)*LN(1-G{r})", fmt="0.000")
pair(ws, 16, 4, "grid maximum of log L", "=MAX(H5:H53)", "0.0000"); pair(ws, 17, 4, "p at the grid maximum", "=INDEX(G5:G53,MATCH(E16,H5:H53,0))", "0.00")
# Part B
lab(ws, 20, 4, "Part B: Y = b1 + b2 X + u, u ~ N(0, s2), n = 20", True)
head(ws, 21, 10, ["X", "Y"])
for i in range(20): cell(ws, 22 + i, 10, float(x[i]), BLUE, "0.0"); cell(ws, 22 + i, 11, float(y[i]), BLUE, "0.00")
ws.column_dimensions["K"].width = 10
lab(ws, 22, 4, "b1 (yellow)"); cell(ws, 22, 5, 3, BLUE, "0.####", YELLOW)
lab(ws, 23, 4, "b2 (yellow)"); cell(ws, 23, 5, 1.5, BLUE, "0.####", YELLOW)
lab(ws, 24, 4, "s2 (yellow)"); cell(ws, 24, 5, 4, BLUE, "0.####", YELLOW)
pair(ws, 25, 4, "log L(b1, b2, s2)", "=-20/2*LN(2*PI()*E24)-SUMPRODUCT((K22:K41-E22-E23*J22:J41)^2)/(2*E24)", "0.0000")
pair(ws, 27, 4, "OLS b2 (SLOPE)", "=SLOPE(K22:K41,J22:J41)", "0.0000"); pair(ws, 28, 4, "OLS b1 (INTERCEPT)", "=INTERCEPT(K22:K41,J22:J41)", "0.0000")
pair(ws, 29, 4, "RSS at OLS", "=SUMPRODUCT((K22:K41-E28-E27*J22:J41)^2)", "0.0000")
pair(ws, 30, 4, "s2 ML = RSS/n", "=E29/20", "0.0000"); pair(ws, 31, 4, "s2 OLS = RSS/(n-2)", "=E29/18", "0.0000")
pair(ws, 32, 4, "max log L = -n/2 (1 + ln 2pi + ln(RSS/n))", "=-20/2*(1+LN(2*PI())+LN(E30))", "0.0000")

# C5 ===================================================================
ws = wb.create_sheet("C5_Delta_Method"); ws.column_dimensions["A"].width = 44
for j in "BCDEF": ws.column_dimensions[j].width = 13
title(ws, "Delta-method standard errors", "Blue inputs are estimates from real regressions (see the notes); change them to try your own.")
o = C["okun"]
lab(ws, 4, 1, "(1) Okun's law: growth that keeps unemployment constant, g = -a/b", True)
pair(ws, 5, 1, "a (intercept)", o["a"], "0.00000", font=BLUE); pair(ws, 6, 1, "b (slope)", o["b"], "0.00000", font=BLUE)
lab(ws, 7, 1, "Var(a), Cov(a,b) / Cov(a,b), Var(b)", True)
cell(ws, 8, 2, o["va"], BLUE, "0.0000000"); cell(ws, 8, 3, o["cab"], BLUE, "0.0000000"); cell(ws, 9, 2, o["cab"], BLUE, "0.0000000"); cell(ws, 9, 3, o["vb"], BLUE, "0.0000000")
pair(ws, 10, 1, "g = -a/b", "=-B5/B6", "0.0000")
lab(ws, 11, 1, "gradient (dg/da, dg/db) = (-1/b, a/b^2)"); cell(ws, 11, 2, "=-1/B6", fmt="0.0000"); cell(ws, 11, 3, "=B5/B6^2", fmt="0.0000")
lab(ws, 12, 1, "se(g) = sqrt(G V G')"); ws.cell(row=12, column=2).value = ArrayFormula("B12", "=SQRT(MMULT(MMULT(B11:C11,B8:C9),TRANSPOSE(B11:C11)))")
cell(ws, 12, 2, ws.cell(row=12, column=2).value, fmt="0.0000")
pair(ws, 13, 1, "95% interval: lower", "=B10-1.96*B12", "0.000"); pair(ws, 14, 1, "95% interval: upper", "=B10+1.96*B12", "0.000")
pair(ws, 15, 1, "annual rate 4g and its se", "=4*B10", "0.000"); cell(ws, 15, 3, "=4*B12", fmt="0.000")
bl = C["black"]
lab(ws, 17, 1, "(2) Percentage effect of a dummy in a log equation, 100(exp(b) - 1)", True)
pair(ws, 18, 1, "b (BLACK, wage equation)", bl["b"], "0.00000", font=BLUE); pair(ws, 19, 1, "se(b)", bl["se"], "0.00000", font=BLUE)
pair(ws, 20, 1, "approximate effect 100 b (%)", "=100*B18", "0.00"); pair(ws, 21, 1, "exact effect 100(exp(b) - 1) (%)", "=100*(EXP(B18)-1)", "0.00")
pair(ws, 22, 1, "delta se = 100 exp(b) se(b)", "=100*EXP(B18)*B19", "0.00")
pair(ws, 23, 1, "95% interval by delta method: lower", "=B21-1.96*B22", "0.00"); cell(ws, 23, 3, "=B21+1.96*B22", fmt="0.00")
pair(ws, 24, 1, "95% interval transforming endpoints: lower", "=100*(EXP(B18-1.96*B19)-1)", "0.00"); cell(ws, 24, 3, "=100*(EXP(B18+1.96*B19)-1)", fmt="0.00")
ad = C["adl"]
lab(ws, 26, 1, "(3) Long-run elasticity in ln C_t = c + b0 ln Y_t + phi ln C_t-1: LR = b0/(1 - phi)", True)
pair(ws, 27, 1, "b0", ad["b0"], "0.00000", font=BLUE); pair(ws, 28, 1, "phi", ad["ph"], "0.00000", font=BLUE)
lab(ws, 29, 1, "Var(b0), Cov / Cov, Var(phi)", True)
cell(ws, 30, 2, ad["v00"], BLUE, "0.0000000"); cell(ws, 30, 3, ad["v01"], BLUE, "0.0000000"); cell(ws, 31, 2, ad["v01"], BLUE, "0.0000000"); cell(ws, 31, 3, ad["v11"], BLUE, "0.0000000")
pair(ws, 32, 1, "long-run elasticity b0/(1 - phi)", "=B27/(1-B28)", "0.0000")
lab(ws, 33, 1, "gradient (1/(1-phi), b0/(1-phi)^2)"); cell(ws, 33, 2, "=1/(1-B28)", fmt="0.0000"); cell(ws, 33, 3, "=B27/(1-B28)^2", fmt="0.0000")
lab(ws, 34, 1, "se"); ws.cell(row=34, column=2).value = ArrayFormula("B34", "=SQRT(MMULT(MMULT(B33:C33,B30:C31),TRANSPOSE(B33:C33)))")
cell(ws, 34, 2, ws.cell(row=34, column=2).value, fmt="0.0000")
pair(ws, 35, 1, "t for H0: long-run elasticity = 1", "=(B32-1)/B34", "0.00")

# C6 ===================================================================
ws = wb.create_sheet("C6_Tests"); ws.column_dimensions["A"].width = 46; ws.column_dimensions["B"].width = 14; ws.column_dimensions["C"].width = 14
title(ws, "Wald, likelihood ratio and Lagrange multiplier tests of H0: p = p0", "Data: the 50 households of sheet C4.")
pair(ws, 4, 1, "k", "=C4_Likelihood!E4", "0"); pair(ws, 5, 1, "n", "=C4_Likelihood!E5", "0"); pair(ws, 6, 1, "p hat", "=B4/B5", "0.0000")
lab(ws, 7, 1, "p0 (yellow)"); cell(ws, 7, 2, 0.6, BLUE, "0.####", YELLOW)
lab(ws, 9, 1, "Statistic", True); lab(ws, 9, 2, "value", True); lab(ws, 9, 3, "p-value (chi2, 1 df)", True)
lab(ws, 10, 1, "Wald W = n (p - p0)^2 / (p(1-p))"); cell(ws, 10, 2, "=B5*(B6-B7)^2/(B6*(1-B6))", fmt="0.000")
lab(ws, 11, 1, "LR = 2[k ln(p/p0) + (n-k) ln((1-p)/(1-p0))]"); cell(ws, 11, 2, "=2*(B4*LN(B6/B7)+(B5-B4)*LN((1-B6)/(1-B7)))", fmt="0.000")
lab(ws, 12, 1, "LM = n (p - p0)^2 / (p0(1-p0))"); cell(ws, 12, 2, "=B5*(B6-B7)^2/(B7*(1-B7))", fmt="0.000")
for r in (10, 11, 12): cell(ws, r, 3, f"=_xlfn.CHISQ.DIST.RT(B{r},1)", fmt="0.0000")
pair(ws, 14, 1, "5% critical value of chi2(1)", "=_xlfn.CHISQ.INV.RT(0.05,1)", "0.000")
pair(ws, 15, 1, "log L(p hat) - log L(p0)", "=C4_Likelihood!E7-(B4*LN(B7)+(B5-B4)*LN(1-B7))", "0.0000")
pair(ws, 16, 1, "score at p0", "=B4/B7-(B5-B4)/(1-B7)", "0.000")

# Exercises ============================================================
ws = wb.create_sheet("Exercises")
ws.column_dimensions["A"].width = 4; ws.column_dimensions["B"].width = 100; ws.column_dimensions["C"].width = 16
ws["B1"] = "Exercises"; ws["B1"].font = TITLE; ws["B2"] = "Type your answer in the yellow cell."; ws["B2"].font = NOTE
ex = [
    ("C1: What is the MSE of the sample median as an estimator of the mean? Is it larger than that of the sample mean?", "=C1_Estimators!U11"),
    ("C1: The theoretical variance of the sample mean is sigma^2/n. What is it here?", "=100/10"),
    ("C2: After how many rolls does the running die mean first stay within 0.1 of 3.5 for the rest of the 1,000 rolls? (Answer: the draw number.)",
     "=MAX(IF(ABS(C2_LLN!C5:C1004-3.5)>=0.1,C2_LLN!A5:A1004))+1"),
    ("C3: By what factor did the standard deviation of the mean fall from n = 1 to n = 30? Compare with sqrt(30).", "=C3_CLT!AK6/C3_CLT!AM6"),
    ("C3: What share of the 500 means of 30 lie within 2 +/- 1.96 x 2/sqrt(30)?", "=C3_CLT!AM10"),
    ("C4: Set p = 0.7 in the yellow cell. What is the score? Why is it not zero?", "=C4_Likelihood!E4/0.7-(C4_Likelihood!E5-C4_Likelihood!E4)/0.3"),
    ("C4: Part B: set b1, b2 and s2 to their ML values. What is the maximised log-likelihood?", "=C4_Likelihood!E32"),
    ("C5: What is the delta-method standard error of the annual growth rate that keeps unemployment constant?", "=C5_Delta_Method!C15"),
    ("C5: For the long-run elasticity, what is the 95% interval (lower limit)?", "=C5_Delta_Method!B32-1.96*C5_Delta_Method!B34"),
    ("C6: Set p0 = 0.8. Which of W, LR and LM is the largest? Report LM.", "=C6_Tests!B5*(C6_Tests!B6-0.8)^2/(0.8*0.2)"),
]
for k, (q, f) in enumerate(ex):
    r = 4 + k; ws.cell(row=r, column=1, value=k + 1).font = BOLD
    x_ = ws.cell(row=r, column=2, value=q); x_.font = BLACK; x_.alignment = Alignment(wrap_text=True, vertical="top"); ws.row_dimensions[r].height = 30
    a = ws.cell(row=r, column=3); a.fill = YELLOW; a.border = BOX; a.number_format = "0.0000"
    if INSTRUCTOR:
        if "IF(" in f: ws.cell(row=r, column=3).value = ArrayFormula(f"C{r}", f)
        else: a.value = f
        a.font = BLACK
for s in wb.worksheets:
    if s.title not in ("README", "Exercises"): s.freeze_panes = "A5"
wb.save(OUT); print("saved", OUT)
