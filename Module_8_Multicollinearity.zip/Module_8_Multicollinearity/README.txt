MULTICOLLINEARITY: PERFECT AND IMPERFECT MULTICOLLINEARITY AND WHAT THEY DO TO OLS
Module 8 of the course on Linear Regression Models. Manhar Singh, November 2026. Notes: 29 pages.

FOLDERS
  notes/                 PDF of the notes, LaTeX source, and lrm-notes.sty (keep the .sty next to the .tex to compile).
  overleaf_single_file/  The same notes as one self-contained .tex file (style inlined): paste into Overleaf and compile.
  data/                  wage2.csv  wages of 935 US men (Wooldridge WAGE2, from Module 7)
                         macro.csv  US quarterly macroeconomic data (from Module 2)
                         longley.csv  Longley (1967) US macroeconomic data, 1947-1962, the classic ill-conditioned regression
                                      (written by this module's Python script from the statsmodels package)
  code/                  module8_examples.py reproduces every number in the notes (needs numpy, pandas, scipy, statsmodels).
                         module8_examples.R and module8_examples.inp (GRETL) follow the same steps.
                         Copy the three CSV files from data/ into code/ before running any script.
                         module_8_template.tex, module8_coords.py and build_module8.py regenerate the notes' .tex
                         (the figures' plotted points) if you change the data.

COMPILING: pdflatex, run twice (for the table of contents).
This module has no practice workbook and no instructor material (Module 9 has the multicollinearity workbook).
NOTE: the R and GRETL scripts were not run for this edition; please run them once before class.
