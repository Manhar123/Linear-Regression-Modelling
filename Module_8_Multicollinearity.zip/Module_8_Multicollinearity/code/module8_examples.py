"""Module 8 -- Multicollinearity.
Every number printed in the Module 8 notes is produced by this script.
Needs wage2.csv (Module 7) and macro.csv (Module 2); the Longley data come with statsmodels
and are written to longley.csv.
Run from top to bottom:  python module8_examples.py
"""
import warnings
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
import statsmodels.formula.api as smf

wage = pd.read_csv("wage2.csv"); macro = pd.read_csv("macro.csv")
longley = sm.datasets.longley.load_pandas().data; longley.to_csv("longley.csv", index=False)

def vif(X):
    """VIF_j = 1/(1-R_j^2) from auxiliary regressions; X excludes the constant."""
    out = {}
    for c in X.columns:
        r2 = sm.OLS(X[c], sm.add_constant(X.drop(columns=c))).fit().rsquared
        out[c] = (r2, 1 / (1 - r2))
    return out

# ---------------------------------------------------------------
print("=== Experiment 1: perfect multicollinearity, the textbook case ===")
X2 = np.arange(1, 7.0); X3 = 2 * X2; Xp = np.column_stack([np.ones(6), X2, X3])
print("rank of X:", np.linalg.matrix_rank(Xp), " det(X'X):", np.linalg.det(Xp.T @ Xp))
print("X'X =\n", Xp.T @ Xp)
v2, v3, c23 = np.var(X2, ddof=1), np.var(X3, ddof=1), np.cov(X2, X3)[0, 1]
print(f"denominator Var(X2)Var(X3) - Cov^2 = {v2*v3 - c23**2}")

# ---------------------------------------------------------------
print("\n=== Experiment 2: perfect multicollinearity in real data (potential experience) ===")
wage["pexper"] = wage.age - wage.educ - 6
Xw = sm.add_constant(wage[["educ", "age", "pexper"]]).to_numpy(float)
print("rank", np.linalg.matrix_rank(Xw), "of", Xw.shape[1], f"; smallest eigenvalue of X'X {np.linalg.eigvalsh(Xw.T @ Xw).min():.2e}")
with warnings.catch_warnings(record=True) as wl:
    warnings.simplefilter("always")
    fp = smf.ols("lwage ~ educ + age + pexper", wage).fit()
    print("statsmodels returns (pinv, minimum-norm):", fp.params.round(5).to_dict(), " R2", round(fp.rsquared, 5))
    print("  warnings issued:", len(wl))
print("  smallest eigenvalue reported:", fp.eigenvals.min())
# other exact solutions: beta + c * null vector, null vector: educ - age + pexper = -6 * const => (6, 1, -1, 1)? check
null = np.array([-6.0, 1.0, -1.0, 1.0]) * 0 + np.linalg.svd(Xw)[2][-1]
null = null / null[3]; print("null vector (scaled so pexper coef = 1):", null.round(6), " max |X null|", np.max(np.abs(Xw @ null)))
b0 = fp.params.to_numpy()
for c_ in [0.0, -0.05, 0.10]:
    bb = b0 + c_ * null; rss = np.sum((wage.lwage - Xw @ bb)**2)
    print(f"  solution with shift {c_:+.2f}: coefs {np.round(bb, 4)}, RSS {rss:.4f}")
f2 = smf.ols("lwage ~ educ + age", wage).fit()
print("identified model lwage ~ educ + age:", f2.params.round(5).to_dict(), f"RSS {f2.ssr:.4f}")
print(f"  combination identified: coef(educ)+... ; actual exper vs potential corr {wage.exper.corr(wage.pexper):.3f}")

# ---------------------------------------------------------------
print("\n=== Experiment 3: the dummy-variable trap (US quarterly inflation) ===")
q = macro.quarter.astype(int); D = pd.get_dummies(q, prefix="Q").astype(float)
Xd = np.column_stack([np.ones(len(macro)), D.to_numpy()])
print("rank", np.linalg.matrix_rank(Xd), "of", Xd.shape[1], "; D1+D2+D3+D4 - const max abs", np.max(np.abs(D.sum(axis=1) - 1)))
fd1 = sm.OLS(macro.infl, sm.add_constant(D[["Q_2", "Q_3", "Q_4"]])).fit()
fd2 = sm.OLS(macro.infl, D).fit()
print("constant + Q2..Q4:", fd1.params.round(3).to_dict(), f"RSS {fd1.ssr:.2f}")
print("four dummies, no constant:", fd2.params.round(3).to_dict(), f"RSS {fd2.ssr:.2f}")
print("quarterly means:", macro.groupby("quarter").infl.mean().round(3).to_dict())
print("F seasonal (const + 3 dummies):", round(fd1.fvalue, 3), round(fd1.f_pvalue, 3))

# ---------------------------------------------------------------
print("\n=== Experiment 4: from perfect to imperfect (X3 = 2 X2 + v) ===")
rng = np.random.RandomState(81); n = 25
x2 = rng.uniform(0, 10, n); e = rng.randn(n); vbase = rng.randn(n)
y = 5 + 1.0 * x2 + 0.5 * (2 * x2) + 2 * e
near = []
for sv in [1.0, 0.1, 0.01, 0.001]:
    x3 = 2 * x2 + sv * vbase; f = sm.OLS(y, sm.add_constant(np.column_stack([x2, x3]))).fit()
    r = np.corrcoef(x2, x3)[0, 1]
    near.append((sv, r, *f.params[1:], *f.bse[1:], f.params[1] + 2 * f.params[2], f.rsquared))
    print(f"sd(v) {sv:6.3f}: corr {r:.7f}, b2 {f.params[1]:9.3f} ({f.bse[1]:8.3f}), b3 {f.params[2]:8.3f} ({f.bse[2]:7.3f}), "
          f"b2 + 2 b3 {f.params[1] + 2*f.params[2]:.4f}, R2 {f.rsquared:.4f}")
fs = sm.OLS(y, sm.add_constant(x2)).fit(); print(f"simple regression on X2: slope {fs.params[1]:.4f} ({fs.bse[1]:.4f}) [true combined effect 2.0]")

# ---------------------------------------------------------------
print("\n=== Experiment 5: consequences of imperfect multicollinearity (Monte Carlo) ===")
rng = np.random.RandomState(82); n = 50; reps = 10000; sig = 3.0
mc = []
for r in [0.0, 0.5, 0.8, 0.9, 0.95, 0.99]:
    a1 = rng.randn(n); a2 = rng.randn(n)
    a1 = (a1 - a1.mean()) / a1.std(); a2 = a2 - a2.mean(); a2 = a2 - (a2 @ a1) / (a1 @ a1) * a1; a2 = a2 / a2.std()
    z2 = a1; z3 = r * a1 + np.sqrt(1 - r**2) * a2           # sample corr exactly r, unit variances
    X = np.column_stack([np.ones(n), z2, z3]); XtXi = np.linalg.inv(X.T @ X)
    Y = X @ np.array([1.0, 1.0, 1.0]) + sig * rng.randn(reps, n)
    B = Y @ (XtXi @ X.T).T; RSS = ((Y - B @ X.T)**2).sum(axis=1); s2 = RSS / (n - 3)
    t2 = B[:, 1] / np.sqrt(s2 * XtXi[1, 1]); tc = stats.t.ppf(0.975, n - 3)
    TSS = ((Y - Y.mean(axis=1, keepdims=True))**2).sum(axis=1); F = ((TSS - RSS) / 2) / (RSS / (n - 3))
    sd_th = sig * np.sqrt(XtXi[1, 1]); sd_sum = np.std(B[:, 1] + B[:, 2]); sd_dif = np.std(B[:, 1] - B[:, 2])
    row = dict(r=r, vif=1 / (1 - r**2), sd=B[:, 1].std(), sd_th=sd_th, insig=np.mean(np.abs(t2) < tc), neg=np.mean(B[:, 1] < 0),
               sd_sum=sd_sum, sd_dif=sd_dif, Frej=np.mean(F > stats.f.ppf(0.95, 2, n - 3)), corrb=np.corrcoef(B[:, 1], B[:, 2])[0, 1],
               r2=np.mean(1 - RSS / TSS))
    mc.append(row)
    print(f"r {r:.2f} VIF {row['vif']:6.2f}: sd(b2) {row['sd']:.4f} (theory {sd_th:.4f}); P(|t2|<{tc:.2f}) {row['insig']:.3f}; "
          f"P(b2<0) {row['neg']:.4f}; sd(b2+b3) {sd_sum:.4f}; sd(b2-b3) {sd_dif:.4f}; corr(b2,b3) {row['corrb']:.3f}; "
          f"F rejects {row['Frej']:.3f}; mean R2 {row['r2']:.3f}")
    if r == 0.95: scat95 = B[:300, 1:3].copy()
    if r == 0.0: scat0 = B[:300, 1:3].copy()

# ---------------------------------------------------------------
print("\n=== Experiment 6: prediction inside and outside the pattern ===")
r = 0.95; rng = np.random.RandomState(83)
a1 = rng.randn(n); a2 = rng.randn(n); z2 = (a1 - a1.mean()) / a1.std(); a2 = a2 - a2.mean(); a2 = a2 - (a2 @ z2) / (z2 @ z2) * z2; a2 /= a2.std()
z3 = r * z2 + np.sqrt(1 - r**2) * a2; X = np.column_stack([np.ones(n), z2, z3]); XtXi = np.linalg.inv(X.T @ X)
for lab, x0 in [("x2 = x3 = 1 (follows the pattern)", np.array([1, 1, 1.0])), ("x2 = 1, x3 = -1 (breaks the pattern)", np.array([1, 1, -1.0]))]:
    print(f"  sd of predicted mean at {lab}: {sig*np.sqrt(x0 @ XtXi @ x0):.4f}")
X0 = np.column_stack([np.ones(n), z2, 0 * z3]); 
print(f"  same point, uncorrelated design (r = 0): {sig*np.sqrt(np.array([1,1,-1.0]) @ np.linalg.inv(np.column_stack([np.ones(n), z2, a2]).T @ np.column_stack([np.ones(n), z2, a2])) @ np.array([1,1,-1.0])):.4f}")

# ---------------------------------------------------------------
print("\n=== Experiment 7: the Longley data (US employment 1947-1962) ===")
yL = longley.TOTEMP; XL = longley.drop(columns="TOTEMP")
fL = sm.OLS(yL, sm.add_constant(XL)).fit()
print(fL.summary().tables[1]); print(f"n {int(fL.nobs)}, R2 {fL.rsquared:.4f}, F {fL.fvalue:.1f}, condition number {fL.condition_number:.3g}")
print("simple correlations with TOTEMP:", longley.corr().TOTEMP.round(3).to_dict())
for c in XL.columns:
    fs = sm.OLS(yL, sm.add_constant(XL[c])).fit(); print(f"  simple regression on {c}: slope {fs.params[c]:.5g}, t {fs.tvalues[c]:.2f}")
V = vif(XL); print("VIFs:", {k: round(v[1], 1) for k, v in V.items()}); print("aux R2:", {k: round(v[0], 5) for k, v in V.items()})
nist = np.array([-3482258.63459582, 15.0618722713733, -0.358191792925910e-1, -2.02022980381683,
                 -1.03322686717359, -0.511041056535807e-1, 1829.15146461355])
XLc = sm.add_constant(XL).to_numpy(float); yv = yL.to_numpy(float)
b_qr = fL.params.to_numpy(); b_inv = np.linalg.inv(XLc.T @ XLc) @ XLc.T @ yv
b_inv32 = (np.linalg.inv((XLc.T @ XLc).astype(np.float32)) @ (XLc.T @ yv).astype(np.float32)).astype(float)
digits = lambda b: -np.log10(np.max(np.abs((b - nist) / nist)))
print(f"agreement with NIST certified values (correct significant digits, worst coefficient): statsmodels {digits(b_qr):.1f}, "
      f"explicit inverse double {digits(b_inv):.1f}, single precision {digits(b_inv32):.1f}")
print("single-precision coefficients:", np.round(b_inv32, 4))
print(f"cond(X'X) {np.linalg.cond(XLc.T @ XLc):.3g}; det(X'X) {np.linalg.det(XLc.T @ XLc):.3g}")
# standardised regressors: determinant of correlation matrix
Rm = XL.corr().to_numpy(); print(f"det of correlation matrix of the 6 regressors {np.linalg.det(Rm):.3e}; smallest eigenvalue {np.linalg.eigvalsh(Rm).min():.2e}")
# leave-one-out instability
loo = []
for i in range(len(longley)):
    m = np.arange(len(longley)) != i; fi = sm.OLS(yL[m], sm.add_constant(XL[m])).fit(); loo.append(fi.params)
loo = pd.DataFrame(loo); full = fL.params
print("leave-one-year-out: min / max of each coefficient, and max % change")
for c in ["GNPDEFL", "GNP", "UNEMP", "ARMED", "POP", "YEAR"]:
    print(f"  {c:8s} full {full[c]:11.4f}  min {loo[c].min():11.4f}  max {loo[c].max():11.4f}  max|%chg| {100*np.max(np.abs(loo[c]/full[c]-1)):.0f}%  "
          f"sign changes {(np.sign(loo[c]) != np.sign(full[c])).sum()}")
ylab = longley.YEAR.astype(int).tolist()
loo_g = list(zip(ylab, loo.GNPDEFL.tolist())); loo_p = list(zip(ylab, loo.POP.tolist()))
# a smaller, less collinear model
fS = sm.OLS(yL, sm.add_constant(XL[["UNEMP", "ARMED", "YEAR"]])).fit()
print("reduced model UNEMP, ARMED, YEAR:", fS.params.round(4).to_dict(), "t", fS.tvalues.round(2).to_dict(), f"R2 {fS.rsquared:.4f}")
print("  VIFs:", {k: round(v[1], 2) for k, v in vif(XL[["UNEMP", "ARMED", "YEAR"]]).items()})
# joint test of the three insignificant-looking variables
fR = sm.OLS(yL, sm.add_constant(XL[["UNEMP", "ARMED", "YEAR"]])).fit()
Fj = ((fR.ssr - fL.ssr) / 3) / (fL.ssr / fL.df_resid); print(f"joint F for GNPDEFL, GNP, POP = 0: {Fj:.3f}, p {stats.f.sf(Fj, 3, fL.df_resid):.3f}")

# ---------------------------------------------------------------
print("\n=== Experiment 8: a milder real case (wage equation with age) ===")
fa = smf.ols("lwage ~ educ + exper + tenure + age", wage).fit()
print(fa.params.round(4).to_dict()); print("t", fa.tvalues.round(2).to_dict())
print("VIFs:", {k: round(v[1], 2) for k, v in vif(wage[["educ", "exper", "tenure", "age"]]).items()})
print(f"corr(exper, age) {wage.exper.corr(wage.age):.3f}; corr(educ, exper) {wage.educ.corr(wage.exper):.3f}")
f3 = smf.ols("lwage ~ educ + exper + tenure", wage).fit(); print("without age:", f3.params.round(4).to_dict(), "se", f3.bse.round(4).to_dict())
print("with age se:", fa.bse.round(4).to_dict())
Fage = fa.f_test("exper = 0, age = 0"); print("joint test exper = age = 0:", Fage)

# ---------------------------------------------------------------
print("\n=== Experiment 9: micronumerosity -- collinearity as lost sample size ===")
for R2j in [0.5, 0.8, 0.9, 0.95, 0.99]:
    print(f"R2_j {R2j}: VIF {1/(1-R2j):.0f}; with n = 1000 the precision of b_j equals that of an uncorrelated design with n = {1000*(1-R2j):.0f}")

out = {"mc": mc, "scat95": scat95.tolist(), "scat0": scat0.tolist(), "loo_g": loo_g, "loo_p": loo_p,
       "full_g": float(full["GNPDEFL"]), "full_p": float(full["POP"])}
with open("module8_coords.py", "w") as fh: fh.write("import numpy as np\nCOORDS = " + repr(out) + "\n")
print("\n[figure coordinates written to module8_coords.py]")
