"""Fill figure and table placeholders in module_8_template.tex.
Tables marked 'from module8_examples.py output' copy printed numbers from that script."""
from module8_coords import COORDS
t = open("module_8_template.tex").read(); c = COORDS
def m(x): s = f"{x:,.3f}" if abs(x) < 1000 else f"{x:,.0f}"; return ("$-$" + s[1:] if s.startswith("-") else s).replace(",", "{,}")
# from module8_examples.py output, Experiment 4
near = [(1.0, "0.9907087", 0.646, 0.943, 0.675, 0.457), (0.1, "0.9999020", -11.511, 9.160, 6.754, 4.570),
        (0.01, "0.9999990", -133.089, 91.411, 67.543, 45.696), (0.001, "0.9999999$^{*}$", -1348.863, 913.932, 675.430, 456.956)]
t = t.replace("@@neartable@@", "\n".join(f"{sv:g} & {r} & {m(b2)} ({m(s2)}) & {m(b3)} ({m(s3)}) & 1.9972 & 0.9197\\\\" for sv, r, b2, s2, b3, s3 in near)
              + "\n\\multicolumn{6}{@{}l}{\\footnotesize $^{*}$ Equal to 1 to seven decimal places.}\\\\")
t = t.replace("@@mctable@@", "\n".join(
    f"{x['r']:.2f} & {x['vif']:.2f} & {x['sd']:.3f} & {x['insig']:.3f} & {x['neg']:.3f} & {x['corrb']:.3f} & {x['sd_sum']:.3f} & {x['Frej']:.3f}\\\\".replace("-", "$-$")
    for x in c["mc"]))
t = t.replace("@@sdpts@@", " ".join(f"({x['r']},{x['sd']:.4f})" for x in c["mc"]))
t = t.replace("@@sumpts@@", " ".join(f"({x['r']},{x['sd_sum']:.4f})" for x in c["mc"]))
t = t.replace("@@insigpts@@", " ".join(f"({x['r']},{x['insig']:.4f})" for x in c["mc"]))
t = t.replace("@@negpts@@", " ".join(f"({x['r']},{x['neg']:.4f})" for x in c["mc"]))
t = t.replace("@@fpts@@", " ".join(f"({x['r']},{x['Frej']:.4f})" for x in c["mc"]))
clip = lambda v: max(-4.9, min(6.9, v))
t = t.replace("@@scat0@@", " ".join(f"({clip(a):.3f},{clip(b):.3f})" for a, b in c["scat0"]))
t = t.replace("@@scat95@@", " ".join(f"({clip(a):.3f},{clip(b):.3f})" for a, b in c["scat95"]))
# from module8_examples.py output, Experiment 7
lt = [("GNP deflator", "15.062", "0.18", "135.5", "0.971", "15.17"), ("GNP", "$-$0.0358", "$-$1.07", "1{,}788.5", "0.984", "20.37"),
      ("Unemployment", "$-$2.020", "$-$4.14", "33.6", "0.502", "2.17"), ("Armed forces", "$-$1.033", "$-$4.82", "3.6", "0.457", "1.92"),
      ("Population", "$-$0.0511", "$-$0.23", "399.2", "0.960", "12.90"), ("Year", "1{,}829.2", "4.02", "759.0", "0.971", "15.29")]
t = t.replace("@@longtable@@", "\n".join(" & ".join(r) + "\\\\" for r in lt))
t = t.replace("@@loog@@", " ".join(f"({y},{v:.3f})" for y, v in c["loo_g"])).replace("@@fullg@@", f"{c['full_g']:.3f}")
t = t.replace("@@loop@@", " ".join(f"({y},{v:.4f})" for y, v in c["loo_p"])).replace("@@fullp@@", f"{c['full_p']:.4f}")
assert "@@" not in t
open("module_8_multicollinearity.tex", "w").write(t); print("written")
