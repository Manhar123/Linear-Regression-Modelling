# Module 8 -- Multicollinearity
# R companion to module8_examples.py. Needs wage2.csv, macro.csv, longley.csv and the package car.
# Deterministic results match the notes; simulations give the same pattern, different decimals.
library(car)
wage <- read.csv("wage2.csv"); macro <- read.csv("macro.csv"); longley <- read.csv("longley.csv")

cat("=== Experiment 1: textbook perfect multicollinearity ===\n")
X <- cbind(1, 1:6, 2 * (1:6)); print(qr(X)$rank); print(t(X) %*% X); print(det(t(X) %*% X))

cat("\n=== Experiment 2: potential experience ===\n")
wage$pexper <- wage$age - wage$educ - 6
fp <- lm(lwage ~ educ + age + pexper, data = wage); print(coef(fp))      # pexper NA
print(alias(fp)); f2 <- lm(lwage ~ educ + age, data = wage); print(coef(f2)); print(deviance(f2))

cat("\n=== Experiment 3: dummy-variable trap ===\n")
D <- model.matrix(~ factor(quarter) - 1, data = macro); print(qr(cbind(1, D))$rank)
print(coef(lm(infl ~ factor(quarter), data = macro))); print(coef(lm(infl ~ factor(quarter) - 1, data = macro)))
print(anova(lm(infl ~ 1, data = macro), lm(infl ~ factor(quarter), data = macro)))

cat("\n=== Experiment 4: from perfect to imperfect ===\n")
set.seed(81); n <- 25; x2 <- runif(n, 0, 10); e <- rnorm(n); v <- rnorm(n); y <- 5 + x2 + 0.5 * (2 * x2) + 2 * e
for (sv in c(1, 0.1, 0.01, 0.001)) { x3 <- 2 * x2 + sv * v; f <- lm(y ~ x2 + x3); b <- coef(f)
  cat(sprintf("sd(v) %.3f corr %.7f b2 %.3f b3 %.3f b2+2b3 %.4f R2 %.4f\n", sv, cor(x2, x3), b[2], b[3], b[2] + 2 * b[3], summary(f)$r.squared)) }

cat("\n=== Experiment 5: consequences (Monte Carlo) ===\n")
set.seed(82); n <- 50; sig <- 3
for (r in c(0, 0.5, 0.8, 0.9, 0.95, 0.99)) {
  a1 <- as.vector(scale(rnorm(n))); a2 <- resid(lm(rnorm(n) ~ a1)); a2 <- a2 / sqrt(mean(a2^2)); a1 <- a1 / sqrt(mean(a1^2))
  z2 <- a1; z3 <- r * a1 + sqrt(1 - r^2) * a2
  res <- t(replicate(10000, { y <- 1 + z2 + z3 + sig * rnorm(n); s <- summary(lm(y ~ z2 + z3))
    c(s$coefficients[2, 1], s$coefficients[3, 1], abs(s$coefficients[2, 3]) < qt(0.975, n - 3), s$fstatistic[1] > qf(0.95, 2, n - 3)) }))
  cat(sprintf("r %.2f: sd(b2) %.4f theory %.4f P(insig) %.3f P(b2<0) %.4f sd(b2+b3) %.4f F rejects %.3f\n", r, sd(res[, 1]),
              sig / sqrt(n * (1 - r^2)), mean(res[, 3]), mean(res[, 1] < 0), sd(res[, 1] + res[, 2]), mean(res[, 4])))
}

cat("\n=== Experiment 7: Longley ===\n")
fL <- lm(TOTEMP ~ GNPDEFL + GNP + UNEMP + ARMED + POP + YEAR, data = longley); print(summary(fL)); print(vif(fL))
print(cor(longley)); print(kappa(model.matrix(fL), exact = TRUE)^2)    # condition number of X'X
for (v in c("GNPDEFL", "GNP", "UNEMP", "ARMED", "POP", "YEAR")) print(summary(lm(longley$TOTEMP ~ longley[[v]]))$coefficients[2, ])
nist <- c(-3482258.63459582, 15.0618722713733, -0.358191792925910e-1, -2.02022980381683, -1.03322686717359, -0.511041056535807e-1, 1829.15146461355)
cat("correct digits, lm():", -log10(max(abs((coef(fL) - nist) / nist))), "\n")
loo <- t(sapply(1:16, function(i) coef(update(fL, data = longley[-i, ])))); print(apply(loo, 2, range))
print(anova(lm(TOTEMP ~ UNEMP + ARMED + YEAR, data = longley), fL))

cat("\n=== Experiment 8: wage equation with age ===\n")
fa <- lm(lwage ~ educ + exper + tenure + age, data = wage); print(summary(fa)); print(vif(fa))
print(linearHypothesis(fa, c("exper = 0", "age = 0")))
