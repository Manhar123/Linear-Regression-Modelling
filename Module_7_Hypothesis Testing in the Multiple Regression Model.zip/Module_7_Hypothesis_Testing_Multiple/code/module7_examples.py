"""Module 7 -- Hypothesis Testing in the Multiple Regression Model.
Every number printed in the Module 7 notes is produced by this script.
Needs wage2.csv, bwght.csv (Wooldridge data, exported from the Python package `wooldridge`),
metal.csv (Hildebrand-Liu SIC 33 production data, Greene Table F6.1) and macro.csv (Module 2).
Run from top to bottom:  python module7_examples.py
"""
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
import statsmodels.formula.api as smf

wage = pd.read_csv("wage2.csv"); metal = pd.read_csv("metal.csv"); bw = pd.read_csv("bwght.csv")
macro = pd.read_csv("macro.csv")

def tests(fu, fr, q):
    """F, Wald, LR and LM statistics from unrestricted and restricted fits (same n)."""
    n = fu.nobs; ku = fu.df_model + 1
    F = ((fr.ssr - fu.ssr) / q) / (fu.ssr / (n - ku))
    W = n * (fr.ssr - fu.ssr) / fu.ssr; LR = n * np.log(fr.ssr / fu.ssr); LM = n * (fr.ssr - fu.ssr) / fr.ssr
    return dict(F=F, pF=stats.f.sf(F, q, n - ku), W=W, LR=LR, LM=LM, pLR=stats.chi2.sf(LR, q),
                Fcrit=stats.f.ppf(0.95, q, n - ku), chi2crit=stats.chi2.ppf(0.95, q))

# ---------------------------------------------------------------
print("=== Experiment 1: the wage equation, individual t tests ===")
fu = smf.ols("lwage ~ educ + exper + tenure", wage).fit(); n = int(fu.nobs); k = 4
print(fu.summary().tables[1]); print(f"n {n}, R2 {fu.rsquared:.4f}, adjR2 {fu.rsquared_adj:.4f}, s {np.sqrt(fu.scale):.4f}, "
      f"RSS {fu.ssr:.3f}, logL {fu.llf:.3f}, F {fu.fvalue:.2f} (p {fu.f_pvalue:.2e})")
tc = stats.t.ppf(0.975, n - k); print(f"t critical 5% two-sided, df {n-k}: {tc:.3f}; one-sided {stats.t.ppf(0.95, n-k):.3f}")
b, se = fu.params["educ"], fu.bse["educ"]; t10 = (b - 0.10) / se
print(f"H0 educ = 0.10: t {t10:.2f}, p {2*stats.t.sf(abs(t10), n-k):.2e}; 95% CI educ {fu.conf_int().loc['educ'].round(4).tolist()}")
print("A&H Table 5.1 (900 obs): educ 0.0731 (0.0066), exper 0.0154 (0.0034), tenure 0.0130 (0.0026), R2 0.1486")

# ---------------------------------------------------------------
print("\n=== Experiment 2: Cobb-Douglas, constant returns to scale (SIC 33, n = 27) ===")
metal["lq"], metal["ll"], metal["lk"] = np.log(metal.va), np.log(metal.labor), np.log(metal.capital)
cu = smf.ols("lq ~ ll + lk", metal).fit(); nm = int(cu.nobs)
print(f"unrestricted: c {cu.params.iloc[0]:.4f} ({cu.bse.iloc[0]:.4f}), alpha {cu.params.iloc[1]:.4f} ({cu.bse.iloc[1]:.4f}), beta {cu.params.iloc[2]:.4f} ({cu.bse.iloc[2]:.4f})")
print(f"  R2 {cu.rsquared:.4f}, RSS {cu.ssr:.5f}, logL {cu.llf:.4f}, F {cu.fvalue:.1f}")
V = cu.cov_params(); va, vb, cab = V.loc["ll", "ll"], V.loc["lk", "lk"], V.loc["ll", "lk"]
s = cu.params.iloc[1] + cu.params.iloc[2]; ses = np.sqrt(va + vb + 2 * cab); tcrs = (s - 1) / ses
print(f"alpha+beta {s:.4f}; Var(a) {va:.6f}, Var(b) {vb:.6f}, Cov {cab:.6f}, corr {cab/np.sqrt(va*vb):.3f}; se(sum) {ses:.4f}")
print(f"  t (H0: alpha+beta=1) {tcrs:.3f}, p {2*stats.t.sf(abs(tcrs), nm-3):.3f}, t^2 {tcrs**2:.4f}; se ignoring cov {np.sqrt(va+vb):.4f}")
metal["lqs"], metal["lks"] = metal.lq - metal.ll, metal.lk - metal.ll
cr = smf.ols("lqs ~ lks", metal).fit()
print(f"restricted: ln(Q/L) on ln(K/L): c {cr.params.iloc[0]:.4f}, beta {cr.params.iloc[1]:.4f} ({cr.bse.iloc[1]:.4f}), alpha = 1 - beta = {1-cr.params.iloc[1]:.4f}; "
      f"RSS {cr.ssr:.5f}, R2 {cr.rsquared:.4f}")
T2 = tests(cu, cr, 1); print({k_: round(v, 4) for k_, v in T2.items()})
print(f"(wrong) R2 form with R2_R from the transformed regression: {((cu.rsquared - cr.rsquared)/1)/((1-cu.rsquared)/(nm-3)):.2f}")
print("statsmodels f_test:", cu.f_test("ll + lk = 1"))
# confidence ellipse and individual intervals
Fc2 = stats.f.ppf(0.95, 2, nm - 3); Vab = V.loc[["ll", "lk"], ["ll", "lk"]].to_numpy()
L = np.linalg.cholesky(Vab); th = np.linspace(0, 2 * np.pi, 121)
ell = (cu.params[["ll", "lk"]].to_numpy()[:, None] + np.sqrt(2 * Fc2) * L @ np.vstack([np.cos(th), np.sin(th)])).T
ci = cu.conf_int().loc[["ll", "lk"]].to_numpy()
print(f"individual 95% CIs: alpha {ci[0].round(3)}, beta {ci[1].round(3)}; 2*F crit(2,{nm-3}) = {2*Fc2:.3f}")
# a point inside the rectangle but outside the ellipse
pt = np.array([0.40, 0.25]); d = pt - cu.params[["ll", "lk"]].to_numpy()
Wpt = d @ np.linalg.solve(Vab, d) / 2; print(f"joint F for (alpha,beta) = (0.40, 0.25): {Wpt:.2f} vs crit {Fc2:.3f}")
pt2 = np.array([0.80, 0.50]); d2 = pt2 - cu.params[["ll", "lk"]].to_numpy()
print(f"joint F for (alpha,beta) = (0.80, 0.50): {d2 @ np.linalg.solve(Vab, d2) / 2:.2f}")

# ---------------------------------------------------------------
print("\n=== Experiment 3: Wald, redundant and omitted variable tests (wage) ===")
print("Wald exper = tenure:", fu.f_test("exper = tenure"))
d = fu.params["exper"] - fu.params["tenure"]; Vw = fu.cov_params()
sed = np.sqrt(Vw.loc["exper", "exper"] + Vw.loc["tenure", "tenure"] - 2 * Vw.loc["exper", "tenure"])
print(f"  t form: diff {d:.5f}, se {sed:.5f}, t {d/sed:.3f}, t^2 {(d/sed)**2:.4f}")
wage["et"] = wage.exper + wage.tenure; frw = smf.ols("lwage ~ educ + et", wage).fit()
print("  restricted (exper+tenure combined):", {k_: round(v, 4) for k_, v in tests(fu, frw, 1).items()}, f"common coef {frw.params['et']:.5f}")
fr_t = smf.ols("lwage ~ educ + exper", wage).fit()
print(f"redundant tenure: restricted coefs {fr_t.params.round(5).to_dict()}, R2 {fr_t.rsquared:.4f}, RSS {fr_t.ssr:.3f}")
T3 = tests(fu, fr_t, 1); print("  ", {k_: round(v, 4) for k_, v in T3.items()}, f" t^2 {fu.tvalues['tenure']**2:.4f}")
print(f"  LR from log-likelihoods: 2(lU - lR) = 2({fu.llf:.3f} - ({fr_t.llf:.3f})) = {2*(fu.llf-fr_t.llf):.4f}")
fr_e = smf.ols("lwage ~ exper + tenure", wage).fit()
print(f"omitted educ: model without educ coefs {fr_e.params.round(5).to_dict()} (se exper {fr_e.bse['exper']:.4f}), R2 {fr_e.rsquared:.4f}")
T4 = tests(fu, fr_e, 1); print("  ", {k_: round(v, 4) for k_, v in T4.items()})
print(f"  corr(educ, exper) {wage.educ.corr(wage.exper):.3f}")
# LM by auxiliary regression for educ omitted
aux = sm.OLS(fr_e.resid, sm.add_constant(wage[["educ", "exper", "tenure"]])).fit()
print(f"  LM = n R2_aux = {n} x {aux.rsquared:.5f} = {n*aux.rsquared:.3f}")
# joint: add married, black, south, urban
fbig = smf.ols("lwage ~ educ + exper + tenure + married + black + south + urban", wage).fit()
T5 = tests(fbig, fu, 4)
print(f"omitted set (married, black, south, urban): R2 {fbig.rsquared:.4f}, t {fbig.tvalues[4:].round(2).to_dict()}")
print("  ", {k_: round(v, 4) for k_, v in T5.items()})
aux2 = sm.OLS(fu.resid, sm.add_constant(wage[["educ", "exper", "tenure", "married", "black", "south", "urban"]])).fit()
print(f"  LM via auxiliary regression n R2 = {n*aux2.rsquared:.3f}")
# overall significance
TSS = np.sum((wage.lwage - wage.lwage.mean())**2)
print(f"overall F: R2 form {(fu.rsquared/3)/((1-fu.rsquared)/(n-4)):.3f}; RSS form {((TSS-fu.ssr)/3)/(fu.ssr/(n-4)):.3f}; crit {stats.f.ppf(0.95,3,n-4):.3f}")

# ---------------------------------------------------------------
print("\n=== Experiment 4: Okun's law with lags, joint tests (US quarterly) ===")
du = np.diff(macro.unemp.to_numpy()); g = 100 * np.diff(np.log(macro.realgdp.to_numpy()))
P = 3; yo = du[P:]; G = np.column_stack([g[P - j: len(g) - j] for j in range(P + 1)])
d4 = pd.DataFrame(G, columns=["g0", "g1", "g2", "g3"]); d4["du"] = yo
fo = smf.ols("du ~ g0 + g1 + g2 + g3", d4).fit(); fo0 = smf.ols("du ~ g0", d4).fit()
print(f"n {int(fo.nobs)}; coefs {fo.params.round(4).to_dict()}; t {fo.tvalues.round(2).to_dict()}")
T6 = tests(fo, fo0, 3); print("H0: b1=b2=b3=0:", {k_: round(v, 4) for k_, v in T6.items()})
print(fo.f_test("g1 = 0, g2 = 0, g3 = 0"))
Vo = fo.cov_params(); Rr = np.array([0, 1, 1, 1, 1.0]); lr_ = Rr @ fo.params.to_numpy(); se_lr = np.sqrt(Rr @ Vo.to_numpy() @ Rr)
for h0 in [-0.3, -0.5]:
    tt = (lr_ - h0) / se_lr; print(f"long-run sum {lr_:.4f}, se {se_lr:.4f}; H0 sum = {h0}: t {tt:.2f}, p {2*stats.t.sf(abs(tt), fo.df_resid):.4f}")
print(fo.t_test("g0 + g1 + g2 + g3 = -0.5"))

# ---------------------------------------------------------------
print("\n=== Experiment 5: joint versus individual tests (Monte Carlo) ===")
rng = np.random.RandomState(71); reps = 10000; nn = 50
z = rng.randn(nn); x2 = z + 0.0 * z; x3 = 0.95 * z + np.sqrt(1 - 0.95**2) * rng.randn(nn)
X = np.column_stack([np.ones(nn), x2, x3]); XtXi = np.linalg.inv(X.T @ X)
print(f"corr(x2,x3) {np.corrcoef(x2, x3)[0,1]:.3f}")
Ys = X @ np.array([1, 0.25, 0.25]) + rng.randn(reps, nn) * 1.0
B = Ys @ (XtXi @ X.T).T; RSS = ((Ys - B @ X.T)**2).sum(axis=1); s2 = RSS / (nn - 3)
tt2 = B[:, 1] / np.sqrt(s2 * XtXi[1, 1]); tt3 = B[:, 2] / np.sqrt(s2 * XtXi[2, 2])
TSS = ((Ys - Ys.mean(axis=1, keepdims=True))**2).sum(axis=1); Fo = ((TSS - RSS) / 2) / (RSS / (nn - 3))
tcr = stats.t.ppf(0.975, nn - 3); fcr = stats.f.ppf(0.95, 2, nn - 3)
both_ns = (np.abs(tt2) < tcr) & (np.abs(tt3) < tcr)
print(f"t crit {tcr:.3f}, F crit {fcr:.3f}")
print(f"share: F rejects {np.mean(Fo > fcr):.4f}; x2 t significant {np.mean(np.abs(tt2) > tcr):.4f}; x3 {np.mean(np.abs(tt3) > tcr):.4f}; "
      f"neither t significant {np.mean(both_ns):.4f}; neither t but F rejects {np.mean(both_ns & (Fo > fcr)):.4f}")
print(f"corr of b2, b3 estimates {np.corrcoef(B[:,1], B[:,2])[0,1]:.3f}")
# the converse: 10 irrelevant regressors, looking at individual t
rng = np.random.RandomState(72); nn = 60; m = 10
Xm = np.column_stack([np.ones(nn), rng.randn(nn, m)]); XtXim = np.linalg.inv(Xm.T @ Xm)
Ym = 1 + rng.randn(reps, nn); Bm = Ym @ (XtXim @ Xm.T).T; RSSm = ((Ym - Bm @ Xm.T)**2).sum(axis=1)
s2m = RSSm / (nn - m - 1); Tm = Bm[:, 1:] / np.sqrt(s2m[:, None] * np.diag(XtXim)[1:])
TSSm = ((Ym - Ym.mean(axis=1, keepdims=True))**2).sum(axis=1); Fm = ((TSSm - RSSm) / m) / (RSSm / (nn - m - 1))
tcm = stats.t.ppf(0.975, nn - m - 1)
print(f"10 irrelevant regressors, n 60: at least one |t| > {tcm:.3f} in {np.mean((np.abs(Tm) > tcm).any(axis=1)):.4f} of samples; "
      f"F rejects in {np.mean(Fm > stats.f.ppf(0.95, m, nn-m-1)):.4f}; 1 - 0.95^10 = {1-0.95**10:.4f}")

# ---------------------------------------------------------------
print("\n=== Experiment 6: F versus chi-square forms of W, LR, LM (size, q = 3) ===")
rng = np.random.RandomState(73); q = 3; size = {}
for nn in [20, 40, 100, 500]:
    Xs = np.column_stack([np.ones(nn), rng.randn(nn, 5)]); Xr = Xs[:, :3]
    Mu = np.eye(nn) - Xs @ np.linalg.pinv(Xs); Mr = np.eye(nn) - Xr @ np.linalg.pinv(Xr)
    U = rng.randn(reps, nn); Y = 1 + 0.5 * Xs[:, 1] - 0.5 * Xs[:, 2] + U
    ru = ((Y @ Mu) * Y).sum(axis=1); rr = ((Y @ Mr) * Y).sum(axis=1)
    F = ((rr - ru) / q) / (ru / (nn - 6)); W = nn * (rr - ru) / ru; LR = nn * np.log(rr / ru); LM = nn * (rr - ru) / rr
    c2 = stats.chi2.ppf(0.95, q); fc = stats.f.ppf(0.95, q, nn - 6)
    size[nn] = dict(F=np.mean(F > fc), W=np.mean(W > c2), LR=np.mean(LR > c2), LM=np.mean(LM > c2))
    print(f"n {nn:4d}: rejection rate of a true H0 at 5%: F {size[nn]['F']:.4f}  Wald {size[nn]['W']:.4f}  LR {size[nn]['LR']:.4f}  LM {size[nn]['LM']:.4f}"
          f"   W>=LR>=LM in every sample: {bool(np.all(W >= LR - 1e-12) and np.all(LR >= LM - 1e-12))}")

# ---------------------------------------------------------------
print("\n=== Experiment 7: birth weight (Asteriou-Hall Exercise 5.1 data) ===")
fb = smf.ols("bwght ~ cigs + faminc", bw).fit()
print(f"n {int(fb.nobs)}: {fb.params.round(4).to_dict()} se {fb.bse.round(4).to_dict()}; R2 {fb.rsquared:.4f}, F {fb.fvalue:.2f} (p {fb.f_pvalue:.2e})")
print(f"  cigs only {smf.ols('bwght ~ cigs', bw).fit().params['cigs']:.4f}; faminc only {smf.ols('bwght ~ faminc', bw).fit().params['faminc']:.4f}; corr {bw.cigs.corr(bw.faminc):.3f}")

out = {"ellipse": ell.tolist(), "ci": ci.tolist(), "ab": cu.params[["ll", "lk"]].tolist(), "size": size,
       "Ften": T3["F"], "Fcrit_ten": T3["Fcrit"], "dfden": n - k}
with open("module7_coords.py", "w") as fh: fh.write("import numpy as np\nCOORDS = " + repr(out) + "\n")
print("\n[figure coordinates written to module7_coords.py]")
