# Module 7 -- Hypothesis Testing in the Multiple Regression Model
# R companion to module7_examples.py. Needs wage2.csv, bwght.csv, metal.csv, macro.csv
# and the packages car and lmtest. (wage2 and bwght are also in the R package 'wooldridge'.)
# Deterministic results match the notes; simulations give the same pattern, different decimals.
library(car); library(lmtest)
wage <- read.csv("wage2.csv"); metal <- read.csv("metal.csv"); bw <- read.csv("bwght.csv"); macro <- read.csv("macro.csv")
tests <- function(fu, fr, q) { n <- nobs(fu); ru <- deviance(fu); rr <- deviance(fr)
  c(F = ((rr - ru) / q) / (ru / df.residual(fu)), W = n * (rr - ru) / ru, LR = n * log(rr / ru), LM = n * (rr - ru) / rr) }

cat("=== Experiment 1: wage equation ===\n")
fu <- lm(lwage ~ educ + exper + tenure, data = wage); print(summary(fu)); print(confint(fu))
cat("H0 educ = 0.10: t =", (coef(fu)["educ"] - 0.10) / sqrt(vcov(fu)["educ", "educ"]), "\n")

cat("\n=== Experiment 2: Cobb-Douglas, constant returns ===\n")
cu <- lm(log(va) ~ log(labor) + log(capital), data = metal); print(summary(cu))
cr <- lm(log(va / labor) ~ log(capital / labor), data = metal)
print(c(RSS_U = deviance(cu), RSS_R = deviance(cr), alpha_R = 1 - unname(coef(cr)[2])))
print(tests(cu, cr, 1)); print(linearHypothesis(cu, "log(labor) + log(capital) = 1"))
V <- vcov(cu); s <- sum(coef(cu)[2:3]); se_s <- sqrt(V[2, 2] + V[3, 3] + 2 * V[2, 3])
print(c(sum = s, se = se_s, t = (s - 1) / se_s, se_no_cov = sqrt(V[2, 2] + V[3, 3]), corr = V[2, 3] / sqrt(V[2, 2] * V[3, 3])))
R2r <- summary(cr)$r.squared; R2u <- summary(cu)$r.squared
cat("(wrong) R2 form:", (R2u - R2r) / ((1 - R2u) / 24), "\n")
for (p in list(c(0.40, 0.25), c(0.80, 0.50))) {
  d <- coef(cu)[2:3] - p; cat("joint F at", p, ":", drop(t(d) %*% solve(V[2:3, 2:3]) %*% d) / 2, "\n") }

cat("\n=== Experiment 3: Wald, redundant and omitted variable tests ===\n")
print(linearHypothesis(fu, "exper = tenure"))
fr_t <- lm(lwage ~ educ + exper, data = wage); print(anova(fr_t, fu)); print(lrtest(fr_t, fu)); print(tests(fu, fr_t, 1))
fr_e <- lm(lwage ~ exper + tenure, data = wage); print(coef(fr_e)); print(tests(fu, fr_e, 1))
aux <- lm(resid(fr_e) ~ educ + exper + tenure, data = wage); cat("LM = nR2:", nobs(fu) * summary(aux)$r.squared, "\n")
fbig <- update(fu, . ~ . + married + black + south + urban); print(anova(fu, fbig)); print(tests(fbig, fu, 4))
s <- summary(fu); print(s$fstatistic)

cat("\n=== Experiment 4: Okun's law with lags ===\n")
du <- diff(macro$unemp); g <- 100 * diff(log(macro$realgdp)); n0 <- length(g)
d <- data.frame(du = du[4:n0], g0 = g[4:n0], g1 = g[3:(n0 - 1)], g2 = g[2:(n0 - 2)], g3 = g[1:(n0 - 3)])
fo <- lm(du ~ g0 + g1 + g2 + g3, data = d); print(summary(fo))
print(linearHypothesis(fo, c("g1 = 0", "g2 = 0", "g3 = 0")))
print(linearHypothesis(fo, "g0 + g1 + g2 + g3 = -0.3")); print(linearHypothesis(fo, "g0 + g1 + g2 + g3 = -0.5"))

cat("\n=== Experiment 5: joint versus individual tests ===\n")
set.seed(71); n <- 50; z <- rnorm(n); x2 <- z; x3 <- 0.95 * z + sqrt(1 - 0.95^2) * rnorm(n)
res <- t(replicate(10000, { y <- 1 + 0.25 * x2 + 0.25 * x3 + rnorm(n); s <- summary(lm(y ~ x2 + x3))
  c(abs(s$coefficients[2:3, 3]) > qt(0.975, n - 3), s$fstatistic[1] > qf(0.95, 2, n - 3)) }))
cat("F rejects", mean(res[, 3]), " neither t significant but F rejects", mean(!res[, 1] & !res[, 2] & res[, 3]), "\n")
set.seed(72); n <- 60; X <- matrix(rnorm(n * 10), n)
res2 <- t(replicate(10000, { s <- summary(lm(rnorm(n) ~ X))
  c(any(abs(s$coefficients[-1, 3]) > qt(0.975, n - 11)), s$fstatistic[1] > qf(0.95, 10, n - 11)) }))
cat("any |t| significant", mean(res2[, 1]), " F rejects", mean(res2[, 2]), "\n")

cat("\n=== Experiment 6: size of F, Wald, LR, LM (q = 3) ===\n")
set.seed(73)
for (n in c(20, 40, 100, 500)) {
  X <- matrix(rnorm(n * 5), n)
  r <- t(replicate(10000, { y <- 1 + 0.5 * X[, 1] - 0.5 * X[, 2] + rnorm(n)
    tests(lm(y ~ X), lm(y ~ X[, 1:2]), 3) }))
  cat(sprintf("n %4d: F %.4f  Wald %.4f  LR %.4f  LM %.4f\n", n, mean(r[, "F"] > qf(0.95, 3, n - 6)),
              mean(r[, "W"] > qchisq(0.95, 3)), mean(r[, "LR"] > qchisq(0.95, 3)), mean(r[, "LM"] > qchisq(0.95, 3))))
}

cat("\n=== Experiment 7: birth weight ===\n")
fb <- lm(bwght ~ cigs + faminc, data = bw); print(summary(fb))
print(c(coef(lm(bwght ~ cigs, data = bw))[2], coef(lm(bwght ~ faminc, data = bw))[2], cor(bw$cigs, bw$faminc)))
