"""Fill figure placeholders in module_7_template.tex."""
import numpy as np
from scipy import stats
from module7_coords import COORDS
t = open("module_7_template.tex").read(); c = COORDS
xs = np.linspace(0.02, 5, 120); fd = []
for (d1, d2), sty in [((1, 24), "rust,dashed"), ((3, 50), "slate"), ((10, 50), "sepia,dotted,line width=1.3pt")]:
    fd.append(f"\\addplot[{sty}] coordinates {{" + " ".join(f"({x:.3f},{min(stats.f.pdf(x, d1, d2), 1.2):.4f})" for x in xs) + "};")
    fd.append(f"\\addlegendentry{{$F_{{{d1},{d2}}}$, 5\\% critical value {stats.f.ppf(0.95, d1, d2):.2f}}}")
    cv = stats.f.ppf(0.95, d1, d2)
    fd.append(f"\\addplot[{sty},forget plot] coordinates {{({cv:.3f},0) ({cv:.3f},{stats.f.pdf(cv, d1, d2) + 0.15:.3f})}};")
t = t.replace("@@fdens@@", "\n".join(fd))
t = t.replace("@@ellipse@@", " ".join(f"({a:.4f},{b:.4f})" for a, b in c["ellipse"]))
(a0, a1), (b0, b1) = c["ci"]
t = t.replace("@@rect@@", f"({a0:.4f},{b0:.4f}) ({a1:.4f},{b0:.4f}) ({a1:.4f},{b1:.4f}) ({a0:.4f},{b1:.4f}) ({a0:.4f},{b0:.4f})")
t = t.replace("@@ab@@", f"{c['ab'][0]:.4f},{c['ab'][1]:.4f}")
fills = {"F": "black!55", "W": "rust!70", "LR": "sepia!70", "LM": "slate!60"}
names = {"F": "$F$ (exact)", "W": "Wald, $\\chi^2$", "LR": "LR, $\\chi^2$", "LM": "LM, $\\chi^2$"}
sp = []
for m in ["F", "W", "LR", "LM"]:
    sp.append(f"\\addplot[fill={fills[m]},draw=black!60] coordinates {{" + " ".join(f"({n},{c['size'][n][m]:.4f})" for n in [20, 40, 100, 500]) + "};")
    sp.append(f"\\addlegendentry{{{names[m]}}}")
t = t.replace("@@sizeplots@@", "\n".join(sp))
assert "@@" not in t
open("module_7_hypothesis_testing_multiple.tex", "w").write(t); print("written")
