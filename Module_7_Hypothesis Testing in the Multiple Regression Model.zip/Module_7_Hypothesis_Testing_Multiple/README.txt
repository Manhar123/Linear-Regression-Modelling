HYPOTHESIS TESTING IN THE MULTIPLE REGRESSION MODEL: LINEAR RESTRICTIONS, THE F TEST, AND THE WALD,
LIKELIHOOD RATIO AND LAGRANGE MULTIPLIER PRINCIPLES
Module 7 of the course on Linear Regression Models. Manhar Singh, November 2026. Notes: 37 pages.

FOLDERS
  notes/                 PDF of the notes, LaTeX source, and lrm-notes.sty (keep the .sty next to the .tex to compile).
  overleaf_single_file/  The same notes as one self-contained .tex file (style inlined): paste into Overleaf and compile.
  data/                  wage2.csv  wages of 935 US men (Wooldridge WAGE2; close to Asteriou and Hall's Table 5.1 example)
                         bwght.csv  birth weight and smoking (Wooldridge BWGHT; Asteriou and Hall's Exercise 5.1 data)
                         metal.csv  US primary metals industry, 27 observations (Hildebrand and Liu), for the Cobb-Douglas example
                         macro.csv  US quarterly macroeconomic data (from Module 2)
  code/                  module7_examples.py reproduces every number in the notes (needs numpy, pandas, scipy, statsmodels).
                         module7_examples.R (needs car and lmtest) and module7_examples.inp (GRETL) follow the same steps.
                         Copy the four CSV files from data/ into code/ before running any script.
                         module_7_template.tex, module7_coords.py and build_module7.py regenerate the notes' .tex
                         (the figures' plotted points) if you change the data.

COMPILING: pdflatex, run twice (for the table of contents).
This module has no practice workbook and no instructor material.
Reading note: Preliminary Module C (inference and large-sample theory) is meant to be read before this module.
NOTE: the R and GRETL scripts were not run for this edition; please run them once before class.
