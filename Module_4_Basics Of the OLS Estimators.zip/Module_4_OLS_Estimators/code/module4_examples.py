"""Module 4 -- Basics of the OLS Estimators.
Every number printed in the Module 4 notes is produced by this script.
Needs engel.csv and macro.csv (written by module2_examples.py) and Foundations_Practice_Data.xlsx.
Run from top to bottom:  python module4_examples.py
"""
import numpy as np
import pandas as pd
import statsmodels.api as sm

engel = pd.read_csv("engel.csv"); macro = pd.read_csv("macro.csv")
X = engel["income"].to_numpy(); Y = engel["foodexp"].to_numpy(); n = len(X)

def ols(y, *xs):
    return sm.OLS(y, sm.add_constant(np.column_stack(xs))).fit()

# ---------------------------------------------------------------
print("=== Experiment 1: OLS is a weighted sum of the Y values ===")
x = X - X.mean(); z = x / np.sum(x**2)
print(f"sum z {z.sum():.2e}; sum z*X {np.sum(z*X):.6f}; sum z^2 {np.sum(z**2):.4e} = 1/sum x^2 {1/np.sum(x**2):.4e}")
print(f"sum z*Y {np.sum(z*Y):.6f}; OLS slope {ols(Y, X).params[1]:.6f}")
i_min, i_max = np.argmin(X), np.argmax(X)
print(f"largest weight (richest household) {z[i_max]:.3e}; weight of median-income household {z[np.argsort(X)[n//2]]:.3e}; "
      f"poorest {z[i_min]:.3e}")
print(f"share of total |weight| on the 10 richest households: {np.sort(np.abs(z))[-10:].sum()/np.abs(z).sum():.3f}")

# ---------------------------------------------------------------
# A common Monte Carlo design for Experiments 2-5
rng = np.random.RandomState(41)
alpha, beta, sigma, ns, reps = 2.0, 0.5, 2.0, 30, 10000
xs = np.linspace(1, 20, ns); xd = xs - xs.mean(); Sxx = np.sum(xd**2)
zt = xd / Sxx
m = ns // 2
U = rng.randn(reps, ns) * sigma                    # normal disturbances
Ys = alpha + beta * xs + U
b_ols = Ys @ zt; a_ols = Ys.mean(axis=1) - b_ols * xs.mean()
print("\n=== Experiment 2: unbiasedness (10,000 samples, n = 30) ===")
print(f"mean beta_hat {b_ols.mean():.4f} (true 0.5); mean alpha_hat {a_ols.mean():.4f} (true 2.0)")
print(f"sd beta_hat {b_ols.std():.5f}; theoretical sqrt(sigma^2/Sxx) {np.sqrt(sigma**2/Sxx):.5f}")
va_theory = sigma**2 * np.sum(xs**2) / (ns * Sxx)
print(f"sd alpha_hat {a_ols.std():.4f}; theoretical {np.sqrt(va_theory):.4f}; "
      f"cov(alpha,beta) {np.cov(a_ols, b_ols)[0,1]:.5f} theory {-xs.mean()*sigma**2/Sxx:.5f}")
print(f"share of samples with beta_hat within 0.05 of truth: {np.mean(abs(b_ols-beta) < 0.05):.3f}")

# ---------------------------------------------------------------
print("\n=== Experiment 3: OLS against other linear unbiased estimators ===")
b_fl = (Ys[:, -1] - Ys[:, 0]) / (xs[-1] - xs[0])
b_half = (Ys[:, m:].mean(axis=1) - Ys[:, :m].mean(axis=1)) / (xs[m:].mean() - xs[:m].mean())
v_fl = 2 * sigma**2 / (xs[-1] - xs[0])**2
v_half = 2 * sigma**2 / (m * (xs[m:].mean() - xs[:m].mean())**2)
for name, b, vt in [("OLS", b_ols, sigma**2/Sxx), ("first and last", b_fl, v_fl), ("group means (halves)", b_half, v_half)]:
    print(f"{name:22s}: mean {b.mean():.4f}; variance {b.var():.6f}; theoretical {vt:.6f}; relative to OLS {b.var()/b_ols.var():.2f}")

# ---------------------------------------------------------------
print("\n=== Experiment 4: 'best' only under the assumptions, and only among linear estimators ===")
# (a) heteroskedastic errors: sd proportional to x
Uh = rng.randn(reps, ns) * 0.25 * xs
Yh = alpha + beta * xs + Uh
bh_ols = Yh @ zt
w = 1 / xs**2                                      # weighted least squares weights
def wls_slope(Ymat):
    xw = np.sum(w * xs) / w.sum(); yw = (Ymat * w).sum(axis=1) / w.sum()
    return ((Ymat - yw[:, None]) * (w * (xs - xw))).sum(axis=1) / np.sum(w * (xs - xw)**2)
bh_wls = wls_slope(Yh)
print(f"heteroskedastic: OLS mean {bh_ols.mean():.4f}, var {bh_ols.var():.6f}; WLS mean {bh_wls.mean():.4f}, var {bh_wls.var():.6f}; "
      f"OLS/WLS variance ratio {bh_ols.var()/bh_wls.var():.2f}")
# (b) fat-tailed errors: Student t with 3 d.f., scaled to sd 2; least absolute deviations is non-linear
r2 = 2000
Ut = rng.standard_t(3, (r2, ns)) * sigma / np.sqrt(3)
Yt = alpha + beta * xs + Ut
bt_ols = Yt @ zt
bt_lad = np.array([sm.QuantReg(Yt[i], sm.add_constant(xs)).fit(q=0.5).params[1] for i in range(r2)])
print(f"t(3) errors: OLS mean {bt_ols.mean():.4f}, var {bt_ols.var():.6f}; LAD mean {bt_lad.mean():.4f}, var {bt_lad.var():.6f}; "
      f"OLS/LAD ratio {bt_ols.var()/bt_lad.var():.2f}")

# ---------------------------------------------------------------
print("\n=== Experiment 5: estimating sigma^2 -- why divide by n - 2 ===")
res = Ys - (a_ols[:, None] + b_ols[:, None] * xs)
RSS = (res**2).sum(axis=1)
print(f"mean RSS/(n-2) {np.mean(RSS/(ns-2)):.4f}; mean RSS/n {np.mean(RSS/ns):.4f}; true sigma^2 {sigma**2}")
se_b = np.sqrt(RSS / (ns - 2) / Sxx)
print(f"mean estimated se(beta_hat) {se_b.mean():.5f}; actual sd of beta_hat {b_ols.std():.5f}")

# ---------------------------------------------------------------
print("\n=== Experiment 6: consistency ===")
rng = np.random.RandomState(43)
for nn in [20, 100, 1000, 10000]:
    bex, ben = [], []
    for _ in range(1000):
        v = rng.randn(nn); xx = 5 + v; e = rng.randn(nn)
        y_ex = 1 + 0.5 * xx + e                     # exogenous
        y_en = 1 + 0.5 * xx + 0.5 * v + e * np.sqrt(0.75)   # Cov(x, u) = 0.5, Var(u) = 1
        xc = xx - xx.mean()
        bex.append(np.sum(xc * y_ex) / np.sum(xc**2)); ben.append(np.sum(xc * y_en) / np.sum(xc**2))
    bex, ben = np.array(bex), np.array(ben)
    print(f"n = {nn:5d}: exogenous mean {bex.mean():.4f} sd {bex.std():.4f} share within 0.05 {np.mean(abs(bex-0.5)<0.05):.3f} | "
          f"endogenous mean {ben.mean():.4f} sd {ben.std():.4f}")
print("plim under endogeneity = 0.5 + Cov(x,u)/Var(x) = 0.5 + 0.5/1 = 1.0")

# ---------------------------------------------------------------
print("\n=== Experiment 7: TSS = ESS + RSS and R^2 ===")
f = ols(Y, X); yhat = f.fittedvalues; e = f.resid
TSS = np.sum((Y - Y.mean())**2); ESS = np.sum((yhat - Y.mean())**2); RSS1 = np.sum(e**2)
print(f"Engel: TSS {TSS:,.0f}; ESS {ESS:,.0f}; RSS {RSS1:,.0f}; ESS+RSS {ESS+RSS1:,.0f}; cross term {np.sum((yhat-Y.mean())*e):.2e}")
print(f"R^2 = ESS/TSS {ESS/TSS:.4f}; 1 - RSS/TSS {1-RSS1/TSS:.4f}; corr(X,Y)^2 {np.corrcoef(X,Y)[0,1]**2:.4f}; "
      f"corr(Y,yhat)^2 {np.corrcoef(Y,yhat)[0,1]**2:.4f}; statsmodels {f.rsquared:.4f}")
x5 = np.array([10, 20, 30, 40, 50.]); y5 = np.array([8, 15, 24, 30, 38.])
f5 = ols(y5, x5); print(f"five households: TSS {np.sum((y5-y5.mean())**2):.1f}, RSS {np.sum(f5.resid**2):.2f}, R^2 {f5.rsquared:.5f}")
s2_engel = RSS1 / (n - 2); print(f"Engel s^2 {s2_engel:,.1f}; s {np.sqrt(s2_engel):.2f}; se(beta) {np.sqrt(s2_engel/np.sum(x**2)):.5f}; "
                                    f"statsmodels se {f.bse[1]:.5f}")

# ---------------------------------------------------------------
print("\n=== Experiment 8: problems with R^2 ===")
# 8.1 spurious regression with trending series
rng = np.random.RandomState(47); T = 200; r2s = []
for i in range(2000):
    ya = np.cumsum(0.5 + rng.randn(T)); xa = np.cumsum(0.5 + rng.randn(T))
    r2s.append(ols(ya, xa).rsquared)
    if i == 0: print(f"8.1 one pair of independent random walks with drift: R^2 {r2s[0]:.3f}")
r2s = np.array(r2s); print(f"8.1 across 2000 pairs: median R^2 {np.median(r2s):.3f}; share above 0.9 {np.mean(r2s>0.9):.3f}")
# 8.2 omitted Z correlated with X
rng = np.random.RandomState(48); nn = 200
Z = rng.randn(nn); Xz = Z + 0.4 * rng.randn(nn); Yz = 1 + 2 * Z + rng.randn(nn)
fz = ols(Yz, Xz); fzz = ols(Yz, Xz, Z)
print(f"8.2 corr(X,Z) {np.corrcoef(Xz,Z)[0,1]:.3f}; Y on X alone: R^2 {fz.rsquared:.3f}, slope {fz.params[1]:.3f}; "
      f"Y on X and Z: slope on X {fzz.params[1]:.3f}, on Z {fzz.params[2]:.3f}")
# 8.3 R^2 is symmetric: reverse regression
fr = ols(X, Y)
print(f"8.3 food on income R^2 {f.rsquared:.4f}; income on food R^2 {fr.rsquared:.4f}; product of slopes {f.params[1]*fr.params[1]:.4f}")
# 8.4 time series vs cross-section
fm = ols(macro.realcons, macro.realdpi)
gc = np.diff(np.log(macro.realcons)); gy = np.diff(np.log(macro.realdpi)); fg = ols(gc, gy)
print(f"8.4 US consumption on income, levels: R^2 {fm.rsquared:.4f}; growth rates: R^2 {fg.rsquared:.4f}, slope {fg.params[1]:.3f}; "
      f"Engel cross-section: R^2 {f.rsquared:.4f}")
# 8.5 low R^2, correct X
rng = np.random.RandomState(49); nn = 1000
Xl = rng.randn(nn); Yl = 1 + 0.5 * Xl + 5 * rng.randn(nn); fl = ols(Yl, Xl)
print(f"8.5 true slope 0.5, noisy: R^2 {fl.rsquared:.4f}; slope {fl.params[1]:.3f}; t {fl.tvalues[1]:.2f}")
ae = pd.read_excel("Foundations_Practice_Data.xlsx", sheet_name="A6_Age_Earnings", header=3, usecols="A:C")
ae.columns = ["w", "age", "earn"]
fa1 = ols(ae.earn, ae.age); fa2 = ols(ae.earn, ae.age, ae.age**2)
print(f"8.5 age-earnings: linear R^2 {fa1.rsquared:.4f}; with age^2 R^2 {fa2.rsquared:.4f}")
# 8.6 different dependent variables
fll = ols(np.log(Y), np.log(X))
print(f"8.6 Engel linear R^2 {f.rsquared:.4f}; log-log R^2 {fll.rsquared:.4f}; "
      f"log-log fit judged on Y in francs: corr(Y, exp(fitted))^2 {np.corrcoef(Y, np.exp(fll.fittedvalues))[0,1]**2:.4f}; "
      f"elasticity {fll.params[1]:.3f}")

# ---------------------------------------------------------------
# coordinates for figures
def hist(a, bins, lo, hi):
    c, ed = np.histogram(a, bins=bins, range=(lo, hi)); return " ".join(f"({p:.4f},{q})" for p, q in zip(ed, list(c) + [c[-1]]))
out = {
    "h_ols": hist(b_ols, 40, 0.0, 1.0), "h_fl": hist(b_fl, 40, 0.0, 1.0), "h_half": hist(b_half, 40, 0.0, 1.0),
}
rng = np.random.RandomState(43); cons = {}
for nn in [20, 100, 1000]:
    bb = []
    for _ in range(4000):
        v = rng.randn(nn); xx = 5 + v; y_ex = 1 + 0.5 * xx + rng.randn(nn); xc = xx - xx.mean()
        bb.append(np.sum(xc * y_ex) / np.sum(xc**2))
    cons[nn] = hist(np.array(bb), 60, -0.1, 1.1)
out["cons"] = cons
with open("module4_coords.py", "w") as fh: fh.write("COORDS = " + repr(out) + "\n")
print("\n[figure coordinates written to module4_coords.py]")
