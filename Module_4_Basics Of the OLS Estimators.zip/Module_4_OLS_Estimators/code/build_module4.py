"""Fill figure placeholders in module_4_template.tex."""
from module4_coords import COORDS
t = open("module_4_template.tex").read()
c = dict(COORDS); cons = c.pop("cons")
c.update({"c20": cons[20], "c100": cons[100], "c1000": cons[1000]})
for k, v in c.items(): t = t.replace(f"@@{k}@@", v)
assert "@@" not in t
open("module_4_ols_estimators.tex", "w").write(t); print("written")
