# Module 4 -- Basics of the OLS Estimators
# R companion to module4_examples.py. Needs engel.csv and macro.csv (from module2_examples.py),
# Foundations_Practice_Data.xlsx, and the packages quantreg and readxl.
# Deterministic results match the notes; simulations give the same pattern, different decimals.

engel <- read.csv("engel.csv"); macro <- read.csv("macro.csv")
X <- engel$income; Y <- engel$foodexp; n <- length(X)

cat("=== Experiment 1: OLS as a weighted sum ===\n")
x <- X - mean(X); z <- x / sum(x^2)
print(c(sum_z = sum(z), sum_zX = sum(z * X), sum_z2 = sum(z^2), inv_Sxx = 1 / sum(x^2),
        sum_zY = sum(z * Y), ols = unname(coef(lm(Y ~ X))[2])))
cat("share of |weight| on 10 richest:", sum(sort(abs(z), decreasing = TRUE)[1:10]) / sum(abs(z)), "\n")

# common Monte Carlo design
set.seed(41); alpha <- 2; beta <- 0.5; sigma <- 2; ns <- 30; reps <- 10000
xs <- seq(1, 20, length.out = ns); xd <- xs - mean(xs); Sxx <- sum(xd^2); zt <- xd / Sxx; m <- ns / 2
mu <- matrix(alpha + beta * xs, reps, ns, byrow = TRUE)
Ys <- mu + matrix(rnorm(reps * ns, 0, sigma), reps)
b_ols <- as.vector(Ys %*% zt); a_ols <- rowMeans(Ys) - b_ols * mean(xs)

cat("\n=== Experiment 2: unbiasedness ===\n")
print(c(mean_b = mean(b_ols), mean_a = mean(a_ols), sd_b = sd(b_ols), sd_b_theory = sqrt(sigma^2 / Sxx),
        sd_a = sd(a_ols), sd_a_theory = sqrt(sigma^2 * sum(xs^2) / (ns * Sxx)), within_005 = mean(abs(b_ols - beta) < 0.05)))

cat("\n=== Experiment 3: other linear unbiased estimators ===\n")
b_fl <- (Ys[, ns] - Ys[, 1]) / (xs[ns] - xs[1])
b_half <- (rowMeans(Ys[, (m + 1):ns]) - rowMeans(Ys[, 1:m])) / (mean(xs[(m + 1):ns]) - mean(xs[1:m]))
print(rbind(mean = c(ols = mean(b_ols), first_last = mean(b_fl), halves = mean(b_half)),
            var = c(var(b_ols), var(b_fl), var(b_half)),
            theory = c(sigma^2 / Sxx, 2 * sigma^2 / (xs[ns] - xs[1])^2,
                       2 * sigma^2 / (m * (mean(xs[(m + 1):ns]) - mean(xs[1:m]))^2))))

cat("\n=== Experiment 4: limits of 'best' ===\n")
Yh <- mu + matrix(rnorm(reps * ns), reps) * matrix(0.25 * xs, reps, ns, byrow = TRUE); w <- 1 / xs^2
b_wls <- apply(Yh, 1, function(y) coef(lm(y ~ xs, weights = w))[2])
cat("heteroskedastic: var OLS", var(as.vector(Yh %*% zt)), " var WLS", var(b_wls), "\n")
library(quantreg)
Yt <- t(replicate(2000, alpha + beta * xs + rt(ns, 3) * sigma / sqrt(3)))
b_lad <- apply(Yt, 1, function(y) coef(rq(y ~ xs, tau = 0.5))[2])
cat("t(3) errors: var OLS", var(as.vector(Yt %*% zt)), " var LAD", var(b_lad), "\n")

cat("\n=== Experiment 5: estimating sigma^2 ===\n")
RSS <- rowSums((Ys - (a_ols + outer(b_ols, xs)))^2)
print(c(RSS_n2 = mean(RSS / (ns - 2)), RSS_n = mean(RSS / ns), mean_se = mean(sqrt(RSS / (ns - 2) / Sxx)), sd_b = sd(b_ols)))
fe <- lm(Y ~ X); print(c(s = summary(fe)$sigma, se_b = summary(fe)$coefficients[2, 2]))

cat("\n=== Experiment 6: consistency ===\n")
set.seed(43)
for (nn in c(20, 100, 1000, 10000)) {
  est <- t(replicate(1000, { v <- rnorm(nn); xx <- 5 + v; e <- rnorm(nn); xc <- xx - mean(xx)
    c(sum(xc * (1 + 0.5 * xx + e)) / sum(xc^2), sum(xc * (1 + 0.5 * xx + 0.5 * v + sqrt(0.75) * e)) / sum(xc^2)) }))
  cat(sprintf("n = %5d: exogenous mean %.4f sd %.4f | endogenous mean %.4f sd %.4f\n",
              nn, mean(est[, 1]), sd(est[, 1]), mean(est[, 2]), sd(est[, 2])))
}

cat("\n=== Experiment 7: TSS = ESS + RSS ===\n")
f <- lm(Y ~ X); yhat <- fitted(f); e <- resid(f)
TSS <- sum((Y - mean(Y))^2); ESS <- sum((yhat - mean(Y))^2); RSS1 <- sum(e^2)
print(c(TSS = TSS, ESS = ESS, RSS = RSS1, sum = ESS + RSS1, cross = sum((yhat - mean(Y)) * e)))
print(c(R2 = ESS / TSS, alt = 1 - RSS1 / TSS, corrXY2 = cor(X, Y)^2, corrYyhat2 = cor(Y, yhat)^2))

cat("\n=== Experiment 8: problems with R^2 ===\n")
set.seed(47); r2s <- replicate(2000, { y <- cumsum(0.5 + rnorm(200)); x <- cumsum(0.5 + rnorm(200)); summary(lm(y ~ x))$r.squared })
cat("8.1 median R2", median(r2s), " share > 0.9", mean(r2s > 0.9), "\n")
set.seed(48); Z <- rnorm(200); Xz <- Z + 0.4 * rnorm(200); Yz <- 1 + 2 * Z + rnorm(200)
cat("8.2 corr(X,Z)", cor(Xz, Z), " R2", summary(lm(Yz ~ Xz))$r.squared, "\n"); print(coef(lm(Yz ~ Xz + Z)))
fr <- lm(X ~ Y); cat("8.3 R2 both ways", summary(f)$r.squared, summary(fr)$r.squared, " product of slopes", coef(f)[2] * coef(fr)[2], "\n")
cat("8.4 levels", summary(lm(realcons ~ realdpi, data = macro))$r.squared,
    " growth", summary(lm(diff(log(macro$realcons)) ~ diff(log(macro$realdpi))))$r.squared, "\n")
set.seed(49); Xl <- rnorm(1000); Yl <- 1 + 0.5 * Xl + 5 * rnorm(1000); fl <- lm(Yl ~ Xl)
cat("8.5 noisy R2", summary(fl)$r.squared, " slope", coef(fl)[2], " t", summary(fl)$coefficients[2, 3], "\n")
library(readxl)
ae <- read_excel("Foundations_Practice_Data.xlsx", sheet = "A6_Age_Earnings", range = "A4:C254"); names(ae) <- c("w", "age", "earn")
cat("8.5 age linear R2", summary(lm(earn ~ age, data = ae))$r.squared, " quadratic", summary(lm(earn ~ age + I(age^2), data = ae))$r.squared, "\n")
fll <- lm(log(Y) ~ log(X))
cat("8.6 linear", summary(f)$r.squared, " log-log", summary(fll)$r.squared, " judged on Y", cor(Y, exp(fitted(fll)))^2,
    " elasticity", coef(fll)[2], "\n")
