BASICS OF THE OLS ESTIMATORS: LINEARITY, UNBIASEDNESS, EFFICIENCY, CONSISTENCY AND THE OVERALL GOODNESS OF FIT
Module 4 of the course on Linear Regression Models. Manhar Singh, November 2026. Notes: 33 pages.

FOLDERS
  notes/                 PDF of the notes, LaTeX source, and lrm-notes.sty (keep the .sty next to the .tex to compile).
  overleaf_single_file/  The same notes as one self-contained .tex file (style inlined): paste into Overleaf and compile.
  data/                  engel.csv and macro.csv (from Module 2), and Foundations_Practice_Data.xlsx (the student workbook
                         of the Preliminary Module on expectation, variance and covariance; its sheet A6_Age_Earnings is used here).
  code/                  module4_examples.py reproduces every number in the notes (needs numpy, pandas, scipy, statsmodels,
                         openpyxl). module4_examples.R does the same steps (needs readxl); simulations give the same pattern
                         but different decimals. Copy the three files in data/ into code/ before running either script.
                         module_4_template.tex, module4_coords.py and build_module4.py regenerate the notes' .tex
                         (the figures' plotted points) if you change the data.

COMPILING: pdflatex, run twice (for the table of contents).
This module has no practice workbook of its own and no instructor material.
NOTE: the R script was not run for this edition; please run it once before class.
