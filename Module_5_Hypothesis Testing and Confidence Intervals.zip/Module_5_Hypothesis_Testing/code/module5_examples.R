# Module 5 -- Hypothesis Testing and Confidence Intervals
# R companion to module5_examples.py. Base R. Needs engel.csv and macro.csv (from module2_examples.py).
# Deterministic results match the notes; simulations give the same pattern, different decimals.

engel <- read.csv("engel.csv"); macro <- read.csv("macro.csv")

cat("=== Experiment 1: testing the Engel slope ===\n")
f <- lm(foodexp ~ income, data = engel); print(summary(f))
b <- coef(f)[2]; se <- summary(f)$coefficients[2, 2]; df <- f$df.residual
print(c(t0 = unname(b / se), crit = qt(0.975, df)))
t05 <- (b - 0.5) / se; print(c(t_half = unname(t05), p = unname(2 * pt(-abs(t05), df))))
t1 <- (b - 1) / se; print(c(t_one = unname(t1), crit_one_sided = qt(0.05, df), p = unname(pt(t1, df))))
print(confint(f, level = 0.90)); print(confint(f, level = 0.95)); print(confint(f, level = 0.99))
print(c(AIC = AIC(f), BIC = BIC(f), logLik = as.numeric(logLik(f))))

cat("\n=== Experiment 2: size and power ===\n")
reject_rate <- function(ns, beta_true, crit, reps = 10000, sigma = 2) {
  xs <- seq(1, 20, length.out = ns); xd <- xs - mean(xs); Sxx <- sum(xd^2)
  Ys <- matrix(2 + beta_true * xs, reps, ns, byrow = TRUE) + matrix(rnorm(reps * ns, 0, sigma), reps)
  bh <- as.vector(Ys %*% (xd / Sxx)); ah <- rowMeans(Ys) - bh * mean(xs)
  seb <- sqrt(rowSums((Ys - ah - outer(bh, xs))^2) / (ns - 2) / Sxx)
  mean(abs((bh - 0.5) / seb) > crit) }
set.seed(51)
print(sapply(c(5, 10, 30), function(ns) c(t = reject_rate(ns, 0.5, qt(0.975, ns - 2)), z = reject_rate(ns, 0.5, 1.96))))
for (ns in c(10, 30, 60)) cat("power n =", ns, ":", round(sapply(c(0.5, 0.55, 0.6, 0.7, 0.8), function(bt) reject_rate(ns, bt, qt(0.975, ns - 2))), 3), "\n")

cat("\n=== Experiment 3: confidence interval coverage ===\n")
set.seed(53)
for (ns in c(5, 10, 30)) {
  xs <- seq(1, 20, length.out = ns); xd <- xs - mean(xs); Sxx <- sum(xd^2)
  Ys <- matrix(2 + 0.5 * xs, 10000, ns, byrow = TRUE) + matrix(rnorm(10000 * ns, 0, 2), 10000)
  bh <- as.vector(Ys %*% (xd / Sxx)); ah <- rowMeans(Ys) - bh * mean(xs)
  seb <- sqrt(rowSums((Ys - ah - outer(bh, xs))^2) / (ns - 2) / Sxx)
  cat(sprintf("n = %2d: coverage with t %.4f, with 1.96 %.4f\n", ns,
              mean(abs(bh - 0.5) <= qt(0.975, ns - 2) * seb), mean(abs(bh - 0.5) <= 1.96 * seb)))
}

cat("\n=== Experiment 4: Okun's law ===\n")
du <- diff(macro$unemp); g <- 100 * diff(log(macro$realgdp)); fo <- lm(du ~ g)
print(summary(fo)$coefficients); print(confint(fo))
bo <- coef(fo)[2]; so <- summary(fo)$coefficients[2, 2]
print(c(t_half = unname((bo + 0.5) / so), t_okun = unname((bo + 0.3) / so), steady_growth_q = unname(-coef(fo)[1] / bo)))

cat("\n=== Experiment 5: Keynesian consumption function ===\n")
fc <- lm(realcons ~ realdpi, data = macro); print(summary(fc)$coefficients); print(confint(fc))
cat("t for MPC = 1:", (coef(fc)[2] - 1) / summary(fc)$coefficients[2, 2],
    " Durbin-Watson:", sum(diff(resid(fc))^2) / sum(resid(fc)^2), "\n")
fd <- lm(diff(macro$realcons) ~ diff(macro$realdpi)); print(coef(fd)); print(confint(fd))

cat("\n=== Experiment 6: statistical versus economic significance ===\n")
set.seed(56); xb <- rnorm(2e5); yb <- 10 + 0.01 * xb + rnorm(2e5); print(summary(lm(yb ~ xb))$coefficients)
xs2 <- rnorm(12); ys2 <- 10 + 0.8 * xs2 + 1.5 * rnorm(12); print(confint(lm(ys2 ~ xs2)))
