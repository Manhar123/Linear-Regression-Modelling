"""Fill figure placeholders in module_5_template.tex."""
from module5_coords import COORDS
t = open("module_5_template.tex").read(); c = COORDS
styles = {10: "rust,dotted,line width=1pt,mark=*,mark size=1.5pt", 30: "sepia,dashed,mark=square*,mark size=1.5pt",
          60: "slate,line width=1.1pt,mark=triangle*,mark size=2pt"}
bs = [0.5, 0.55, 0.6, 0.7, 0.8]
pp = []
for ns, row in c["power"].items():
    pp.append(f"\\addplot[{styles[ns]}] coordinates {{" + " ".join(f"({b},{r:.4f})" for b, r in zip(bs, row)) + "};")
    pp.append(f"\\addlegendentry{{$n={ns}$}}")
t = t.replace("@@powerplots@@", "\n".join(pp))
ci = []
for i, (lo, hi, miss) in enumerate(c["ci"], 1):
    col = "rust,line width=1.4pt" if miss else "slate,line width=0.9pt"
    ci.append(f"\\addplot[{col}] coordinates {{({i},{lo:.4f}) ({i},{hi:.4f})}};")
t = t.replace("@@ciplots@@", "\n".join(ci))
t = t.replace("@@okun@@", c["okun"])
a, b = c["okun_ab"]; t = t.replace("@@okunline@@", f"{a:.4f}{b:+.4f}*x")
assert "@@" not in t
open("module_5_hypothesis_testing.tex", "w").write(t); print("written")
