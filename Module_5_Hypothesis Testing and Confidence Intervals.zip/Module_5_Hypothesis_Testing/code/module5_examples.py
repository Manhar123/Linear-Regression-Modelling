"""Module 5 -- Hypothesis Testing and Confidence Intervals.
Every number printed in the Module 5 notes is produced by this script.
Needs engel.csv and macro.csv (written by module2_examples.py).
Run from top to bottom:  python module5_examples.py
"""
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm

engel = pd.read_csv("engel.csv"); macro = pd.read_csv("macro.csv")
X = engel["income"].to_numpy(); Y = engel["foodexp"].to_numpy(); n = len(X)
def ols(y, *xs): return sm.OLS(y, sm.add_constant(np.column_stack(xs))).fit()

# ---------------------------------------------------------------
print("=== Experiment 1: testing the Engel slope ===")
f = ols(Y, X); b, se = f.params[1], f.bse[1]; df = n - 2
tc = stats.t.ppf(0.975, df)
print(f"beta_hat {b:.4f}, se {se:.5f}, df {df}, t (H0: beta=0) {b/se:.2f}, crit 5% two-sided {tc:.3f}, "
      f"p {2*stats.t.sf(abs(b/se), df):.2e}")
print(f"alpha_hat {f.params[0]:.3f}, se {f.bse[0]:.3f}, t {f.tvalues[0]:.2f}, p {f.pvalues[0]:.2e}")
t05 = (b - 0.5) / se
print(f"H0: beta = 0.5: t {t05:.3f}, two-sided p {2*stats.t.sf(abs(t05), df):.3f}")
t1 = (b - 1) / se
print(f"H0: beta = 1 vs H1: beta < 1: t {t1:.2f}, one-sided crit {stats.t.ppf(0.05, df):.3f}, p {stats.t.cdf(t1, df):.2e}")
for lvl in [0.90, 0.95, 0.99]:
    c = stats.t.ppf(1 - (1 - lvl) / 2, df)
    print(f"{int(lvl*100)}% CI for beta: [{b - c*se:.4f}, {b + c*se:.4f}] (crit {c:.3f})")
c = stats.t.ppf(0.975, df); print(f"95% CI for alpha: [{f.params[0]-c*f.bse[0]:.2f}, {f.params[0]+c*f.bse[0]:.2f}]")
print("statsmodels conf_int:\n", f.conf_int(0.05))
print(f"other output: R2 {f.rsquared:.4f}, adj R2 {f.rsquared_adj:.4f}, s {np.sqrt(f.scale):.3f}, F {f.fvalue:.2f} "
      f"(p {f.f_pvalue:.2e}), t^2 {f.tvalues[1]**2:.2f}, logL {f.llf:.2f}, AIC {f.aic:.2f}, BIC {f.bic:.2f}, "
      f"RSS {f.ssr:.1f}, mean Y {Y.mean():.3f}, sd Y {Y.std(ddof=1):.3f}")
hq = -2 * f.llf + 2 * 2 * np.log(np.log(n)); print(f"Hannan-Quinn {hq:.2f}")
print(f"elasticity at means {b*X.mean()/Y.mean():.3f}")

# ---------------------------------------------------------------
print("\n=== Experiment 2: size and power of the t test (Monte Carlo) ===")
rng = np.random.RandomState(51); reps = 10000; sigma = 2.0
def sim_reject(ns, beta_true, crit_fn, beta0=0.5):
    xs = np.linspace(1, 20, ns); xd = xs - xs.mean(); Sxx = np.sum(xd**2)
    Ys = 2 + beta_true * xs + rng.randn(reps, ns) * sigma
    bh = Ys @ (xd / Sxx); ah = Ys.mean(axis=1) - bh * xs.mean()
    rss = ((Ys - ah[:, None] - bh[:, None] * xs)**2).sum(axis=1)
    seb = np.sqrt(rss / (ns - 2) / Sxx)
    return np.mean(np.abs((bh - beta0) / seb) > crit_fn(ns))
tcrit = lambda ns: stats.t.ppf(0.975, ns - 2); zcrit = lambda ns: 1.96
for ns in [5, 10, 30]:
    print(f"n = {ns:2d}, H0 true: rejection rate with t critical value {sim_reject(ns, 0.5, tcrit):.4f}; "
          f"with 1.96 {sim_reject(ns, 0.5, zcrit):.4f}")
print("power (H0: beta = 0.5, 5% two-sided):")
power = {}
for ns in [10, 30, 60]:
    row = [sim_reject(ns, bt, tcrit) for bt in [0.5, 0.55, 0.6, 0.7, 0.8]]
    power[ns] = row; print(f"  n = {ns:2d}: true beta 0.5, 0.55, 0.6, 0.7, 0.8 -> {np.round(row, 3)}")
# p-values under H0 are uniform
rng = np.random.RandomState(52); ps = []
xs = np.linspace(1, 20, 30); xd = xs - xs.mean(); Sxx = np.sum(xd**2)
Ys = 2 + 0.5 * xs + rng.randn(reps, 30) * sigma
bh = Ys @ (xd / Sxx); ah = Ys.mean(axis=1) - bh * xs.mean()
seb = np.sqrt(((Ys - ah[:, None] - bh[:, None] * xs)**2).sum(axis=1) / 28 / Sxx)
pv = 2 * stats.t.sf(np.abs((bh - 0.5) / seb), 28)
print(f"p-values when H0 is true: share below 0.01 {np.mean(pv<0.01):.4f}, 0.05 {np.mean(pv<0.05):.4f}, 0.10 {np.mean(pv<0.10):.4f}, "
      f"0.50 {np.mean(pv<0.5):.4f}")

# ---------------------------------------------------------------
print("\n=== Experiment 3: confidence interval coverage ===")
rng = np.random.RandomState(53)
for ns in [5, 10, 30]:
    xs = np.linspace(1, 20, ns); xd = xs - xs.mean(); Sxx = np.sum(xd**2)
    Ys = 2 + 0.5 * xs + rng.randn(reps, ns) * sigma
    bh = Ys @ (xd / Sxx); ah = Ys.mean(axis=1) - bh * xs.mean()
    seb = np.sqrt(((Ys - ah[:, None] - bh[:, None] * xs)**2).sum(axis=1) / (ns - 2) / Sxx)
    ct = stats.t.ppf(0.975, ns - 2)
    cov_t = np.mean(np.abs(bh - 0.5) <= ct * seb); cov_z = np.mean(np.abs(bh - 0.5) <= 1.96 * seb)
    print(f"n = {ns:2d}: coverage of 95% CI with t {cov_t:.4f}; with 1.96 {cov_z:.4f}; t crit {ct:.3f}; "
          f"average width (t) {np.mean(2*ct*seb):.3f}")
# first 20 intervals for the figure (n = 10)
rng = np.random.RandomState(54); ns = 10
xs = np.linspace(1, 20, ns); xd = xs - xs.mean(); Sxx = np.sum(xd**2)
Ys = 2 + 0.5 * xs + rng.randn(40, ns) * sigma
bh = Ys @ (xd / Sxx); ah = Ys.mean(axis=1) - bh * xs.mean()
seb = np.sqrt(((Ys - ah[:, None] - bh[:, None] * xs)**2).sum(axis=1) / (ns - 2) / Sxx)
ct = stats.t.ppf(0.975, ns - 2); lo, hi = bh - ct * seb, bh + ct * seb
miss = np.where((lo > 0.5) | (hi < 0.5))[0]
print(f"figure: 40 intervals, misses at samples {miss + 1}")
ci_list = [(float(l), float(h), bool((l > 0.5) | (h < 0.5))) for l, h in zip(lo, hi)]

# ---------------------------------------------------------------
print("\n=== Experiment 4: Okun's law, US quarterly 1959-2009 ===")
du = np.diff(macro.unemp.to_numpy()); g = 100 * np.diff(np.log(macro.realgdp.to_numpy()))
fo = ols(du, g); bo, so = fo.params[1], fo.bse[1]; dfo = len(du) - 2
print(f"n {len(du)}; a {fo.params[0]:.4f} (se {fo.bse[0]:.4f}); b {bo:.4f} (se {so:.4f}); t {fo.tvalues[1]:.2f}; "
      f"p {fo.pvalues[1]:.2e}; R2 {fo.rsquared:.3f}; s {np.sqrt(fo.scale):.3f}")
ci = fo.conf_int(); print(f"95% CI for b: [{ci[1,0]:.4f}, {ci[1,1]:.4f}]")
print(f"growth that keeps unemployment constant: -a/b = {-fo.params[0]/bo:.3f}% per quarter = {-4*fo.params[0]/bo:.2f}% per year")
t_half = (bo - (-0.5)) / so; print(f"H0: b = -0.5: t {t_half:.2f}, p {2*stats.t.sf(abs(t_half), dfo):.3e}")
t_03 = (bo - (-0.3)) / so; print(f"H0: b = -0.3: t {t_03:.2f}, p {2*stats.t.sf(abs(t_03), dfo):.3f}")

# ---------------------------------------------------------------
print("\n=== Experiment 5: Keynesian consumption function, US ===")
fc = ols(macro.realcons.to_numpy(), macro.realdpi.to_numpy()); bc, sc = fc.params[1], fc.bse[1]; dfc = len(macro) - 2
print(f"levels: a {fc.params[0]:.2f} (se {fc.bse[0]:.2f}); MPC {bc:.4f} (se {sc:.5f}); R2 {fc.rsquared:.4f}")
t1 = (bc - 1) / sc; print(f"H0: MPC = 1 vs H1: MPC < 1: t {t1:.2f}; one-sided crit {stats.t.ppf(0.05, dfc):.3f}; p {stats.t.cdf(t1, dfc):.2e}")
print(f"95% CI for MPC: [{fc.conf_int()[1,0]:.4f}, {fc.conf_int()[1,1]:.4f}]")
from statsmodels.stats.stattools import durbin_watson
print(f"Durbin-Watson of the levels regression {durbin_watson(fc.resid):.3f} (a warning sign, Modules 13-14)")
dc, dy = np.diff(macro.realcons.to_numpy()), np.diff(macro.realdpi.to_numpy()); fd = ols(dc, dy)
print(f"first differences: MPC {fd.params[1]:.4f} (se {fd.bse[1]:.4f}); 95% CI [{fd.conf_int()[1,0]:.3f}, {fd.conf_int()[1,1]:.3f}]; "
      f"R2 {fd.rsquared:.3f}")

# ---------------------------------------------------------------
print("\n=== Experiment 6: statistical versus economic significance ===")
rng = np.random.RandomState(56); N = 200000
xb = rng.randn(N); yb = 10 + 0.01 * xb + rng.randn(N); fb = ols(yb, xb)
print(f"n {N}: slope {fb.params[1]:.4f}, t {fb.tvalues[1]:.2f}, p {fb.pvalues[1]:.2e}, R2 {fb.rsquared:.5f}")
xs2 = rng.randn(12); ys2 = 10 + 0.8 * xs2 + 1.5 * rng.randn(12); fs = ols(ys2, xs2)
print(f"n 12: slope {fs.params[1]:.3f}, t {fs.tvalues[1]:.2f}, p {fs.pvalues[1]:.3f}, 95% CI [{fs.conf_int()[1,0]:.2f}, {fs.conf_int()[1,1]:.2f}]")

# ---------------------------------------------------------------
out = {"power": power, "ci": ci_list,
       "okun": " ".join(f"({p:.3f},{q:.2f})" for p, q in zip(g, du)), "okun_ab": (float(fo.params[0]), float(bo))}
with open("module5_coords.py", "w") as fh: fh.write("import numpy as np\nCOORDS = " + repr(out) + "\n")
print("\n[figure coordinates written to module5_coords.py]")
