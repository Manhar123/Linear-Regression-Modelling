HYPOTHESIS TESTING AND CONFIDENCE INTERVALS: THE t TEST, p-VALUES, CONFIDENCE INTERVALS,
AND ESTIMATING AND READING A REGRESSION IN R AND GRETL
Module 5 of the course on Linear Regression Models. Manhar Singh, November 2026. Notes: 30 pages.

FOLDERS
  notes/                 PDF of the notes, LaTeX source, and lrm-notes.sty (keep the .sty next to the .tex to compile).
  overleaf_single_file/  The same notes as one self-contained .tex file (style inlined): paste into Overleaf and compile.
  data/                  engel.csv and macro.csv (from Module 2).
  code/                  module5_examples.py reproduces every number in the notes (needs numpy, pandas, scipy, statsmodels).
                         module5_examples.R (R) and module5_examples.inp (GRETL) follow the same steps; simulations give
                         the same pattern but different decimals. Copy the two CSV files from data/ into code/ first.
                         module_5_template.tex, module5_coords.py and build_module5.py regenerate the notes' .tex
                         (the figures' plotted points) if you change the data.

COMPILING: pdflatex, run twice (for the table of contents).
This module has no practice workbook and no instructor material.
NOTE: the R and GRETL scripts were not run for this edition; please run them once before class.
